// בחרתי בי — the onboarding (DESIGN.md §6.1, rebuilt for issue #82). Three
// screens between an opening and a closing, one character, and at the end of
// them one complete kabbalah.
//
// This file renders and wires; it computes nothing. Every number, string and
// decision comes from onboarding-model.js, which has no DOM and is covered
// by the node tests in extension/tests/.
//
// It is a tab and not the popup for three reasons: the shell is 760×640 and
// Chrome caps a popup at 800×600; §3.2 gives the popup a different width
// entirely, so one document cannot be both; and a tab does not die when she
// leaves to fetch her link. The draft below stays anyway — a tab can be
// closed too.
//
// ---------------------------------------------------------------------------
// The three screens, and what each of them asks (issue #82, Sara's plan):
//
//   1 · התמונה הכנה        her name · where the time escapes · up to five
//                          links · and, per link, how long she is there today
//   2 · בואי נחשוב על פתרון quiet hours · and, per link, how much of that time
//                          she wants back
//   3 · את מסוגלת          the kabbalah as it now stands, with a way back into
//                          it · the reminder hour · companion or commitment
//
// The engine derives the limit; she is never asked for one. See
// onboarding-model.js's header for the reframe, and docs/data-model.md for
// what the record now carries.
// ---------------------------------------------------------------------------

// B6 (2026-08-21): the done screen's only control used to be "restart",
// which wipes everything she just decided and starts the onboarding over —
// the one moment right after she commits, the product offered to discard
// it. It should lead her into the product instead. The dashboard is real:
// extension/dashboard.html, built on claude/issue-20-dashboard (commit
// 2f40444, "a local dashboard, and finally a door to a second kabbalah") —
// not merged into this branch at the time of this note. One named constant,
// so the single place this points to is easy to find and fix if that path
// changes before the branches meet. UNVERIFIED until that branch merges:
// this file has not been run against a real dashboard.html on disk.
const DASHBOARD_PATH = "dashboard.html";

let answers = freshAnswers();
let step = 0;

// ---------- what this tab was opened to do (issue #20) ----------
// Three intents over the same three screens, parsed once at load from the
// URL this tab was opened with — the dashboard's "יצירת קבלה חדשה" opens
// `onboarding.html?new=1`, its "עריכת אתרים" opens `?edit=<id>`, and every
// other door (the popup's "הגדרות הקבלה", the morning-after screen's "להקל
// על הקבלה", a fresh install) still opens the bare URL. Read once and never
// re-derived mid-session, so a query string is not something a click three
// screens later could be tricked into re-reading.
//
// `saveKabbalah()`'s three branches below are the whole of what makes
// creating a second kabbalah safe: the default branch is byte-for-byte what
// this file always did (edit kabbalot[0], or create it if it does not exist
// yet), and the other two are additions beside it, never a rewrite of it.
function intentFromLocation() {
  if (typeof location === "undefined") return { kind: "edit" };
  let params;
  try {
    params = new URLSearchParams(location.search);
  } catch {
    return { kind: "edit" };
  }
  if (params.get("new") === "1") return { kind: "new" };
  const editId = params.get("edit");
  if (editId) return { kind: "edit-id", targetId: editId };
  return { kind: "edit" };
}

let intent = intentFromLocation();

// The index into answers.places whose link field should take the cursor on
// the next STEPS[1] render, or null when nothing is waiting for focus. Not
// part of `answers`, so it never reaches the draft or the saved kabbalah.
let focusPlaceIndex = null;

// Issue #86 · what the "לא בטוחה? אפשר לבדוק את זה יחד." link is showing
// right now, WHEN NOTHING IS RUNNING (historyBusy — declared below —
// answers "is something running" on its own; historyBlock, STEPS[1],
// checks it first and shows the same busy note regardless of historyOffer
// while it is true, so there is deliberately no "working" kind here to
// keep in sync with it). null while the link itself is on screen;
// { kind: "declined" } (a real no — she answered Chrome's own prompt with
// cancel); { kind: "error" } (the
// permission was granted but the read itself threw — same words as
// "declined" (COPY.historyDeclined; see historyBlock's own comment for why
// the text stays one string), but with the link kept alive beside it,
// because this one is not a "no" she gave and retrying costs her nothing);
// { kind: "none" } (nothing of hers matched anywhere in the window);
// { kind: "tooFewDays" } (a named place DID have matching visits, just not
// on enough distinct days — or an average that rounded to 0 — to call an
// estimate; COPY.historyTooFewDays, never COPY.historyNothing, which would
// be a false "we found nothing"); { kind: "estimate",
// byPlace: { [place]: minutes }, skippedPlaces: [place] } while the offer
// is up — skippedPlaces (Minor, follow-up review of #86) is every OTHER
// named place that had a real visit in the window but did not itself
// qualify, so historyBlock can name it with COPY.historyPlaceTooThin
// instead of silently dropping it from a card that already shows at least
// one number. Deliberately NOT a
// field of `answers`: answers is what the draft and the kabbalah are built
// from, and an estimate she has not accepted must never reach either — only
// an accepted number does, through acceptHistoryOffer() below, by writing
// places[i].spend exactly as the dial does. Reset whenever the places
// change, so an offer never outlives the places it was computed for.
let historyOffer = null;

// Code-quality review of f187b20 (I3): historyBusy stops a second click
// from starting a second concurrent request/read/remove while the first is
// still in flight — checkHistoryTogether no-ops instead of racing chrome
// itself. historyGeneration is the finer-grained guard: every action that
// invalidates an in-flight read (resetHistoryOffer, called from every
// place-changing handler below) bumps it, and checkHistoryTogether checks
// it before every render so a read that finishes after her places already
// changed is thrown away rather than shown.
let historyBusy = false;
let historyGeneration = 0;

// The one place historyOffer is ever cleared. Always paired with bumping
// historyGeneration, so a checkHistoryTogether() call already in flight for
// the places this reset just walked away from is invalidated at the same
// moment the offer disappears from the screen — not left to land later on
// top of whatever she has done since.
function resetHistoryOffer() {
  historyOffer = null;
  historyGeneration++;
}

const el = (id) => document.getElementById(id);

// §3.8 / §4: the pose per step is onboarding-model.js's own POSE_BY_STEP
// (§4, "one pose per moment") — not redeclared here. Two `const
// POSE_BY_STEP` at the top level of two <script> tags that share one page
// is a SyntaxError in a real browser, the same as it is in a single file;
// this file only adds what the model does not compute: the pixel position
// that goes with each pose. DESIGN.md §3.8 gives only the range
// (150–171px), not a value per pose; the exact figures are
// design/Kabbalot Pilot v3.dc.html's own — the one place they are written
// down.
const TOP_BY_STEP = [167, 150, 150, 171, 154];

function paintChrome() {
  el("character").src = `character/v3/${POSE_BY_STEP[step]}.png`;
  el("character").style.top = `${TOP_BY_STEP[step]}px`;
  el("bubble").textContent = bubbleFor(step, answers);

  const shows = showsProgress(step);
  el("progress").hidden = !shows;
  if (shows) {
    const n = Math.min(step, 3);
    el("seg1").classList.toggle("on", n >= 1);
    el("seg2").classList.toggle("on", n >= 2);
    el("seg3").classList.toggle("on", n >= 3);
    el("step-label").textContent = stepLabel(step);
  }
}

// Every step renders into the column and then wires itself.
const STEPS = {};

// Fix 1 (2026-08-21, Sara's report): steps 1–3 carry the fields she must
// not miss — the place link, "+ עוד מקום" and the nickname on screen 1, the
// quiet-hours toggle on screen 2, the mode cards on screen 3. `.step`'s own
// `margin-block: auto` (below, onboarding.css) is right for step 0 and the
// done screen, where a short message is meant to sit centred — but the same
// rule centres a *short* screen 1 too, and the emptiest, most common state
// of screen 1 (one blank row, nothing resolved yet) is exactly that: short.
// Centering it pushes the very fields this screen exists for down into the
// middle of the 534px pane instead of starting at its top. `.step-top`
// pins that margin to zero instead of auto, so these three steps always
// start flush with the top of the column. See the report for the measured
// gap this removes.
const TOP_ALIGNED_STEPS = [1, 2, 3];

function render() {
  paintChrome();
  const column = el("column");
  column.innerHTML = "";
  const node = STEPS[step]();
  if (TOP_ALIGNED_STEPS.includes(step)) node.classList.add("step-top");
  column.appendChild(node);
}

function go(next) {
  step = next;
  render();
  saveDraftSoon();
}

// A tiny helper so each renderer reads as markup rather than as DOM calls.
function html(markup) {
  const wrap = document.createElement("div");
  wrap.className = "step";
  wrap.innerHTML = markup;
  return wrap;
}

// The rows that actually resolved to a place, with the index each one has in
// answers.places — the renderer needs both: the index to write back through,
// the place to key a label or a goal by.
function resolvedRows() {
  const seen = [];
  const out = [];
  (answers.places || []).forEach((row, i) => {
    const place = placeOfRow(row);
    if (!place || seen.includes(place)) return;
    seen.push(place);
    out.push({ row, i, place });
  });
  return out;
}

// ---------- step 0 · the opening (§6.1) ----------
STEPS[0] = () => {
  const node = html(`
    <div class="h1">${COPY.h1}</div>
    <div class="lead">${COPY.lead}</div>
    <div class="step-footer">
      <button type="button" class="btn-primary lg" id="start">${COPY.start}</button>
    </div>
  `);
  node.querySelector("#start").addEventListener("click", () => go(1));
  return node;
};

// ---------- the compact time bar ----------
//
// One control, two jobs: how long she is there today (screen 1, from two
// places up) and how much she wants back (screen 2, always). It is the same
// arithmetic the dial does — minutesFromFrac/fracOf in the model, one floor,
// one step, one ceiling — drawn as a 10px horizontal track instead of a
// 230px ring, because five rings do not fit in a 400px column and Sara's own
// constraint on this screen is that one place must look simple.
//
// The drag shape is the quiet-hours range's, deliberately: paint the bar's
// own pixels while the pointer is down (paintBar), and re-render exactly
// once on pointerup. The bug that shape exists to avoid is worth naming —
// calling render() from pointermove rebuilds the node the gesture is holding
// and resets the drag closure mid-gesture, so one press produced one step of
// movement and then went inert. See the dial's own comment further down.
// `label` is what she pasted, so she can tell one row from the next — and
// that is the *only* screen in this product where the raw ADDRESS she typed
// is ever shown back to her, row by row. The cultural red line (Sara's
// ruling, #15, narrowed by Founder Ruling 1, 2026-08-26) is about every
// surface someone else in the room could see without her having opened it
// herself — not "the product speaks only of the nickname past setup",
// which stopped being true the moment nameFrom()'s own fallback started
// defaulting a kabbalah's name to the site itself. This screen is where
// she is still typing the addresses herself, one row at a time; hiding them
// back from her on the very next screen would make the list unreadable and
// prove nothing. `aria` is the question the bar answers, which is what a
// screen reader needs and a sighted reader already has from the card's own
// title.
function barMarkup({ key, label, aria, value, min, max, text }) {
  const frac = fracOf(value, min, max);
  const pct = Math.min(Math.max(frac, 0), 1) * 100;
  return `
    <div class="mins" data-bar="${key}">
      <div class="mins-head">
        <span class="mins-label" dir="ltr">${label}</span>
        <span class="mins-value" dir="ltr" data-bar-value="${key}">${text}</span>
      </div>
      <div class="mins-track" data-bar-track="${key}" dir="ltr">
        <div class="mins-fill" data-bar-fill="${key}" style="width:${pct}%;"></div>
        <div class="mins-handle" data-bar-handle="${key}" role="slider" tabindex="0"
             aria-label="${aria}" aria-valuemin="${min}" aria-valuemax="${max}"
             aria-valuenow="${value}" aria-valuetext="${text}"
             style="left:${pct}%;"></div>
      </div>
    </div>`;
}

// `get`/`set` read and write the one number this bar owns; `bounds()` returns
// its live floor and ceiling (a give-back bar's ceiling moves the moment its
// own place's spend does); `text()` is the words under the number.
function wireBar(node, key, { get, set, bounds, text, live }) {
  const track = node.querySelector(`[data-bar-track="${key}"]`);
  const handle = node.querySelector(`[data-bar-handle="${key}"]`);
  const fill = node.querySelector(`[data-bar-fill="${key}"]`);
  const valueEl = node.querySelector(`[data-bar-value="${key}"]`);
  if (!track || !handle || !fill) return;
  let dragging = false;
  let rect = null;

  const paintBar = () => {
    const { min, max } = bounds();
    const pct = Math.min(Math.max(fracOf(get(), min, max), 0), 1) * 100;
    fill.style.width = `${pct}%`;
    handle.style.left = `${pct}%`;
    // A slider's aria-valuenow/valuetext have to stay truthful for the whole
    // drag, not only at its ends.
    handle.setAttribute("aria-valuenow", get());
    handle.setAttribute("aria-valuemin", min);
    handle.setAttribute("aria-valuemax", max);
    handle.setAttribute("aria-valuetext", text());
    if (valueEl) valueEl.textContent = text();
    // Anything else on the screen that is a function of this number — the
    // two running totals under screen 2's list — repaints here rather than
    // waiting for the pointer to come up, for the same reason the dial
    // repaints its own weekly line: a total that only catches up on release
    // is a total she cannot use while she is choosing.
    live?.();
  };

  const fromPointer = (e) => {
    if (!rect || !rect.width) return;
    const { min, max } = bounds();
    // The track is dir="ltr" (§5: a time axis is not mirrored), so the left
    // edge is the floor whichever way the page reads.
    const frac = (e.clientX - rect.left) / rect.width;
    set(minutesFromFrac(frac, min, max));
    paintBar();
    saveDraftSoon();
  };

  const start = (e) => {
    rect = track.getBoundingClientRect();
    dragging = true;
    handle.setPointerCapture?.(e.pointerId);
    fromPointer(e);
  };
  // Pressing anywhere on the track jumps the handle there and keeps
  // dragging — the handle is 18px wide and the value it names is not, so
  // asking her to hit the knob exactly would be the same "this only responds
  // to clicks" complaint in a different costume.
  track.addEventListener("pointerdown", start);
  handle.addEventListener("pointerdown", start);
  const move = (e) => {
    if (dragging) fromPointer(e);
  };
  track.addEventListener("pointermove", move);
  handle.addEventListener("pointermove", move);
  const end = (e) => {
    if (!dragging) return;
    dragging = false;
    handle.releasePointerCapture?.(e.pointerId);
    render();
    saveDraftSoon();
    el("column").querySelector(`[data-bar-handle="${key}"]`)?.focus();
  };
  track.addEventListener("pointerup", end);
  track.addEventListener("pointercancel", end);
  handle.addEventListener("pointerup", end);
  handle.addEventListener("pointercancel", end);

  // §9 · arrows step, Home and End go to this bar's own ends.
  handle.addEventListener("keydown", (e) => {
    const { min, max } = bounds();
    const steps = { ArrowRight: DIAL_STEP, ArrowUp: DIAL_STEP, ArrowLeft: -DIAL_STEP, ArrowDown: -DIAL_STEP };
    if (e.key in steps) {
      e.preventDefault();
      set(Math.min(Math.max(get() + steps[e.key], min), max));
    } else if (e.key === "Home") {
      e.preventDefault();
      set(min);
    } else if (e.key === "End") {
      e.preventDefault();
      set(max);
    } else {
      return;
    }
    render();
    saveDraftSoon();
    el("column").querySelector(`[data-bar-handle="${key}"]`)?.focus();
  });
}

// ---------- screen 1 · the honest picture (§6.1, issue #82) ----------
//
// Sara's four faults, all of them found sitting in front of the real
// product, and where each one is answered here:
//
//   1. chips that did not require a link  → there are no chips. A row is a
//      link. The scope chips (הכל / רק Shorts) appear on a row only once the
//      link she pasted turns out to be a youtube address, which is the one
//      place in the product where a site's own shape actually matters.
//   2. a field that did not explain itself → the nickname sits under a plain
//      divider, below the links it names, with §7's own placeholder.
//   3. a dial that demanded clicks → it is dragged (claude/drag-controls),
//      and from two places up it is replaced by bars that are dragged too.
//   4. a screen that mixed one site's quota with the whole browser's quiet
//      hours → quiet hours are on screen 2 now, and nothing on this screen
//      asks for a quota at all.
//
// What is on this screen is Sara's own list for it and nothing else: her
// name, the question, the links, and per link how long she is there. The
// "ספרי במילים שלך" card is not on her list, and walking this in a real
// browser is what settled it — that card was the block pushing the dial
// itself half under the sticky continue button on the very first paint. It
// has moved to screen 2, under the give-back, rather than being deleted:
// `kabbalahNote` has its own retention rule (#39) and losing the only way to
// write it would be a bigger change than she asked for.
STEPS[1] = () => {
  const rows = answers.places.length ? answers.places : [emptyPlaceRow()];
  const resolved = resolvedRows();
  const single = resolved.length <= 1;

  // The scope choice belongs to the row whose link turned out to be a
  // youtube address, so it renders inside that row rather than as a card of
  // its own below the list. A separate card cost a card's padding and a
  // column gap on the one screen with least room to spare, and it also put
  // the question further from the answer it is about.
  const ytChips = (row, i) => {
    const place = placeOfRow(row);
    if (!place || !isYouTubePlace(place)) return "";
    return `<div class="yt-row pop">
        <span class="yt-label">${COPY.ytTitle}</span>
        <div class="chip-row" role="radiogroup" aria-label="${COPY.ytTitle}">
          ${YT_CHIPS.map(
            (name) =>
              `<button type="button" class="chip pink sm${row.ytRule === name ? " on" : ""}"
                       role="radio" aria-checked="${row.ytRule === name}"
                       data-yt="${i}|${name}">${name}</button>`
          ).join("")}
        </div>
      </div>`;
  };

  // Fix 2 (2026-08-21): the mail scope chip, same shape as the YouTube one
  // immediately above — a row's own corner choice, appearing only once the
  // link she pasted resolves to a Gmail address. This is the one place the
  // brief asks for it: at setup, on the row that names the site, never past
  // it (the CULTURAL RED LINE, popup.js's header).
  const mailChips = (row, i) => {
    const place = placeOfRow(row);
    if (!place || !isMailPlace(place)) return "";
    return `<div class="yt-row pop">
        <span class="yt-label">${COPY.mailTitle}</span>
        <div class="chip-row" role="radiogroup" aria-label="${COPY.mailTitle}">
          ${MAIL_CHIPS.map(
            (name) =>
              `<button type="button" class="chip pink sm${row.mailRule === name ? " on" : ""}"
                       role="radio" aria-checked="${row.mailRule === name}"
                       data-mail="${i}|${name}">${name}</button>`
          ).join("")}
        </div>
      </div>`;
  };

  const placeRow = (row, i) => `
    <div class="place-row">
      <div class="place-head">
        <input class="field place-link" dir="ltr" autocomplete="off"
               data-place-index="${i}" placeholder="${COPY.linkPlaceholder}" />
        ${
          rows.length > 1
            ? `<button type="button" class="place-remove" data-remove-place="${i}"
                       aria-label="${COPY.removePlace}">−</button>`
            : ""
        }
      </div>
      ${ytChips(row, i)}
      ${mailChips(row, i)}
    </div>`;

  const spend = totalSpend(answers);

  // The links are one list and the times are another, on purpose. Keeping a
  // 230px dial inside a scrollable list of link boxes is how the single-place
  // case — the case Sara says most women will be in — ends up looking like
  // the crowded one. So the card holds only what she types, and the times sit
  // below it under §7's own title, as one dial or as one bar per place.
  const spendControls =
    single && resolved.length === 1
      ? dialMarkup(resolved[0].row, resolved[0].i)
      : resolved
          .map(({ row, i, place }) =>
            barMarkup({
              key: `spend-${i}`,
              label: place,
              aria: COPY.spendTitle,
              value: spendOfRow(row),
              min: DIAL_MIN,
              max: answers.dialMax,
              text: fmt(spendOfRow(row)),
            })
          )
          .join("");

  // Fix 3 (2026-08-21, Sara's report): "שאני כבר בוחרת 2 אופציות אני לא
  // יכולה לבחור שאני יותר מ3 שעות ביום." The extend mechanism
  // (canExtendDial/nextDialMax/extendLabel, onboarding-model.js) already
  // existed and the dial already offers it — dialMarkup() below renders the
  // same button this one does. The wall she hit was never the model's; it
  // was that this bar view (two places up, which is what "already choosing
  // 2 options" means) never rendered the button at all, so `answers.dialMax`
  // had no way to move once every bar reached its shared 3:00 ceiling. One
  // extend button under the whole list, not one per bar — the ceiling is
  // shared by every bar (`max: answers.dialMax` above), so raising it once
  // raises it for all of them, exactly the way the dial's own click does
  // through the very same `#extend` handler this reuses further down.
  const multiExtend =
    resolved.length > 1 && canExtendDial(Math.max(...resolved.map(({ i }) => spendOfRow(answers.places[i]))), answers.dialMax)
      ? `<button type="button" class="btn-quiet sm dial-extend" id="extend">${extendLabel(answers.dialMax)}</button>`
      : "";

  // Issue #86. Under the time control, above the footer (the footer stays
  // the last child — see nothing-important-sits-under-the-footer.mjs). A
  // .btn-link muted, not a button: it is the smallest thing on the screen
  // on purpose — her own estimate is the default, this is the way to check
  // it. Every other state of the same slot is a single quiet line, except
  // the offer (a card with its two answers) and "error" just below.
  const historyLinkMarkup = () =>
    `<button type="button" class="btn-link muted history-check" id="history-check">${COPY.historyCheck}</button>`;
  const historyBlock = () => {
    // Item 4 (whole-branch review of #86): checked before anything else,
    // including whether historyOffer itself is null. A place-changing edit
    // resets historyOffer (resetHistoryOffer) the instant she makes it,
    // even while checkHistoryTogether is still mid-flight for the places
    // it was computed for — without this, that reset alone brought the
    // link back on screen, and clicking it was a dead click: checkHistory
    // Together's own historyBusy guard (still true — the abandoned run has
    // not reached its own `finally` yet) silently swallowed it, with
    // nothing on screen saying why. historyBusy only ever clears once a
    // run actually finishes, and its own `finally` always re-renders when
    // it does (see checkHistoryTogether), so this note is never left
    // stranded — the link reliably comes back the moment there is truly
    // nothing running, live and clickable.
    if (historyBusy) return `<div class="hint history-note">${COPY.historyWorking}</div>`;
    if (!historyOffer) return historyLinkMarkup();
    if (historyOffer.kind === "declined") return `<div class="hint history-note">${COPY.historyDeclined}</div>`;
    // Code-quality review (Minor, post-f187b20): "declined" used to also
    // cover a read that threw after the grant — same COPY.historyDeclined
    // line (its own comment, onboarding-model.js, already says the string
    // covers both), but with no way back. That was fine while the only way
    // in was a real API failure. It stopped being fine once
    // background.js's boot-time cleanup (I4, the-permission-does-not
    // -outlive-a-dead-tab.mjs) started running on every worker wake: a wake
    // landing mid-read revokes `history` out from under checkHistoryTogether
    // and the read throws, right after she pressed yes — a transient loss,
    // not a "no" — so unlike a real decline, the link stays reachable
    // beside the note instead of leaving her stuck. COPY is unchanged
    // either way; only whether the link renders differs.
    if (historyOffer.kind === "error") {
      return `<div class="hint history-note">${COPY.historyDeclined}</div>${historyLinkMarkup()}`;
    }
    if (historyOffer.kind === "none") return `<div class="hint history-note">${COPY.historyNothing}</div>`;
    // Blocker 2: distinct from "none" — real visits were found, just not
    // enough of them to call an estimate. Never COPY.historyNothing, which
    // would say "no visits" when there were some.
    if (historyOffer.kind === "tooFewDays") {
      return `<div class="hint history-note">${COPY.historyTooFewDays}</div>`;
    }
    const entries = Object.entries(historyOffer.byPlace);
    // M3: `place` is interpolated unescaped, same as it already is in
    // resolvedRows()/spendControls above — safe only because every place
    // string that reaches here is historyPlaceOf's own output, which is
    // built exclusively from URL's own .hostname (plus this file's fixed
    // "/shorts" and mail-corner suffixes), never a raw string a page could
    // put HTML characters into.
    //
    // Blocker 1 (whole-branch review of #86): this used to branch on
    // entries.length — how many places CLEARED the HISTORY_MIN_DAYS floor —
    // not on how many places she actually named. She could name two
    // (youtube.com and news.example), one of them (say news.example) never
    // reach five qualifying days, and entries would still have length 1:
    // the single-place, unlabelled sentence would render for a number that
    // is only ever one of two places, with nothing on screen saying which.
    // placesFrom(answers).length is what she named, independent of how many
    // of those places the read could actually confirm — the single-line
    // layout is only honest when there was never more than one place to
    // begin with.
    // Minor (follow-up review of #86): skippedPlaces only ever holds OTHER
    // named places (never the one entries[0] describes), so it is empty
    // whenever placesFrom(answers).length === 1 and never touches that
    // branch — a place with nothing to show and nothing else named beside
    // it stays silent, same as before; a place with nothing to show WHILE
    // another one does is named, so she is never left looking at one row
    // for two places she typed in with no explanation for the gap.
    const lines =
      placesFrom(answers).length === 1
        ? [historyOfferLine(entries[0][1])]
        : [
            HISTORY_OFFER_LEAD,
            ...entries.map(([place, m]) => `<span dir="ltr">${place}</span>: ${historyOfferRow(m)}`),
            ...(historyOffer.skippedPlaces || []).map(
              (place) => `<span dir="ltr">${place}</span>: ${COPY.historyPlaceTooThin}`
            ),
            HISTORY_OFFER_TRAILER,
          ];
    return `<div class="card pop history-offer">
        ${lines.map((l) => `<div class="history-line">${l}</div>`).join("")}
        <div class="history-actions">
          <button type="button" class="btn-quiet sm" id="history-accept">${COPY.historyAccept}</button>
          <button type="button" class="btn-link muted" id="history-ignore">${COPY.historyIgnore}</button>
        </div>
      </div>`;
  };

  const node = html(`
    <label class="her-name">
      <span class="her-name-label">${COPY.herNameLabel}</span>
      <input class="field" id="her-name" maxlength="24" autocomplete="off" />
    </label>
    <div class="h3">${COPY.step1Title}</div>
    <div class="card">
      <div class="place-list">${rows.map(placeRow).join("")}</div>
      ${
        rows.length < PLACE_MAX
          ? `<button type="button" class="btn-link place-add" id="add-place">${COPY.addPlace}</button>`
          : ""
      }
      ${
        // Fix 5 (2026-08-21, Sara's decision) removed this field from every
        // path — "she wants the character to suggest the name herself
        // later." That silence is safe only for a *first* kabbalah (nothing
        // yet to confuse it with; see nameFrom()'s own comment,
        // onboarding-model.js). It stops being safe the moment a second
        // kabbalah can exist, and issue #20's `?new=1` and `?edit=<id>`
        // intents are exactly the two paths where that is true: `new`
        // creates a kabbalah beside one that already has a name, and
        // `edit-id` targets one specific kabbalah among possibly several.
        // The plain, no-query default still never asks — Sara's decision
        // stands there. Before issue #94 that path also carried the popup's
        // own "הגדרות הקבלה" / "להקל על הקבלה" (both opened onboarding.html
        // blind, landing on this same default); both now open `?edit=<id>`
        // instead, so what is left on the bare default is first-time
        // onboarding — nothing yet to confuse a silent name with. Reinstating
        // the exact approved copy (COPY.namePlaceholder, unchanged since
        // before Fix 5) rather than inventing new wording for either case.
        intent.kind === "new" || intent.kind === "edit-id"
          ? `<div class="place-divider" aria-hidden="true"></div>
             <input class="field" id="custom-name" maxlength="24" autocomplete="off"
                    placeholder="${COPY.namePlaceholder}" />`
          : ""
      }
    </div>
    ${
      resolved.length
        ? `<div class="card-title spend-title">${COPY.spendTitle}</div>
           ${
             // The dial is one 230px ring whose height never grows with
             // anything. The bars do grow with the places — `.spend-list`
             // used to cap and scroll them on their own, a second scroll
             // region nested inside `.column`'s; Fix 6 / B1 (2026-08-21)
             // removed that cap along with the sticky footer it was
             // guarding against, so they now grow in the one scroll region
             // the whole step already has. See she-must-not-scroll-to
             // -find-them.mjs and nothing-important-sits-under-the-footer
             // .mjs.
             single && resolved.length === 1
               ? spendControls
               : `<div class="spend-list">${spendControls}</div>${multiExtend}`
           }
           <div class="weekly">${weeklyLine(spend)}</div>
           ${historyBlock()}`
        : ""
    }
    ${
      resolved.length
        ? `<div class="step-footer"><button type="button" class="btn-primary md" id="next">${COPY.next}</button></div>`
        : ""
    }
  `);

  node.querySelector("#her-name").value = answers.herName || "";

  node.querySelector("#her-name").addEventListener("input", (e) => {
    answers.herName = e.target.value;
    saveDraftSoon();
  });

  // Only present for intent.kind "new" / "edit-id" (see the render above) —
  // optional-chained the same way #add-place already is, since this step
  // renders without it on the default path.
  const customNameInput = node.querySelector("#custom-name");
  if (customNameInput) {
    customNameInput.value = answers.customName || "";
    customNameInput.addEventListener("input", (e) => {
      answers.customName = e.target.value;
      saveDraftSoon();
    });
  }

  node.querySelectorAll("[data-place-index]").forEach((input) => {
    const i = Number(input.dataset.placeIndex);
    input.value = rows[i]?.link || "";
    input.addEventListener("input", (e) => {
      // Reassigned, never mutated in place: freshAnswers() hands out a new
      // array, but a draft restored from storage does not, and writing
      // through an index would edit whatever else is pointing at it.
      answers.places = rows.map((r, idx) => (idx === i ? { ...r, link: e.target.value } : r));
      resetHistoryOffer();
      render();
      saveDraftSoon();
      // Re-query rather than close over `input`: render() just replaced the
      // whole column, and the node this listener was attached to is gone.
      const again = el("column").querySelector(`[data-place-index="${i}"]`);
      if (again) {
        again.focus();
        again.setSelectionRange(again.value.length, again.value.length);
      }
    });
  });

  node.querySelectorAll("[data-mail]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const [idx, name] = btn.dataset.mail.split("|");
      const i = Number(idx);
      answers.places = rows.map((r, k) => (k === i ? { ...r, mailRule: name } : r));
      // Code-quality review of f187b20 (I2): the chip can change which place
      // a row resolves to (הכל vs a Gmail corner), the same as an edited
      // link can — an offer computed for the row's old place must not sit
      // there looking current for its new one.
      resetHistoryOffer();
      render();
      saveDraftSoon();
    })
  );

  node.querySelectorAll("[data-yt]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const [idx, name] = btn.dataset.yt.split("|");
      const i = Number(idx);
      answers.places = rows.map((r, k) => (k === i ? { ...r, ytRule: name } : r));
      // Code-quality review of f187b20 (I2): same reasoning as the mail chip
      // just above — הכל vs רק Shorts is a different place.
      resetHistoryOffer();
      render();
      saveDraftSoon();
    })
  );

  node.querySelectorAll("[data-remove-place]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const i = Number(btn.dataset.removePlace);
      // This button only exists while rows.length > 1, so removal never
      // drives answers.places below one row. The single refill guard lives
      // at the top of this renderer, so a test that breaks it has somewhere
      // real to fail.
      answers.places = answers.places.filter((_, idx) => idx !== i);
      resetHistoryOffer();
      render();
      saveDraftSoon();
    })
  );

  node.querySelector("#add-place")?.addEventListener("click", () => {
    if (answers.places.length >= PLACE_MAX) return;
    answers.places = [...answers.places, emptyPlaceRow()];
    focusPlaceIndex = answers.places.length - 1;
    // Code-quality review of f187b20 (I2): a fresh empty row does not
    // change what any *existing* row resolves to, but an offer already on
    // screen was rendered for the place set as it stood before this one
    // joined it — the offer's own multi/single layout (historyBlock) and
    // acceptHistoryOffer's per-row write both assume that set is still
    // current.
    resetHistoryOffer();
    render();
    saveDraftSoon();
  });

  if (focusPlaceIndex !== null) {
    const idx = focusPlaceIndex;
    focusPlaceIndex = null;
    // `node` is not attached to the document here — render() appends it
    // right after this function returns, and a detached element cannot take
    // focus in a real browser (a stub's .focus() does not know the
    // difference, which is why no unit test caught this the first time).
    // Deferring to a microtask lets that appendChild happen first.
    queueMicrotask(() => {
      el("column").querySelector(`[data-place-index="${idx}"]`)?.focus();
    });
  }

  // The dial, or one bar per row — only ever one of the two on screen.
  if (single && resolved.length === 1) {
    wireDial(node, resolved[0].i);
  } else {
    for (const { i } of resolved) {
      wireBar(node, `spend-${i}`, {
        get: () => spendOfRow(answers.places[i]),
        set: (v) => {
          answers.places = answers.places.map((r, k) => (k === i ? { ...r, spend: v } : r));
        },
        bounds: () => ({ min: DIAL_MIN, max: answers.dialMax }),
        text: () => fmt(spendOfRow(answers.places[i])),
      });
    }
  }

  node.querySelector("#extend")?.addEventListener("click", () => {
    answers.dialMax = nextDialMax(answers.dialMax);
    render();
    saveDraftSoon();
  });

  node.querySelector("#history-check")?.addEventListener("click", () => {
    checkHistoryTogether();
  });
  node.querySelector("#history-accept")?.addEventListener("click", acceptHistoryOffer);
  node.querySelector("#history-ignore")?.addEventListener("click", () => {
    resetHistoryOffer();
    render();
  });

  node.querySelector("#next")?.addEventListener("click", () => go(2));
  return node;
};

// ---------- issue #86 · "לא בטוחה? אפשר לבדוק את זה יחד." ----------
// The only code in the product that ever holds a history item. The shape is
// the issue's own: ask (inside her click, so Chrome shows its prompt), read
// once, compute, GIVE THE PERMISSION BACK, and only then put anything on
// screen. `finally` is what makes the fourth step unconditional — an API
// that throws after the grant still hands the permission back. What is
// kept afterwards is a number per place and nothing else; the lists this
// function built are gone with its frame.
//
// Code-quality review of f187b20 (I3): historyBusy and historyGeneration
// (declared beside historyOffer above) are what keep this async round trip
// honest against two things happening while it is in flight — a second
// click, and her changing the places it was computed for. historyBusy
// no-ops a stacked call outright, before it ever touches chrome. Every
// historyOffer assignment past that point is gated by stillCurrent():
// resetHistoryOffer (called from every place-changing handler) bumps
// historyGeneration, so a read that finishes after her places already moved
// on is discarded rather than drawn on top of whatever she has done since —
// while the request/read/remove sequence itself always runs to completion
// regardless, because the permission still has to go back either way.
//
// Item 4 (whole-branch review of #86): two render() calls, not one per
// step along the way. The first, right after the grant, is only ever there
// to paint the busy note promptly (a slow read with no visible feedback
// would read as broken); it never touches historyOffer, so it cannot go
// stale. The second, and the only one that ever writes a final result to
// the screen, is the unconditional one in `finally`, reached only after
// historyBusy is already false. historyBlock() (STEPS[1] above) checks
// historyBusy before it ever looks at historyOffer, so ANY render() fired
// while historyBusy is still true — this function's own first one, or one
// from a place-changing edit that landed mid-flight — shows the same busy
// note regardless of what historyOffer holds. That is also what keeps the
// busy note from being stranded on screen forever after a run a
// place-changing edit walked away from: the edit's own render drew the
// busy note too (historyBusy was still true), and only this function's own
// eventual `finally` — the one point historyBusy actually turns false —
// draws the link that comes after it.
async function checkHistoryTogether() {
  const places = placesFrom(answers);
  if (!places.length || historyBusy) return;
  historyBusy = true;
  const myGeneration = ++historyGeneration;
  const stillCurrent = () => historyGeneration === myGeneration;

  try {
    let granted = false;
    try {
      granted = await chrome.permissions.request({ permissions: ["history"] });
    } catch {
      granted = false;
    }
    if (!granted) {
      if (stillCurrent()) historyOffer = { kind: "declined" };
      return;
    }

    // issue #108: tell background.js this tab now owns a live read, so that
    // if this tab dies before its own `finally` below ever runs — closed,
    // crashed, the browser killing the tab — chrome.tabs.onRemoved firing
    // on this tab's id knows to give `history` back on its own instead of
    // leaving it dangling until the next real browser launch. Best-effort:
    // a message that never arrives leaves the read running exactly as
    // before this fix, with chrome.runtime.onStartup/onInstalled as the
    // fallback they always were.
    try {
      await chrome.runtime?.sendMessage?.({ type: "history-read-started" });
    } catch {
      // Nothing to do — see the comment above.
    }

    // Show the busy note immediately — the read below can take a while (a
    // busy profile means several batches of getVisits calls), and a click
    // that produces no visible feedback until the whole thing is done would
    // read as broken, not as busy. historyBlock() shows this note purely
    // from historyBusy (checked before historyOffer), so this render is
    // correct regardless of what historyOffer currently holds — it does not
    // need a stillCurrent() guard the way an historyOffer assignment does,
    // because it is not writing anything that could go stale.
    render();

    let byPlace = null;
    let hadVisitsWithoutEstimate = false;
    let skippedPlaces = [];
    try {
      ({ byPlace, hadVisitsWithoutEstimate, skippedPlaces } = await readHistoryEstimate(places));
    } catch {
      byPlace = null;
    } finally {
      try {
        await chrome.permissions.remove({ permissions: ["history"] });
      } catch {
        // Nothing to do: the permission is optional and Chrome drops it on
        // uninstall regardless; the number is still not shown until here.
      }
      // issue #108: unconditionally, even if the remove above threw — this
      // tab is done holding a read open either way, and background.js must
      // stop treating it as one. Otherwise this same tab closing moments
      // later (the ordinary case, not the dead-tab one) would still look
      // like a tab that died mid-read, and get swept a second, pointless
      // time on top of the removal directly above.
      try {
        await chrome.runtime?.sendMessage?.({ type: "history-read-finished" });
      } catch {
        // Nothing to do — see the comment above.
      }
    }

    if (!stillCurrent()) return;
    // byPlace is only ever null here because the try above threw — a real
    // decline already returned above, before the permission was even
    // granted. "error", not "declined": the retry link stays up for this
    // one (historyBlock's own comment says why).
    //
    // Blocker 2: an empty byPlace is not always "genuinely nothing" —
    // hadVisitsWithoutEstimate (readHistoryEstimate's own comment) is true
    // exactly when at least one named place had a real visit in the window
    // that still fell short of an estimate. "tooFewDays" then, never
    // "none".
    historyOffer =
      byPlace === null
        ? { kind: "error" }
        : Object.keys(byPlace).length
          ? { kind: "estimate", byPlace, skippedPlaces }
          : hadVisitsWithoutEstimate
            ? { kind: "tooFewDays" }
            : { kind: "none" };
  } finally {
    historyBusy = false;
    render();
  }
}

// search() gives one item per URL with its last visit only, which is enough
// for "the next arrival anywhere" but not for her own places, where every
// arrival counts — so getVisits() is asked for those URLs and those only.
// history-estimate.js does the rest on plain objects.
//
// estimateWindowStart(Date.now(), items) is what actually enforces the
// 30-day window (history-estimate.js's own HISTORY_WINDOW_DAYS constant
// only documents its width) and corrects it for a bounded search() that did
// not reach back the full 30 days on a very active profile — passed as
// estimateDailyMinutes's `since` so both corrections are the same value.
// A place sampled on fewer than HISTORY_MIN_DAYS distinct days is too thin
// a sample to call an estimate — dropped here, same as a place with no
// visits at all, so it simply falls out of the offer rather than showing a
// number she never actually generated most of.
//
// M1 (code-quality review of f187b20): the getVisits fan-out used to be one
// at a time, awaited in a loop — a busy profile with hundreds of matching
// URLs held the permission for exactly that many round trips in a row.
// HISTORY_VISITS_BATCH URLs at once, in parallel, shrinks the held-permission
// window to (matched URLs / batch size) round trips instead of one per URL,
// without ever having more than a batch's worth of getVisits calls in the
// air at once.
const HISTORY_VISITS_BATCH = 20;

async function readHistoryEstimate(places) {
  const startTime = Date.now() - HISTORY_WINDOW_DAYS * 86400000;
  const items = await chrome.history.search({ text: "", startTime, maxResults: HISTORY_SEARCH_MAX });
  const matched = items.filter((item) => historyPlaceOf(item.url, places));
  const lists = [items];
  for (let i = 0; i < matched.length; i += HISTORY_VISITS_BATCH) {
    const batch = matched.slice(i, i + HISTORY_VISITS_BATCH);
    const visitsByItem = await Promise.all(
      batch.map((item) => chrome.history.getVisits({ url: item.url }))
    );
    batch.forEach((item, k) => {
      lists.push(
        visitsByItem[k]
          .filter((v) => v.visitTime >= startTime)
          .map((v) => ({ url: item.url, visitTime: v.visitTime }))
      );
    });
  }
  const merged = mergeVisits(lists);
  const since = estimateWindowStart(Date.now(), items);
  const estimates = estimateDailyMinutes(merged, places, { since });
  const byPlace = {};
  for (const [place, e] of Object.entries(estimates)) {
    if (e.daysWithVisits < HISTORY_MIN_DAYS) continue;
    byPlace[place] = e.minutesPerDay;
  }
  // Blocker 2 (whole-branch review of #86): a place can have real visits in
  // the window and still not reach byPlace above — too few distinct days
  // (still present in `estimates`, dropped by the HISTORY_MIN_DAYS filter
  // just above), or an average that rounds down to 0 minutes
  // (history-estimate.js drops those before they ever reach `estimates` at
  // all). Both are "we found something, just not enough to call an
  // estimate" — COPY.historyTooFewDays (offer-wide) or
  // COPY.historyPlaceTooThin (per-row, alongside a place that DID qualify),
  // never COPY.historyNothing, which is reserved for a place nothing here
  // ever matched. Checked against the raw merged, since-windowed visits
  // rather than `estimates`, because that is the only place a
  // rounds-to-zero place still shows up at all.
  //
  // Minor (follow-up review of #86): named alongside "genuinely nothing"
  // places used to just fall out of byPlace with no further trace — fine
  // when NO place qualifies (the whole offer already says "found, not
  // enough" via historyOffer's own tooFewDays kind), but silent and
  // confusing when at least one OTHER place did qualify: she named two
  // places, the card shows one number, and nothing says why the second
  // place is missing. skippedPlaces is every named place with a real visit
  // in the window that still didn't make it into byPlace — the glue
  // (checkHistoryTogether) only actually uses it when byPlace is nonempty;
  // hadVisitsWithoutEstimate is unchanged, just derived from it now
  // instead of computed separately.
  const skippedPlaces = places.filter((place) => {
    if (place in byPlace) return false;
    return merged.some((v) => v.visitTime >= since && historyPlaceOf(v.url, places) === place);
  });
  const hadVisitsWithoutEstimate = skippedPlaces.length > 0;
  return { byPlace, hadVisitsWithoutEstimate, skippedPlaces };
}

// Into the field the way a turned dial goes in: places[i].spend, on the
// grid, with the dial widened if the number is past its current ceiling.
// A row whose place had no visits keeps whatever she set.
function acceptHistoryOffer() {
  if (!historyOffer || historyOffer.kind !== "estimate") return;
  const byPlace = historyOffer.byPlace;
  answers.places = answers.places.map((row) => {
    const place = placeOfRow(row);
    const minutes = place ? byPlace[place] : undefined;
    const spend = spendFromEstimate(minutes);
    return spend === null ? row : { ...row, spend };
  });
  const widest = Math.max(...Object.values(byPlace).map((m) => spendFromEstimate(m) ?? 0));
  answers.dialMax = dialMaxFor(widest, answers.dialMax);
  resetHistoryOffer();
  render();
  saveDraftSoon();
}

// ---------- §3.5 · the dial (one place only) ----------
function dialMarkup(row, i) {
  const spend = spendOfRow(row);
  const max = answers.dialMax;
  const angle = dialAngle(spend, max);
  // C1 (2026-08-21, Sara's report): the ring's own fill is capped short of
  // a true close while more room is still one tap away — see ringAngle's
  // own comment, onboarding-model.js. The handle below, and every
  // aria/text value in this markup, still read the real, uncapped `angle`
  // and `spend` — only the coloured arc is held back.
  const ringDeg = ringAngle(angle, max);
  const handle = dialHandle(spend, max);
  return `
    <div class="dial-wrap">
      <div class="dial" id="dial" role="slider" tabindex="0"
           data-dial-index="${i}"
           aria-label="${COPY.spendTitle}"
           aria-valuemin="${DIAL_MIN}" aria-valuemax="${max}"
           aria-valuenow="${spend}" aria-valuetext="${fmt(spend)} ביום">
        <div class="dial-ring" style="background: conic-gradient(from 0deg,
             var(--primary) 0deg, var(--pink) ${ringDeg}deg,
             var(--track) ${ringDeg}deg 360deg);"></div>
        <div class="dial-face">
          <div class="dial-clock" dir="ltr">${clock(spend)}</div>
          <div class="dial-words">${fmt(spend)} ביום</div>
        </div>
        <div class="dial-handle" style="left:${handle.x}px; top:${handle.y}px;"></div>
      </div>
    </div>
    ${
      canExtendDial(spend, max)
        ? `<button type="button" class="btn-quiet sm dial-extend" id="extend">${extendLabel(max)}</button>`
        : ""
    }`;
}

// Dragging fires pointermove far faster than a full re-render can keep up
// with, and the old code learned that the hard way: it called a full
// render() on *every* pointermove, which rebuilds `#dial` from scratch — a
// fresh element, a fresh keydown listener, and, because `dragging` and
// `rect` were declared inside the renderer, a fresh closure with `dragging`
// reset to false. The pointer was still physically down, but the handler
// installed one instant earlier now pointed at a closure that had already
// forgotten it was dragging. One pointerdown produced exactly one step of
// movement and then went inert — which reads, to a person turning the ring,
// as "this only responds to clicks."
//
// The fix, kept intact from claude/drag-controls: while the pointer is down,
// paint the dial's own pixels directly instead of tearing down and
// rebuilding the node. `dial`, `dragging` and `rect` live in this function's
// closure, which is never recreated mid-drag. A single render() happens once,
// on pointerup, to catch what live-painting does not touch (the extend
// button's appearance, the weekly line's exact wording).
function wireDial(node, i) {
  const dial = node.querySelector("#dial");
  if (!dial) return;
  let rect = null;
  let dragging = false;
  // Set for exactly one fromPointer call — the one pointerdown itself
  // triggers — then cleared. See Fix, 2026-08-26, below.
  let freshPress = false;

  const spendOf = () => spendOfRow(answers.places[i]);
  const setSpend = (v) => {
    answers.places = answers.places.map((r, k) => (k === i ? { ...r, spend: v } : r));
  };

  const paintDialLive = () => {
    const spend = spendOf();
    const max = answers.dialMax;
    const angle = dialAngle(spend, max);
    // C1: the live-drag repaint has to hold the same gap dialMarkup's own
    // first paint does, or the ring would flash fully closed mid-drag and
    // only pull back open again on the next full render() — the exact
    // "looks finished" moment this fix exists to remove, just delayed by
    // one frame instead of avoided.
    const ringDeg = ringAngle(angle, max);
    const pos = dialHandle(spend, max);
    dial.querySelector(".dial-ring").style.background = `conic-gradient(from 0deg,
             var(--primary) 0deg, var(--pink) ${ringDeg}deg,
             var(--track) ${ringDeg}deg 360deg)`;
    dial.querySelector(".dial-clock").textContent = clock(spend);
    dial.querySelector(".dial-words").textContent = `${fmt(spend)} ביום`;
    const handleEl = dial.querySelector(".dial-handle");
    handleEl.style.left = `${pos.x}px`;
    handleEl.style.top = `${pos.y}px`;
    dial.setAttribute("aria-valuenow", spend);
    dial.setAttribute("aria-valuetext", `${fmt(spend)} ביום`);
    const weekly = node.querySelector(".weekly");
    if (weekly) weekly.textContent = weeklyLine(totalSpend(answers));
  };

  // ---------- Fix (2026-08-26, Sara's live-Chrome report) ----------
  // "מסתובב לנצח ולא מתמלא בסוף" — tapping the dial directly (not dragging)
  // sent it to the far end almost everywhere she tapped. The cause: `prev`
  // (dialSeam's own "where the pointer was a moment ago") was ALWAYS
  // dialFrac(spendOf(), dialMax) — the CURRENT stored spend, converted back
  // to a fraction. For a genuine drag that is a fair stand-in for "the
  // pointer's last position" (consecutive samples are close together, and
  // it is exactly what keeps a drag that reaches an end honestly stuck
  // there — see the-dial-gets-stuck-and-full.mjs). For a pointerDOWN it is
  // exactly wrong: there was no drag yet, so "the current stored spend" is
  // simply wherever the dial happened to sit before she touched it — the
  // default, say — and dialSeam was handed that as if it were the pointer's
  // own previous position. A tap far from wherever the dial already sat
  // then reads, arithmetically, identical to a fast drag that spun past an
  // end, and dialSeam (before its own fix, alongside this one) clamped it
  // to an end that has nothing to do with where she actually tapped.
  //
  // A press has no previous position — there is no seam to have crossed —
  // so `freshPress` marks exactly the one fromPointer call a pointerdown
  // triggers: for that call alone, `prev` is seeded with the press's own
  // raw fraction, making dialSeam(raw, raw) a no-op by construction
  // (frac - prevFrac === 0), whatever dialSeam's own gate ends up being.
  // Every later call, mid-drag, goes back to reading the committed spend —
  // untouched, on purpose: that is the behaviour that makes a drag reaching
  // an end stay stuck there sample after sample, and nothing about the tap
  // bug calls for changing it.
  const fromPointer = (e) => {
    if (!rect) return;
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const phi = (Math.atan2(e.clientY - cy, e.clientX - cx) * 180) / Math.PI;
    const raw = ((phi + 90 + 360) % 360) / 360;
    const prev = freshPress ? raw : dialFrac(spendOf(), answers.dialMax);
    freshPress = false;
    setSpend(dialFromFrac(dialSeam(prev, raw), answers.dialMax));
    paintDialLive();
    saveDraftSoon();
  };

  // Pointer Events only, with capture so the drag survives the pointer
  // leaving the 230px circle — it does, constantly, while she is turning it.
  // The handle is `pointer-events:none` (§3.5 — it is a purely visual knob),
  // so every press already reaches `#dial` underneath it.
  dial.addEventListener("pointerdown", (e) => {
    rect = dial.getBoundingClientRect();
    dragging = true;
    freshPress = true; // this press has no previous position, no seam to test
    dial.setPointerCapture?.(e.pointerId);
    fromPointer(e);
  });
  dial.addEventListener("pointermove", (e) => {
    if (dragging) fromPointer(e);
  });
  const endDrag = (e) => {
    if (!dragging) return;
    dragging = false;
    dial.releasePointerCapture?.(e.pointerId);
    render();
    saveDraftSoon();
    el("column").querySelector("#dial")?.focus();
  };
  dial.addEventListener("pointerup", endDrag);
  dial.addEventListener("pointercancel", endDrag);

  // §9: arrows move by five minutes, Home and End go to the ends.
  dial.addEventListener("keydown", (e) => {
    const keys = {
      ArrowUp: DIAL_STEP, ArrowRight: DIAL_STEP,
      ArrowDown: -DIAL_STEP, ArrowLeft: -DIAL_STEP,
    };
    let next = null;
    if (e.key in keys) next = spendOf() + keys[e.key];
    else if (e.key === "Home") next = DIAL_MIN;
    else if (e.key === "End") next = answers.dialMax;
    else return;
    e.preventDefault();
    setSpend(Math.min(Math.max(next, DIAL_MIN), answers.dialMax));
    render();
    saveDraftSoon();
    el("column").querySelector("#dial")?.focus();
  });
}

// ---------- screen 2 · בואי נחשוב על פתרון (issue #82) ----------
//
// Sara's own order: quiet hours first — they belong to the browser and to
// nothing in particular — and then the one question this whole rebuild is
// for. Nothing on this screen names a quota. She says what she wants back
// from each place, and the engine subtracts.
//
// §8 decision 2 · quiet hours have one scope only: the extension rules the
// browser, not the machine, so there is nothing to choose between and no
// chip row is built. #37 deleted the kabbalah-scoped variant from the whole
// codebase.
const QUIET_FLOOR = 6;
// C2-follow-up (2026-08-23, Sara): "אני רוצה להעלות את השעות הקטנות ל-12
// בלילה והוא לא נותן לי, 11 זה הסוף שלו." This was 23, and the axis under
// the bar has always read "24:00" — so the picker was drawing a scale it
// would not let her reach the end of. It reaches it now.
//
// 24:00 IS THE END OF THE DAY, NOT THE START OF ONE. This bar has a single
// axis running 6:00 to 24:00 with `from` always left of `to`, so it cannot
// express a window that *crosses* midnight at all, and there is no
// ambiguity to resolve here: the only thing "24:00" can mean on this
// control is "until the day is over". The engine agrees without being
// asked — parseClock("24:00") is 1440, which is larger than any `from` on
// this axis, so activeWindow takes its plain same-day branch and the window
// runs to minute 1439. A window that really does cross midnight is set in
// the dashboard, where two clock fields can put `to` below `from`, and
// activeWindow's overnight branch has always carried it.
const QUIET_CEIL = 24;
const QUIET_SPAN = 24 - QUIET_FLOOR;
// C2 (2026-08-21) moved this from whole hours to half hours. Sara's report
// of 2026-08-23 asks for the next notch down and names it: "חלקי שעות כמו
// רבע שעה חצי שעה וכזה". A quarter-hour grid contains the half-hour one, so
// nothing C2 fixed is undone here — every position that worked before still
// works, there are simply three stops between the hours instead of one.
//
// The engine needed nothing then and needs nothing now: activeWindow and
// parseClock have always compared plain minutes. quiet-hours.mjs proves it
// at the quarter, at midnight, and across the overnight branch.
const QUIET_STEP = 0.25;

function quietMarkup() {
  const { quietOn, qFrom, qTo } = answers;
  const left = (Math.max(0, qFrom - QUIET_FLOOR) / QUIET_SPAN) * 100;
  const width = ((qTo - qFrom) / QUIET_SPAN) * 100;
  return `
    <div class="card">
      <label class="quiet-toggle">
        <input type="checkbox" id="quiet-on" ${quietOn ? "checked" : ""} />
        <span>${COPY.quietToggle}</span>
      </label>
      ${
        quietOn
          ? `<div class="quiet-body">
               <div class="quiet-row">
                 <span>${COPY.quietFrom}</span>
                 <div class="stepper">
                   <button type="button" class="stepper-btn" data-q="from-" aria-label="${COPY.quietFrom}">−</button>
                   <span class="stepper-value" id="quiet-from-value" dir="ltr">${quietHourLabel(qFrom)}</span>
                   <button type="button" class="stepper-btn" data-q="from+" aria-label="${COPY.quietFrom}">+</button>
                 </div>
                 <span>${COPY.quietTo}</span>
                 <div class="stepper">
                   <button type="button" class="stepper-btn" data-q="to-" aria-label="${COPY.quietTo}">−</button>
                   <span class="stepper-value" id="quiet-to-value" dir="ltr">${quietHourLabel(qTo)}</span>
                   <button type="button" class="stepper-btn" data-q="to+" aria-label="${COPY.quietTo}">+</button>
                 </div>
               </div>
               <div class="quiet-bar-wrap" dir="ltr">
                 <div class="quiet-bar" id="quiet-bar">
                   <div class="quiet-fill" id="quiet-fill" style="left:${left}%; width:${width}%;"></div>
                   <div class="quiet-handle" id="quiet-handle-from" role="slider" tabindex="0"
                        aria-label="${COPY.quietFrom}"
                        aria-valuemin="${QUIET_FLOOR}" aria-valuemax="${qTo - QUIET_STEP}"
                        aria-valuenow="${qFrom}" aria-valuetext="${quietHourLabel(qFrom)}"
                        style="left:${left}%;"></div>
                   <div class="quiet-handle" id="quiet-handle-to" role="slider" tabindex="0"
                        aria-label="${COPY.quietTo}"
                        aria-valuemin="${qFrom + QUIET_STEP}" aria-valuemax="${QUIET_CEIL}"
                        aria-valuenow="${qTo}" aria-valuetext="${quietHourLabel(qTo)}"
                        style="left:${left + width}%;"></div>
                 </div>
                 <div class="quiet-axis"><span>6:00</span><span>15:00</span><span>24:00</span></div>
               </div>
               <div class="fine">${COPY.quietNote}</div>
             </div>`
          : ""
      }
    </div>`;
}

// B_ZERO (2026-08-21, Sara's decision): the target bar's own floor is
// TARGET_MIN (zero, onboarding-model.js), not DIAL_MIN — "not at all" has to
// be a place she can actually drag to. The real floor (LIMIT_FLOOR_MINUTES,
// five) is enforced inside the model, by limitFromRawTarget: DIAL_STEP steps
// of five from a zero floor only ever land on zero or a multiple of five, so
// the bar's own grid never produces the forbidden one-to-four sliver, and
// giveBackFromTarget below snaps anything that somehow does.
STEPS[2] = () => {
  const resolved = resolvedRows();

  const node = html(`
    <div class="h3">${COPY.step2Title}</div>
    ${quietMarkup()}
    <div class="card">
      <div class="card-title">${COPY.targetTitle}</div>
      <div class="give-list">
        ${resolved
          .map(({ row, i, place }) =>
            barMarkup({
              key: `back-${i}`,
              label: place,
              aria: COPY.targetTitle,
              value: targetOfRow(row),
              min: TARGET_MIN,
              max: spendOfRow(row),
              text: fmt(targetOfRow(row)),
            })
          )
          .join("")}
      </div>
    </div>
    <div class="card">
      <div class="card-title">${COPY.noteTitle}</div>
      <textarea class="field" id="note" placeholder="${COPY.notePlaceholder}"></textarea>
    </div>
    <div class="step-footer">
      <button type="button" class="btn-primary md" id="next">${COPY.next}</button>
    </div>
  `);

  // B2 (2026-08-21): this bar drags a target now, not a give-back amount —
  // "how long, per day, are you choosing to be there", not "how much do you
  // want back". The stored field is still `giveBack` (docs/data-model.md;
  // everything downstream of onboarding still reads it), so a drag is
  // converted back through giveBackFromTarget() on the way in. B4 moved the
  // daily/weekly consequence of this whole list off this screen and onto
  // screen 3 as its own redesigned summary, so there is no running total to
  // repaint here any more — each bar only ever has to keep its own number
  // honest, which `text` (in wireBar) already does without a `live` hook.
  for (const { i } of resolved) {
    wireBar(node, `back-${i}`, {
      get: () => targetOfRow(answers.places[i]),
      set: (v) => {
        const spend = spendOfRow(answers.places[i]);
        answers.places = answers.places.map((r, k) =>
          k === i ? { ...r, giveBack: giveBackFromTarget(spend, v) } : r
        );
      },
      bounds: () => ({ min: TARGET_MIN, max: spendOfRow(answers.places[i]) }),
      text: () => fmt(targetOfRow(answers.places[i])),
    });
  }

  node.querySelector("#note").value = answers.note || "";
  node.querySelector("#note").addEventListener("input", (e) => {
    answers.note = e.target.value;
    saveDraftSoon();
  });

  node.querySelector("#quiet-on").addEventListener("change", (e) => {
    answers.quietOn = e.target.checked;
    render();
    saveDraftSoon();
  });

  // C2, then Sara's 2026-08-23 report: quarter hours now, not whole ones
  // and not only halves — QUIET_STEP, never a literal step size here — and
  // the window still never turns inside out.
  node.querySelectorAll("[data-q]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const a = answers;
      if (btn.dataset.q === "from-") a.qFrom = Math.max(QUIET_FLOOR, a.qFrom - QUIET_STEP);
      if (btn.dataset.q === "from+") a.qFrom = Math.min(a.qTo - QUIET_STEP, a.qFrom + QUIET_STEP);
      if (btn.dataset.q === "to-") a.qTo = Math.max(a.qFrom + QUIET_STEP, a.qTo - QUIET_STEP);
      if (btn.dataset.q === "to+") a.qTo = Math.min(QUIET_CEIL, a.qTo + QUIET_STEP);
      render();
      saveDraftSoon();
    })
  );

  // ── the quiet-hours range ───────────────────────────────────────────────
  // Same shape as the dial's own fix, same reason: a `#quiet-bar` rebuilt on
  // every pointermove is a `#quiet-bar` whose drag state was just reset out
  // from under it. paintQuietLive() patches the fill and both handles in
  // place while a handle is down; wireQuietHandle() is one function shared
  // by both handles, each getting its own pointer capture, its own keyboard
  // slider semantics, and its own clamp — the clamp is what stops the two
  // handles from ever crossing.
  const paintQuietLive = () => {
    const { qFrom, qTo } = answers;
    const left = (Math.max(0, qFrom - QUIET_FLOOR) / QUIET_SPAN) * 100;
    const width = ((qTo - qFrom) / QUIET_SPAN) * 100;
    const fill = node.querySelector("#quiet-fill");
    const from = node.querySelector("#quiet-handle-from");
    const to = node.querySelector("#quiet-handle-to");
    if (!fill || !from || !to) return;
    fill.style.left = `${left}%`;
    fill.style.width = `${width}%`;
    from.style.left = `${left}%`;
    to.style.left = `${left + width}%`;
    from.setAttribute("aria-valuenow", qFrom);
    from.setAttribute("aria-valuetext", quietHourLabel(qFrom));
    from.setAttribute("aria-valuemax", qTo - QUIET_STEP);
    to.setAttribute("aria-valuenow", qTo);
    to.setAttribute("aria-valuetext", quietHourLabel(qTo));
    to.setAttribute("aria-valuemin", qFrom + QUIET_STEP);
    const fromValue = node.querySelector("#quiet-from-value");
    const toValue = node.querySelector("#quiet-to-value");
    if (fromValue) fromValue.textContent = quietHourLabel(qFrom);
    if (toValue) toValue.textContent = quietHourLabel(qTo);
  };

  // Rounds to the nearest QUIET_STEP — a quarter of an hour since Sara's
  // 2026-08-23 report. A drag that lands exactly on a half hour or a whole
  // one still resolves there, since both already sit on the same grid.
  const hourFromPointer = (e, bar) => {
    const rect = bar.getBoundingClientRect();
    if (!rect || !rect.width) return null;
    const frac = Math.min(Math.max((e.clientX - rect.left) / rect.width, 0), 1);
    const raw = QUIET_FLOOR + frac * QUIET_SPAN;
    return Math.round(raw / QUIET_STEP) * QUIET_STEP;
  };

  function wireQuietHandle(id, { get, set, ownMin, ownMax }) {
    const handle = node.querySelector(id);
    const bar = node.querySelector("#quiet-bar");
    if (!handle || !bar) return;
    let dragging = false;

    const applyClamped = (raw) => {
      if (raw == null) return;
      const clamped = Math.min(Math.max(raw, ownMin()), ownMax());
      if (clamped === get()) return;
      set(clamped);
    };

    handle.addEventListener("pointerdown", (e) => {
      dragging = true;
      handle.setPointerCapture?.(e.pointerId);
      applyClamped(hourFromPointer(e, bar));
      paintQuietLive();
      saveDraftSoon();
    });
    handle.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      applyClamped(hourFromPointer(e, bar));
      paintQuietLive();
      saveDraftSoon();
    });
    const endDrag = (e) => {
      if (!dragging) return;
      dragging = false;
      handle.releasePointerCapture?.(e.pointerId);
      render();
      saveDraftSoon();
      el("column").querySelector(id)?.focus();
    };
    handle.addEventListener("pointerup", endDrag);
    handle.addEventListener("pointercancel", endDrag);

    handle.addEventListener("keydown", (e) => {
      // C2: half an hour per arrow press, not a whole one.
      const steps = {
        ArrowRight: QUIET_STEP, ArrowUp: QUIET_STEP,
        ArrowLeft: -QUIET_STEP, ArrowDown: -QUIET_STEP,
      };
      if (e.key in steps) {
        e.preventDefault();
        applyClamped(get() + steps[e.key]);
      } else if (e.key === "Home") {
        e.preventDefault();
        applyClamped(ownMin());
      } else if (e.key === "End") {
        e.preventDefault();
        applyClamped(ownMax());
      } else {
        return;
      }
      render();
      saveDraftSoon();
      el("column").querySelector(id)?.focus();
    });
  }

  wireQuietHandle("#quiet-handle-from", {
    get: () => answers.qFrom,
    set: (v) => { answers.qFrom = v; },
    ownMin: () => QUIET_FLOOR,
    ownMax: () => answers.qTo - QUIET_STEP,
  });
  wireQuietHandle("#quiet-handle-to", {
    get: () => answers.qTo,
    set: (v) => { answers.qTo = v; },
    ownMin: () => answers.qFrom + QUIET_STEP,
    ownMax: () => QUIET_CEIL,
  });

  node.querySelector("#next").addEventListener("click", () => go(3));
  return node;
};

// ---------- screen 3 · את מסוגלת (issue #82) ----------
// The kabbalah as it now stands, in §7.2's own approved sentence, with a way
// back into it; the mode; the reminder hour; and one line of encouragement
// before the last button.
STEPS[3] = () => {
  const modeCard = (value, title, note) => `
    <button type="button" class="mode-card${answers.mode === value ? " on" : ""}"
            role="radio" aria-checked="${answers.mode === value}" data-mode="${value}">
      <span class="mode-title">${title}</span>
      <span class="mode-note">${note}</span>
    </button>`;

  // B4 (2026-08-21, Sara: "מעוצב יפה, שיהיה בצורה של שורה שורה ברור, ויתן לך
  // הזמן בשבוע וביום בצורה של שעון כמה זמן חוזר אליך") — the give-back
  // framing B2 moved off screen 2 lands here, as its own card: one line for
  // the day, one for the week, each a plain clock-style number rather than
  // a sentence to parse, the same typographic family the dial's own clock
  // reading already uses (§3.5, .dial-clock). ${clock} is DESIGN.md §5's
  // own dir="ltr" convention for a time value; "ביום"/"בשבוע" are not new
  // words — both already appear verbatim in totalSaveLine and
  // COPY.giveBackWeekly, immediately above and below this card.
  //
  // C3 (2026-08-21, Sara's report): "שהסיכום יהיה בצבע הרבה יותר יפה" — she
  // read the card as a plain table, one purple number twice over. The
  // "week" class below is the only markup change; the actual colour
  // decision (why --pink-ink and not a new hex, why the card's own
  // background stays --surface rather than a tinted gradient) lives in
  // onboarding.css, right above .give-summary, with the exact contrast
  // numbers that ruled each option in or out.
  const dailyBack = totalGiveBack(answers);
  const weeklyBack = weeklyGiveBackHours(dailyBack);

  const node = html(`
    <div class="h3">${COPY.step3Title}</div>
    <div class="badge-success">${totalSaveLine(answers)}</div>
    <div class="card give-summary">
      <div class="give-summary-row">
        <span class="give-summary-label">ביום</span>
        <span class="give-summary-clock" dir="ltr">${clock(dailyBack)}</span>
      </div>
      <div class="give-summary-row">
        <span class="give-summary-label">בשבוע</span>
        <span class="give-summary-clock week" dir="ltr">${weeklyBack}</span>
        <span class="give-summary-unit">שעות</span>
      </div>
    </div>
    <div class="card">
      <div class="lead summary">${summaryLine(answers)}</div>
      <button type="button" class="btn-link" id="change">${COPY.change}</button>
    </div>
    <div class="card-title">${COPY.modeQuestion}</div>
    <div class="modes" role="radiogroup" aria-label="${COPY.modeQuestion}">
      ${modeCard("companion", COPY.modeCompanion, COPY.modeCompanionNote)}
      ${modeCard("commitment", COPY.modeCommitment, COPY.modeCommitmentNote)}
    </div>
    <div class="fine">${COPY.modeNote}</div>
    <div class="reminder">
      <span>${COPY.reminder}</span>
      <div class="stepper big">
        <button type="button" class="stepper-btn big" data-hour="-" aria-label="${COPY.reminder}">−</button>
        <div class="stepper-value big" dir="ltr">${quietHourLabel(answers.hour)}</div>
        <button type="button" class="stepper-btn big" data-hour="+" aria-label="${COPY.reminder}">+</button>
      </div>
    </div>
    <div class="step-footer">
      <div class="encourage">${COPY.encourage}</div>
      <!-- B5 (2026-08-21, Sara's decision): "להתחיל קטן יותר" sat right
           here, next to #finish. Sara first read it as a duplicate; it
           technically was not (easedPlaces() below took one step off every
           place's give-back before finishing) — but a woman can produce
           that exact outcome herself by moving screen 2's own sliders, so
           it was a duplicate in the one sense that matters: nothing on the
           screen ever explained the difference. Removed rather than
           relabelled. See easedPlaces()'s own comment in
           onboarding-model.js. -->
      <div class="actions">
        <!-- B_ZERO (2026-08-21, Sara's decision): splitting the two floors
             (onboarding-model.js, limitFromRawTarget) does not by itself
             stop her from setting every place's target equal to what she
             spends — a plan that gives back nothing, on purpose this time,
             not by the old bug's accident. The house rule is that an
             unavailable action disappears rather than being disabled
             (popup.js's showResetConfirm), and finishing an onboarding built
             around "what you get back" onto a bottom line that would have
             to read zero minutes is the same failure this whole change
             exists to fix. So #finish only renders once totalGiveBack has
             something in it; COPY.noGiveBackNote (UNAPPROVED — see its own
             comment in onboarding-model.js) takes its place otherwise, and
             "לשנות" two cards up is already the way back to the sliders that
             would change it. -->
        ${
          dailyBack > 0
            ? `<button type="button" class="btn-primary md" id="finish">${COPY.finish}</button>`
            : `<p class="fine no-give-back">${COPY.noGiveBackNote}</p>`
        }
      </div>
    </div>
  `);

  node.querySelectorAll("[data-mode]").forEach((btn) =>
    btn.addEventListener("click", () => {
      answers.mode = btn.dataset.mode;
      render();
      saveDraftSoon();
    })
  );

  // "the summary of the kabbalah with the ability to change it" — the way
  // back is the beginning of it, not a second editor: everything on screens
  // 1 and 2 is two clicks from here and she arrives with every answer still
  // in place.
  node.querySelector("#change").addEventListener("click", () => go(1));

  // The prototype's bounds, on the quarter-hour grid the quiet-hours
  // control above now uses (Sara, 2026-08-23). Mirrored in dashboard.js,
  // which carries the long comment on why the ceiling is the last quarter
  // before midnight rather than midnight itself: a reminder is a moment,
  // not a range, and there is no moment "24:00" on a wall clock.
  // issue 142: no floor. Sara's call. See background.js's herHourHasPassed,
  // which had to learn about hours inside the day's tail before this number
  // could safely go below DAY_RESET_HOUR.
  const REMINDER_FLOOR = 0;
  const REMINDER_CEIL = 23.75;
  const REMINDER_STEP = 0.25;
  node.querySelectorAll("[data-hour]").forEach((btn) =>
    btn.addEventListener("click", () => {
      answers.hour =
        btn.dataset.hour === "+"
          ? Math.min(REMINDER_CEIL, answers.hour + REMINDER_STEP)
          : Math.max(REMINDER_FLOOR, answers.hour - REMINDER_STEP);
      render();
      saveDraftSoon();
    })
  );

  // Optional-chained the same way #add-place already is (STEPS[1]) — the
  // button does not exist on screen at all while totalGiveBack is zero.
  node.querySelector("#finish")?.addEventListener("click", () => finishOnboarding());
  return node;
};

// ---------- writing it down ----------

// Her first kabbalah is created; a later run in the default (no query
// string) intent edits the primary one instead of adding a second, and
// never touches the streak — only a fall does that. Issue #20 adds the two
// other intents beside this one, unchanged.
async function saveKabbalah() {
  const places = placesFrom(answers);
  // A kabbalah with no places watches nothing and breaks everything. This
  // cannot be reached from the UI (screen 1 hides its button until a place
  // exists) — it is the belt behind that brace.
  if (!places.length) {
    go(1);
    return false;
  }

  const { kabbalot = [] } = await storeGet("kabbalot");

  if (intent.kind === "new") {
    // Always appended, never touches an existing entry — this is the one
    // path in the whole product that can leave with two kabbalot. See
    // docs/data-model.md §20 and the report for why this used to not exist.
    const fresh = buildKabbalah(answers, {
      id: `k_${crypto.randomUUID()}`,
      today: dateStr(),
    });
    await storeSet({ kabbalot: [...kabbalot, fresh] });
  } else if (intent.kind === "edit-id") {
    const k = kabbalot.find((x) => x.id === intent.targetId);
    const fresh = buildKabbalah(answers, {
      id: intent.targetId,
      today: dateStr(),
    });
    if (k) {
      // mode is deliberately left untouched here — see
      // answersFromKabbalah()'s own comment in onboarding-model.js. Changing
      // it belongs to the dashboard's settings screen alone, which is the
      // only place that knows to route a switch into commitment through
      // pendingMode instead of writing it on the spot.
      k.name = fresh.name;
      // Important 4: carries the flag forward too, or a name regenerated
      // this round (she left the field blank because it was already
      // generated) would silently lose the "generated" marker and freeze
      // on THIS place forever, the next time she edits it again.
      k.nameIsGenerated = fresh.nameIsGenerated;
      k.rule = fresh.rule;
      k.places = fresh.places;
      k.placeGoals = fresh.placeGoals;
      k.baselineMinutes = fresh.baselineMinutes;
      await storeSet({ kabbalot });
    } else {
      // The target vanished between the dashboard's own check and this
      // click (another tab, another device sharing this profile). Her
      // answers are not thrown away for that — they become a new kabbalah
      // rather than silently disappearing.
      await storeSet({ kabbalot: [...kabbalot, { ...fresh, mode: "companion" }] });
    }
  } else if (kabbalot[0]) {
    const fresh = buildKabbalah(answers, { id: kabbalot[0].id, today: dateStr() });
    const k = kabbalot[0];
    // Fix 5 (2026-08-21): this is the one branch (the plain default,
    // no-query intent) that still never shows the nickname field — see
    // STEPS[1] above — so `fresh.name` is unconditionally nameFrom()'s
    // fallback, "המקום שלי", here. Overwriting k.name with it on every edit
    // would quietly erase whatever real name this kabbalah already has (one
    // she typed through `?new=1`/`?edit=<id>` before this default-path edit,
    // or one a future flow sets) the moment she so much as adjusts a link.
    // Only a genuinely typed customName replaces the name she already has;
    // an edit through this branch supplies none — there is no field here to
    // supply one — so it always leaves the name exactly as it was.
    if ((answers.customName || "").trim()) k.name = fresh.name;
    k.rule = fresh.rule;
    k.places = fresh.places;
    k.placeGoals = fresh.placeGoals;
    k.baselineMinutes = fresh.baselineMinutes;
    k.mode = fresh.mode;
    await storeSet({ kabbalot });
  } else {
    const fresh = buildKabbalah(answers, { id: `k_${crypto.randomUUID()}`, today: dateStr() });
    await storeSet({ kabbalot: [fresh] });
  }

  const updates = {};
  // Local only, never synced — the same promise the field makes on screen.
  if (answers.note?.trim()) updates.kabbalahNote = answers.note.trim();
  updates.reminderHour = answers.hour;
  // Sara: "אני גם רוצה שהוא ישאל לשם שלי." Stored under its own key so that
  // every screen the character speaks on can reach it. Written as an empty
  // string when she skipped the field rather than left out — a screen asking
  // "do I know her name" should get a plain answer, not the difference
  // between undefined and "".
  updates.userName = herNameFrom(answers);

  const window_ = quietWindowFrom(answers);
  if (window_) {
    const { quietWindows = [] } = await storeGet("quietWindows");
    updates.quietWindows = [...quietWindows, window_];
  }
  await storeSet(updates);
  return true;
}

async function finishOnboarding() {
  if (!(await saveKabbalah())) return;
  // Only once it is safely stored: clearing the draft empties the answers it
  // was built from.
  const done = { ...answers };
  await clearDraft();
  answers = done;
  step = 4;
  render();
}

// ---------- the done screen (§6.1) ----------
// B6 (2026-08-21): this used to end on "restart" — wipe everything she just
// decided, go back to screen 0 — the one control on the one screen that
// follows a commitment, and it was an offer to discard it. It leads into
// the product now: a plain link to the dashboard (DASHBOARD_PATH, top of
// this file), a normal same-tab navigation, since this screen is already a
// tab and not a popup (this file's own header, above).
STEPS[4] = () => {
  const node = html(`
    <div class="h1-done">${COPY.doneTitle}</div>
    <div class="lead">${summaryLine(answers)}</div>
    <a class="btn-primary md" id="to-dashboard" href="${DASHBOARD_PATH}">${COPY.toDashboard}</a>
  `);
  return node;
};

// ---------- the draft ----------
// Getting the link means leaving this window. The onboarding is a tab now,
// so the window usually survives — but a tab can be closed, and this cost
// nothing to keep. Written on every keystroke and every choice, debounced so
// typing does not write a letter at a time.

let draftSaver = null;

async function saveDraft() {
  await storeSet({
    onboardingDraft: {
      step,
      answers,
      savedAt: Date.now(),
      // #20: which of the three intents this draft belongs to, so a later
      // reopening of this tab (or a fresh one, opened with a different
      // query string) never resumes the wrong one. See
      // docs/data-model.md's onboardingDraft entry.
      intent: intent.kind,
      targetId: intent.targetId ?? null,
    },
  });
}

function saveDraftSoon() {
  clearTimeout(draftSaver);
  draftSaver = setTimeout(saveDraft, 400);
}

async function clearDraft() {
  clearTimeout(draftSaver);
  answers = freshAnswers();
  await storeSet({ onboardingDraft: null });
}

document.addEventListener("DOMContentLoaded", async () => {
  const { onboardingDraft, kabbalot = [], userName, reminderHour } = await storeGet([
    "onboardingDraft",
    "kabbalot",
    "userName",
    "reminderHour",
  ]);
  // The model already refuses to resume a draft from a different evening —
  // it should not go on sitting on her disk once we have noticed that. This
  // is the only moment resumeTarget() itself distinguishes "too old" from
  // "no draft" / "an old build's shape", so the delete happens here rather
  // than inside the model (issue #39).
  if (draftIsStale(onboardingDraft)) {
    await storeSet({ onboardingDraft: null });
  }

  // #20: a draft is only ever resumed into the intent it was written for. A
  // draft with no `intent` field at all predates this build and is treated
  // as the default ("edit") — the shape every draft had before today, so a
  // tester mid-onboarding when this ships still lands exactly where she
  // would have.
  const draftIntent = onboardingDraft?.intent || "edit";
  const draftMatches =
    onboardingDraft &&
    draftIntent === intent.kind &&
    (intent.kind !== "edit-id" || onboardingDraft.targetId === intent.targetId);

  const target = draftMatches ? resumeTarget(onboardingDraft) : null;
  if (target) {
    answers = { ...freshAnswers(), ...target.answers };
    step = target.step;
  } else if (intent.kind === "new") {
    // The shortened onboarding (§8 decision 3, the issue's own words): she
    // has already met screen 0 once, so this starts on screen 1 with her
    // own name already in place.
    answers = { ...freshAnswers(), herName: (userName || "").slice(0, 24), hour: Number.isFinite(reminderHour) ? reminderHour : 20 };
    step = 1;
  } else if (intent.kind === "edit-id") {
    const k = kabbalot.find((x) => x.id === intent.targetId);
    if (k && canEditPlacesViaOnboarding(k)) {
      answers = answersFromKabbalah(k, { userName, reminderHour });
      step = 1;
    } else {
      // A stale link (the kabbalah is gone) or one this screen cannot edit
      // safely (onboarding-model.js's own guard) — falls back to the one
      // path that can never lose data rather than guessing.
      intent = { kind: "edit" };
      answers = freshAnswers();
      step = 0;
    }
  }
  render();
});
