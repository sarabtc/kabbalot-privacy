// קשה לי עכשיו — the local chat engine (issue #17).
//
// Nothing here touches the DOM or `chrome`, and nothing here hardcodes a
// word of the character's copy: every message is read out of
// docs/messages.md by parseMessageBank() below, so a voice pass on that
// document (wording, emoji, punctuation) flows through without touching this
// file. This module owns the *shape* of the conversation and the selection
// rule — never the words.
//
// parseMessageBank() has no filesystem access itself (it takes the
// document's text as a string), which keeps it usable from Node (tests, and
// later a small build step or a fetch() of a bundled copy of the doc) and
// from a browser context alike.
//
// The selection algorithm and the placeholder table below are transcribed
// from docs/messages.md's "מפרט למנוע" section. That section is the
// specification; see the module-level comments marked ⚑ for the places it
// left a choice unmade, and the report this module shipped with for the
// full list.

// ---------------------------------------------------------------------------
// Reading the bank: group 1, "קשה לי עכשיו"
// ---------------------------------------------------------------------------
// The document lays group 1 out as one "### תור N" subsection per turn (each
// holding its own **ID** ... text blocks) followed by one "### סגירה"
// subsection for the closer. Reading the *number* of turn subsections off
// the document — rather than assuming three — means ⚑3 (the message bank
// currently builds three real turns and closes on the fourth; the prototype
// code instead closes on the third) landing either way later is a change to
// docs/messages.md alone: if a future edit removes the "### תור 3" heading,
// this module drops to two real turns on its own, no code change required.

/**
 * Parse the "קשה לי עכשיו" message bank out of docs/messages.md's own text.
 * @param {string} markdown the full contents of docs/messages.md
 * @returns {{
 *   turns: Record<string,string>[],
 *   closing: Record<string,string>,
 *   closingDefaultRange: {from:string, to:string} | null,
 *   valve: ReturnType<typeof parseValveBank>,
 * }}
 */
export function parseMessageBank(markdown) {
  const groupMatch = markdown.match(/## קבוצה 1[\s\S]*?(?=\n## קבוצה 2)/);
  if (!groupMatch) {
    throw new Error('chat-engine: could not find "## קבוצה 1" (קשה לי עכשיו) in the message bank');
  }
  const section = groupMatch[0];

  // Locate every "### תור N" / "### סגירה" subsection, in document order.
  const headingRe = /###\s+(תור \d+|סגירה)\n/g;
  const marks = [];
  let m;
  while ((m = headingRe.exec(section))) {
    marks.push({ label: m[1], headingStart: m.index, bodyStart: headingRe.lastIndex });
  }
  for (let i = 0; i < marks.length; i++) {
    const bodyEnd = i + 1 < marks.length ? marks[i + 1].headingStart : section.length;
    marks[i].body = section.slice(marks[i].bodyStart, bodyEnd);
  }

  const turns = [];
  let closing = {};
  let closingRaw = "";
  for (const mark of marks) {
    if (mark.label === "סגירה") {
      closing = parseMessageBlocks(mark.body);
      closingRaw = mark.body;
    } else {
      const messages = parseMessageBlocks(mark.body);
      if (Object.keys(messages).length > 0) turns.push(messages);
    }
  }

  return {
    turns,
    closing,
    closingDefaultRange: parseClosingDefaultRange(closingRaw),
    valve: parseValveBank(markdown),
  };
}

// One subsection's body -> { "H-01": "line one\nline two", ... }, in the
// order the ids appear. A block is an "**ID** ..." line followed by its
// message-text lines, up to a blank line or the next "**ID**" line.
// Annotation lines wrapped in single asterisks (e.g. the note under C-01
// about its own default eligibility) are commentary, not message text, and
// are skipped rather than appended.
function parseMessageBlocks(body) {
  const messages = {};
  let currentId = null;
  let currentLines = [];
  const flush = () => {
    if (currentId) messages[currentId] = currentLines.join("\n").trim();
    currentId = null;
    currentLines = [];
  };
  for (const rawLine of body.split("\n")) {
    const line = rawLine.trim();
    const idMatch = line.match(/^\*\*([A-Z]-\d+)\*\*/);
    if (idMatch) {
      flush();
      currentId = idMatch[1];
      continue;
    }
    if (!currentId) continue;
    if (line === "") {
      flush();
      continue;
    }
    if (/^\*[^*].*\*$/.test(line)) continue; // an italic-only annotation line
    currentLines.push(line);
  }
  flush();
  return messages;
}

// ⚑9 (docs/messages.md, "להכרעת שרה"): C-01 asks a question in the same
// breath the chat's input closes, and the document sets an explicit interim
// default while that stands undecided: "עד להכרעה, ברירת המחדל היא `C-02`
// עד `C-04`." This reads that sentence directly, rather than hardcoding
// which id is excluded — so if the sentence's own range changes (or the
// note is removed once ⚑9 is settled), eligibleClosingIds() below follows
// without a code change. Finding no such sentence is read as "no
// restriction documented" and every closing message is offered.
function parseClosingDefaultRange(rawClosingBody) {
  const m = rawClosingBody.match(/ברירת המחדל היא\s+`([A-Z]-\d+)`\s+עד\s+`([A-Z]-\d+)`/);
  return m ? { from: m[1], to: m[2] } : null;
}

// ---------------------------------------------------------------------------
// Reading the bank: group 8, "שסתום היום הקשה" (issue #87)
// ---------------------------------------------------------------------------
// Group 8 is laid out as one "### רגע N · …" subsection per moment, each
// holding two or three *proposals* as blockquotes ("> **הצעה 1א׳ (… ·
// טרם אושרה):**" and the lines under it) — none approved, no ids assigned
// (the document reserves ids for approval). So the document itself names
// the one proposal that is wired, in a marker line under each moment:
//
//   **בקוד (טיוטה): 1א׳**
//
// This reads that line, then the blockquote it points at: message lines,
// a "**[button]**" line if the proposal carries one, and a field
// placeholder written the way the document writes it ("הטקסט האפור בשדה:
// …"). A proposal whose header still says "טרם אושרה" is flagged
// `draft: true`; approval is deleting those two words and rebuilding, and
// swapping proposals is editing the marker line — both without touching
// code. Moments are keyed by the role the screens know them by, below,
// not by their number, so renumbering the document is not a code change
// either.
export const VALVE_MOMENTS = {
  1: "offer",     // the character hands it over, at the close of a returned-to chat
  2: "waiting",   // the ten minutes
  3: "ready",     // she is back and it is waiting
  4: "released",  // the day is released
  5: "immediate", // third return the same day — no chat
  6: "note",      // the optional free text
  7: "morning",   // the morning after a released day
  8: "export",    // her data: the export line
};

/**
 * @param {string} markdown the full contents of docs/messages.md
 * @returns {{ draft: boolean, moments: Record<string, {label:string, draft:boolean, text:string, button:string|null, placeholder:string|null}> }}
 */
export function parseValveBank(markdown) {
  const groupMatch = markdown.match(/^## קבוצה 8[\s\S]*?(?=\n## סיכום כמותי)/m);
  if (!groupMatch) {
    throw new Error('chat-engine: could not find "## קבוצה 8" (שסתום היום הקשה) in the message bank');
  }
  const section = groupMatch[0];

  const headingRe = /###\s+רגע (\d+)\s*·[^\n]*\n/g;
  const marks = [];
  let m;
  while ((m = headingRe.exec(section))) {
    marks.push({ n: Number(m[1]), headingStart: m.index, bodyStart: headingRe.lastIndex });
  }

  const moments = {};
  let draft = false;
  marks.forEach((mark, i) => {
    const bodyEnd = i + 1 < marks.length ? marks[i + 1].headingStart : section.length;
    const key = VALVE_MOMENTS[mark.n];
    if (!key) return;
    const parsed = parseValveMoment(section.slice(mark.bodyStart, bodyEnd), mark.n);
    if (!parsed) return;
    moments[key] = parsed;
    if (parsed.draft) draft = true;
  });

  // Group 8 defines exactly one variable today — {{ימים_ששוחררו}}, רגע 8's
  // export line (docs/messages.md's variable table). Any other {{...}}
  // token surviving into the wired copy is either a leftover from a
  // proposal that still names a kabbalah (⚑13, which the document requires
  // gone) or a typo the document never declared as a variable, so this
  // fails the build the same way a missing proposal does above — loudly,
  // and naming the moment — rather than shipping an unrenderable token to
  // the popup silently.
  const ALLOWED_VARIABLES = new Set(["{{ימים_ששוחררו}}"]);
  for (const [key, moment] of Object.entries(moments)) {
    const haystack = `${moment.text}${moment.button || ""}${moment.placeholder || ""}`;
    for (const found of haystack.matchAll(/\{\{[^}]+\}\}/g)) {
      if (!ALLOWED_VARIABLES.has(found[0])) {
        throw new Error(
          `chat-engine: valve moment "${key}" uses ${found[0]}, which is not in group 8's variable whitelist ` +
            `(${[...ALLOWED_VARIABLES].join(", ")}) — either the copy still names something ⚑13 requires gone, ` +
            `or docs/messages.md's variable table needs this token added`
        );
      }
    }
  }

  return { draft, moments };
}

// One moment's body -> the proposal its marker line names, or null when the
// moment has no marker (a moment the document has not wired yet).
function parseValveMoment(body, momentNumber) {
  const markerRe = /^\*\*בקוד \(טיוטה\): (\S+)\*\*$/gm;
  const markers = [...body.matchAll(markerRe)];
  if (markers.length === 0) return null;
  if (markers.length > 1) {
    throw new Error(
      `chat-engine: רגע ${momentNumber} has ${markers.length} "בקוד (טיוטה)" marker lines — exactly one is allowed per moment`
    );
  }
  const label = markers[0][1];
  const lines = body.split("\n");
  const headIdx = lines.findIndex((l) => l.startsWith(`> **הצעה ${label} (`));
  if (headIdx === -1) {
    throw new Error(
      `chat-engine: רגע ${momentNumber} names proposal ${label} in its "בקוד" line, but no such proposal exists`
    );
  }
  const draft = /טרם אושרה/.test(lines[headIdx]);

  const text = [];
  let button = null;
  let placeholder = null;
  for (let i = headIdx + 1; i < lines.length; i++) {
    const raw = lines[i];
    if (!raw.startsWith(">")) break;
    const line = raw.replace(/^>\s?/, "").trim();
    if (line === "") break; // the blank quote line before the italic annotation
    const btn = line.match(/^\*\*\[(.+?)\]\*\*$/);
    if (btn) {
      button = btn[1];
      continue;
    }
    const ph = line.match(/הטקסט האפור בשדה: (.+?)\)\*$/);
    if (ph) {
      placeholder = ph[1];
      continue;
    }
    if (/^\*[^*].*\*$/.test(line)) continue; // an italic-only annotation line
    text.push(line);
  }

  // A moment can carry its button outside the proposals, once for all of
  // them ("**הכפתור עצמו (טרם אושר):** **[…]**" under רגע 3).
  if (!button) {
    const shared = body.match(/^\*\*הכפתור עצמו[^\n]*?:\*\*\s*\*\*\[(.+?)\]\*\*/m);
    if (shared) button = shared[1];
  }

  return { label, draft, text: text.join("\n"), button, placeholder };
}

/** All closing ids the bank defines, offered or not. */
export function closingPoolIds(bank) {
  return Object.keys(bank.closing);
}

/** The closing ids eligible to be picked *right now*, per the default range
 * docs/messages.md documents for ⚑9 (see parseClosingDefaultRange above). */
export function eligibleClosingIds(bank) {
  const ids = closingPoolIds(bank);
  if (!bank.closingDefaultRange) return ids;
  const { from, to } = bank.closingDefaultRange;
  const start = ids.indexOf(from);
  const end = ids.indexOf(to);
  if (start === -1 || end === -1) return ids; // the named ids moved or vanished — fail open
  return ids.slice(start, end + 1);
}

function textFor(bank, id) {
  for (const turn of bank.turns) if (id in turn) return turn[id];
  return bank.closing[id];
}

// ---------------------------------------------------------------------------
// Selection: "בחירה בלי חזרות" (docs/messages.md, מפרט למנוע)
// ---------------------------------------------------------------------------
//   מועמדות = מאגר פחות מה שכבר נאמר בשיחה הנוכחית פחות ההיסטוריה המקומית
//   אם מועמדות ריקה: מנקים את ההיסטוריה של המאגר ומחשבים שוב
//   בוחרים אקראית מהמועמדות
//   דוחפים את המזהה להיסטוריה, וגוזמים אותה ל(גודל המאגר פחות 1)
//
// The window is (pool size - 1), not a fixed number — a fixed window of 5
// against a 4-message pool (turn 3) would empty it outright (the spec calls
// this out by name). Because the window is always one short of the full
// pool, history alone can never account for every id: at least one candidate
// always survives it. The only way to reach an empty `candidates` is for
// *this conversation's* used-ids to also cover part of the pool — the same
// pool asked twice in one conversation. group 1's turn-based shape never
// does that on its own, but the primitive below implements the documented
// algorithm generally, exactly as written, rather than assuming away the
// branch it names.
function pickFromPool(pool, poolHistory, usedInConversation, rng) {
  const excluded = new Set([...usedInConversation, ...poolHistory]);
  let candidates = pool.filter((id) => !excluded.has(id));
  let historyToKeep = poolHistory;

  if (candidates.length === 0) {
    // מנקים את ההיסטוריה של המאגר ומחשבים שוב — clear *this pool's* history
    // only (not what has already been said in the conversation) and retry.
    historyToKeep = [];
    candidates = pool.filter((id) => !usedInConversation.includes(id));
    if (candidates.length === 0) {
      // Every message in the pool has already been used in this very
      // conversation; there is nothing left to say without repeating. The
      // spec's fallback does not cover this — it only clears the pool's
      // cross-conversation history, which cannot itself cause this.
      throw new Error(
        "chat-engine: pool exhausted — every message already used in this conversation"
      );
    }
  }

  const id = candidates[Math.floor(rng() * candidates.length)];
  const window = Math.max(pool.length - 1, 0);
  const history = [...historyToKeep, id].slice(-window);
  return { id, history };
}

// ---------------------------------------------------------------------------
// Conversation state
// ---------------------------------------------------------------------------
// `state` is one conversation: which turn it is on, every id already used in
// it (so a repeat within the conversation is structurally impossible), and
// whether it has closed. `poolHistory` is the recent-history lists for each
// pool (turn1, turn2, …, closing) — persisted across conversations (and, per
// the spec, across browser restarts) so repeat opens on the same day do not
// resurface the same lines. Both are plain JSON; storing and loading them,
// like loading the bank itself, is the caller's job.

export function createConversationState() {
  return { turn: 0, usedIds: [], closed: false };
}

/** Starts empty; each pool's key is added the first time it is drawn from,
 * so this needs no knowledge of how many turns the bank currently has. */
export function createPoolHistory() {
  return {};
}

/**
 * Advance the conversation by exactly one assistant message: the opening
 * line (turn 1, called with a freshly-created state, before she has typed
 * anything) counts as the first of the real turns, matching how
 * "קשה לי עכשיו" already opens with a line rather than a blank input. Each
 * subsequent call is the reply to her next message, until the bank's real
 * turns are spent, after which the next call returns a closing line and
 * `state.closed` becomes true.
 *
 * @param {ReturnType<typeof parseMessageBank>} bank
 * @param {{turn:number, usedIds:string[], closed:boolean}} state
 * @param {Record<string,string[]>} poolHistory
 * @param {{rng?: () => number}} [options] rng defaults to Math.random; pass a
 *   fixed one in tests for a deterministic pick.
 */
export function advanceConversation(bank, state, poolHistory, { rng = Math.random } = {}) {
  if (state.closed) {
    throw new Error("chat-engine: conversation is already closed");
  }
  const nextTurn = state.turn + 1;
  const isClosing = nextTurn > bank.turns.length;
  const poolKey = isClosing ? "closing" : `turn${nextTurn}`;
  const pool = isClosing ? eligibleClosingIds(bank) : Object.keys(bank.turns[nextTurn - 1]);

  const { id, history } = pickFromPool(pool, poolHistory[poolKey] ?? [], state.usedIds, rng);

  return {
    id,
    text: textFor(bank, id),
    state: {
      turn: isClosing ? state.turn : nextTurn,
      usedIds: [...state.usedIds, id],
      closed: isClosing,
    },
    poolHistory: { ...poolHistory, [poolKey]: history },
  };
}

// ---------------------------------------------------------------------------
// Placeholders — docs/messages.md "טבלת המשתנים"
// ---------------------------------------------------------------------------
// None of group 1's messages use a single {{...}} token — it was written as
// whole, static lines on purpose (⚑4: composing ack + pick would double the
// containment beat). The variable table, though, is written for the whole
// message bank (check-ins, the morning after a fall, week transitions, the
// stop page, notifications) and is part of "מפרט למנוע", the section this
// build was told to follow. These are exported as small, independently-
// tested pure functions — not wired into advanceConversation above, and not
// a message-selection engine for those other groups (that is each of those
// issues' own scope) — so that:
//   (a) the empty-case and singular/plural rules the spec calls out by name
//       are built and verified now, next to the spec itself, and
//   (b) if a message in *this* bank later gains a token (e.g. a mentor name,
//       ⚑5, still awaiting Sara's decision and — per the product decision
//       that landed while this module was built — carrying no emoji of its
//       own either way), wiring it in is an edit to the message text plus a
//       renderTemplate() call, not new code.
//
// The words baked in here (ממשיכה / ממשיכות, the ״…״ quoting, ", " and " ו",
// "ועוד") are not message-bank copy — they are the variable table's own
// grammar rules, specified in docs/messages.md's engine section itself
// rather than in any message a voice pass would revise, and they carry no
// emoji. Nothing else in this module hardcodes anything the message bank
// says.

export const placeholders = {
  /** {{שם}} / {{שם2}} — always quoted by the caller's template; truncated to
   * 24 characters and then "…". A name is a required field (מקרה ריק: לא
   * ייתכן) so there is no empty case to handle here. */
  truncateName(name) {
    const s = String(name);
    return s.length > 24 ? `${s.slice(0, 24)}…` : s;
  },

  /** הטיית הפועל אחרי {{קבלות_עומדות}} — one surviving kabbalah takes
   * "ממשיכה", two or more take "ממשיכות". */
  verbForSurvivingCount(n) {
    return n === 1 ? "ממשיכה" : "ממשיכות";
  },

  /** {{קבלות_עומדות}} — the kabbalot that did not break yesterday, one call
   * per kabbalah's own name (never a count computed across kabbalot as one
   * global figure — decision 3, "kabbalot are independent"). Formats as
   * ״א״, ״ב״ ו״ג״ for up to three names; beyond that, three names and then
   * "ועוד {k}". Empty list: returns null — per the table the *message* is
   * not rendered at all, and the caller falls back to M-01. */
  formatSurvivingKabbalot(names) {
    if (!names || names.length === 0) return null;
    const quoted = names.map((n) => `״${placeholders.truncateName(n)}״`);
    if (quoted.length === 1) return quoted[0];
    if (quoted.length <= 3) {
      const last = quoted[quoted.length - 1];
      const rest = quoted.slice(0, -1).join(", ");
      return `${rest} ו${last}`;
    }
    const shown = quoted.slice(0, 3).join(", ");
    const remaining = quoted.length - 3;
    return `${shown} ועוד ${remaining}`;
  },

  /** {{ימים}} — streak length in one named kabbalah. Below 2, the row that
   * carries it is not rendered at all. */
  shouldRenderStreakDays(days) {
    return days >= 2;
  },

  /** {{דקות}} — minutes returned today. Below 1, the row is not rendered. */
  shouldRenderMinutes(minutes) {
    return minutes >= 1;
  },

  /** {{שעות}} — hours returned this week, one decimal place. Below 0.5, the
   * row is not rendered. */
  shouldRenderHours(hours) {
    return hours >= 0.5;
  },
  formatHours(hours) {
    return hours.toFixed(1);
  },

  /** {{יעד}} / {{יעד_חדש}} / {{נותר}} / {{מכסה}} — a clock reading, H:MM,
   * minutes zero-padded. */
  formatClock(totalMinutes) {
    const h = Math.floor(totalMinutes / 60);
    const m = totalMinutes % 60;
    return `${h}:${String(m).padStart(2, "0")}`;
  },

  /** {{יום}} — a weekday name only, never a numeric date. */
  weekdayName(date) {
    const names = [
      "יום ראשון",
      "יום שני",
      "יום שלישי",
      "יום רביעי",
      "יום חמישי",
      "יום שישי",
      "שבת",
    ];
    return names[date.getDay()];
  },

  /** {{הארכות_לפני}} — graces left *before* this one is used. At 0, the
   * table says B-C-07 is shown in place of the button. */
  gracesBeforeDisplay(gracesLeftBefore) {
    return gracesLeftBefore === 0
      ? { show: "fallback", fallbackId: "B-C-07" }
      : { show: "button", value: gracesLeftBefore };
  },

  /** {{הארכות_אחרי}} — graces left *after* this one is used. At 0, the
   * table says G-04 is shown. `{{הארכות_לפני}}` and `{{הארכות_אחרי}}` are
   * deliberately two separate inputs (docs/messages.md is explicit: "זה
   * ההבדל בין 'נשארו 2' לפני הלחיצה ובין 'נשארו 2' אחריה") — this module
   * never derives one from the other. */
  gracesAfterDisplay(gracesLeftAfter) {
    return gracesLeftAfter === 0
      ? { show: "fallback", fallbackId: "G-04" }
      : { show: "value", value: gracesLeftAfter };
  },
};

/** Generic {{token}} substitution, so a future edit to a message's text
 * (adding a token that does not exist in group 1 today) is a data change to
 * docs/messages.md plus a call here — not new engine code. Unknown or
 * missing keys resolve to "" rather than throwing, since the render-or-not
 * decision for a missing value belongs to the empty-case helpers above, not
 * to this function. */
export function renderTemplate(text, vars) {
  return text.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (_, key) => {
    const v = vars ? vars[key] : undefined;
    return v == null ? "" : String(v);
  });
}

// ---------------------------------------------------------------------------
// The integration point left for popup.js
// ---------------------------------------------------------------------------
// askOra() in popup.js (line ~1335) currently returns `{ reply: null }` as a
// placeholder. It is expected to become roughly:
//
//   import { parseMessageBank, advanceConversation, createConversationState,
//     createPoolHistory } from "./chat-engine.js";
//   // + `<script type="module">` on popup.html's script tag, since this
//   //   file is a plain ES module and popup.js is not one today.
//
//   // The bank itself has to reach the popup somehow — this module only
//   // parses text, it does not fetch it. docs/messages.md is not shipped in
//   // extension/ today; whoever wires this needs either a small build step
//   // that turns it into a bundled JSON/JS asset, or a
//   // web_accessible_resources entry so the popup can fetch() the raw file
//   // at runtime and hand its text to parseMessageBank() once, e.g. into a
//   // module-level `let bank` set on DOMContentLoaded.
//
//   // conversationState and poolHistory are read from chrome.storage.local
//   // at showConversation() and written back after every advanceConversation
//   // call — poolHistory under a key of its own, so it survives browser
//   // restarts as the spec requires; conversationState only needs to live
//   // as long as the open chat panel (a JS closure is enough, as it already
//   // is for `history` in showConversation()).
//
//   async function askOra() {
//     const { id, text, state, poolHistory } =
//       advanceConversation(bank, conversationState, poolHistory);
//     conversationState = state;
//     await storeSet({ chatPoolHistory: poolHistory });
//     if (state.closed) { /* disable the input, per DESIGN.md §6.2 */ }
//     return { reply: text };
//   }
//
// This module does not touch popup.js — a sibling branch is rewriting its
// screens — so the wiring above is not applied here.
