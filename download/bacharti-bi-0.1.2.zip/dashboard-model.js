// בחרתי בי — dashboard-model.js: everything the dashboard computes, with no
// DOM and no chrome in sight — the same split onboarding-model.js and
// morning-after-model.js already use, so all of it can be run and checked
// by a plain node script. dashboard.js is a thin renderer over this file.
//
// Issue #20's spec, and where each piece of it lives below:
//   · an overview across every kabbalah            → overviewStats
//   · a weekly standing percentage, framed positively ("87% עמידה")
//                                                  → weeklyStandingPercent
//   · creating a second kabbalah, with a gentle
//     pause when the existing ones are young       → gentlePause
//   · settings: mode per kabbalah (next-day rule)  → requestModeChange
//               the week's own "להתקדם / להישאר"    → applyWeekChoice
//               (#30 wrote this choice down and
//               never built a reader for it — #20
//               is that reader)
//
// Issue #102's own additions (the 2a board's numbers), each pure and each
// tested the same way as the above:
//   · the "מצב היום" clock, remaining/used         → formatClock / remainingToday
//   · "השבוע החזרת לעצמך", Hebrew-phrased           → returnedThisWeekMinutes /
//                                                     formatReturnedHours
//   · the monthly success calendar                 → monthCalendar
//   · the suggestion card's own offer               → targetSuggestion
// (usageMinutesForDay and HEBREW_MONTHS are the small pieces those five are
// built from, not surfaces of their own.)
//
// Every date this file touches arrives as an already-computed "today"
// string — dateStr() from shared.js in the real page, frozenDateStr() from
// fixed-clock.mjs in tests. Nothing here calls `new Date()` on its own; see
// docs/data-model.md's own warning about DAY_RESET_HOUR and why a fourth
// copy of that constant is not worth adding to this file when every caller
// already has the string in hand.

// ---------- small date arithmetic, no DAY_RESET_HOUR knowledge here ----------

function parseDay(str) {
  const [y, m, d] = String(str).split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

function calendarDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// Positive or negative — a shift of -1 is "yesterday", +1 is "tomorrow".
// Every other date helper in this file is built out of this one, so a day
// this file needs to name is always named the same way.
function shiftDateStr(str, deltaDays) {
  const d = parseDay(str);
  return calendarDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() + deltaDays));
}

function daysAgoStr(todayStr, n) {
  return shiftDateStr(todayStr, -n);
}

function tomorrowStr(todayStr) {
  return shiftDateStr(todayStr, 1);
}

function daysBetween(fromStr, toStr) {
  if (!fromStr || !toStr) return 0;
  const ms = parseDay(toStr) - parseDay(fromStr);
  return Math.max(0, Math.round(ms / 86400000));
}

// ---------- statistics: per kabbalah, and the history a chart reads ----------

// A day is "kept" or "fell" only if the journal actually judged it —
// background.js's evaluatePastDays() never writes a day_success or a fall
// event for a day with no measured minute in it at all (it `continue`s
// straight past it, docs/data-model.md's own "מדולג לגמרי").
// So a skipped day does not need to be filtered out of a failure count —
// there is no category it was ever placed into that a statistic could read
// as a failure. That is the whole mechanism behind "no statistic may
// present a skipped day as a failed one."
function dayStatusMap(events, kabbalahId) {
  const out = {};
  for (const e of events || []) {
    if (e.kabbalahId !== kabbalahId) continue;
    const day = e.meta?.day;
    if (!day) continue;
    // issue #87 — a day she released herself: a third state, drawn apart
    // from a fall (dashboard.css) but counted against her week exactly
    // like one, because otherwise the streak and the percentage mean
    // nothing. popup.js writes the entry; background.js writes no `fall`
    // for that day.
    //
    // Precedence rule, made explicit rather than left to event order:
    // once a day is released, nothing else recorded for that day (a
    // day_success or fall, arriving before or after it in the array) may
    // unset that status. background.js never re-judges an already-released
    // day today, so this is not reachable through the app's own writers —
    // but nothing enforced it structurally until now.
    if (e.type === "released") {
      out[day] = "released";
      continue;
    }
    if (out[day] === "released") continue;
    if (e.type === "day_success") out[day] = "kept";
    else if (e.type === "fall") out[day] = "fell";
  }
  return out;
}

// The last `days` calendar days up to and including today, oldest first.
// `status` is one of "kept" / "fell" / "released" / "skipped" — "skipped"
// covers three genuinely different situations (a day the Shabbat arc
// swallowed whole, a marked holiday, a day before the kabbalah existed at
// all) that this file does not need to tell apart, because none of them is
// ever allowed to read as a failure. Note what is NOT on that list any
// more: יום שישי and מוצאי שבת are judged days now, and carry a real event
// either way (background.js).
function historyForKabbalah(events, k, todayStr, days = 14) {
  const statuses = dayStatusMap(events, k.id);
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const day = daysAgoStr(todayStr, i);
    if (k.createdAt && day < k.createdAt) {
      out.push({ day, status: "skipped" });
      continue;
    }
    out.push({ day, status: statuses[day] || "skipped" });
  }
  return out;
}

// The weekly standing percentage — issue #20's own example, "87% עמידה" —
// over the trailing 7 days including today, the same window
// export.js's weeklyReturnedMinutes already counts "this week" as. The
// denominator is judged days only (kept + fell); a week with nothing judged
// in it is not "0% עמידה", it is nothing to report yet — null — because a
// percentage with nothing real underneath it is not a positive number, it
// is a false one wearing a positive costume.
function weeklyStandingPercent(events, k, todayStr) {
  const judged = historyForKabbalah(events, k, todayStr, 7).filter(
    (d) => d.status !== "skipped"
  );
  if (!judged.length) return null;
  const kept = judged.filter((d) => d.status === "kept").length;
  return Math.round((kept / judged.length) * 100);
}

// The overview — pooled across every kabbalah's judged days, not an average
// of each one's own percentage. Pooling is the honest combination: a
// brand-new kabbalah with a single judged day would otherwise swing the
// headline number exactly as hard as a kabbalah with three weeks behind it,
// which is not what "her standing, overall" should mean.
function overviewStats(kabbalot, events, todayStr) {
  let judgedTotal = 0;
  let keptTotal = 0;
  let bestStreak = 0;
  let totalDaysKept = 0;
  for (const k of kabbalot) {
    const judged = historyForKabbalah(events, k, todayStr, 7).filter(
      (d) => d.status !== "skipped"
    );
    judgedTotal += judged.length;
    keptTotal += judged.filter((d) => d.status === "kept").length;
    bestStreak = Math.max(bestStreak, k.streak || 0);
    totalDaysKept += k.daysKept || 0;
  }
  return {
    count: kabbalot.length,
    weeklyPercent: judgedTotal ? Math.round((keptTotal / judgedTotal) * 100) : null,
    bestStreak,
    totalDaysKept,
  };
}

// ---------- creating a second kabbalah: the gentle pause ----------
//
// "אם הקבלות הקיימות צעירות משבוע — הדמות עוצרת בעדינות" (issue #20). Any
// one young kabbalah is enough to pause — the same gate docs/messages.md
// already uses for the *proactive* second-offer ("אם אחת צעירה משבוע,
// מציגים S-04"), reused here for the manual button because the underlying
// worry is the same either way: a second commitment before the first has
// had a week to prove it can hold is more likely to weaken both than
// strengthen either.
//
// Returns null when there is nothing to pause for — no kabbalah exists yet,
// or every one of them is at least a week old — and dashboard.js opens the
// onboarding tab straight away in that case. When it returns something,
// dashboard.js shows S-04 (naming the *youngest* kabbalah, the one the
// pause is actually about) and a way straight through — S-05 — that no
// state this function returns can block. See gentlePause's own caller in
// dashboard.js and the report.
const GENTLE_PAUSE_DAYS = 7;

function gentlePause(kabbalot, todayStr) {
  let youngest = null;
  for (const k of kabbalot || []) {
    const age = daysBetween(k.createdAt, todayStr);
    if (age < GENTLE_PAUSE_DAYS && (youngest === null || age < youngest.days)) {
      youngest = { kabbalahId: k.id, kabbalahName: k.name, days: age };
    }
  }
  return youngest;
}

// ---------- settings: mode per kabbalah — the one rule with teeth ----------
//
// "שינוי מצב למחויבות נכנס לתוקף רק למחר" (issue #20's own closing
// criterion). Entering commitment — the direction that strengthens what
// tomorrow's version of her will have to face — is staged through
// `pendingMode` and only actually takes hold once background.js's
// applyDuePendingModes() sees dateStr() reach `effectiveOn`, on some tick
// after the day has genuinely turned. Leaving commitment is written
// immediately: this product never locks her in behind a choice she wants
// to reverse (§1 principle 4) — the delay's whole job is to make sure a
// choice to lock herself *down* survives one full night before it starts
// holding her to anything, not to make either direction hard to reach.
//
// A kabbalah that is still "companion" with a pending switch to commitment,
// clicked "companion" on again, is not asking to leave anything — she was
// never in commitment yet — so that reads as cancelling the pending switch,
// not as a same-day exit needing its own protection.
function requestModeChange(k, targetMode, todayStr) {
  if (targetMode !== "companion" && targetMode !== "commitment") return null;

  if (targetMode === k.mode) {
    if (k.pendingMode && k.pendingMode.mode !== targetMode) {
      return { mode: k.mode, pendingMode: null };
    }
    return null;
  }

  if (targetMode === "commitment") {
    return {
      mode: k.mode,
      pendingMode: { mode: "commitment", effectiveOn: tomorrowStr(todayStr) },
    };
  }

  // targetMode === "companion", and k.mode was "commitment" — immediate.
  return { mode: "companion", pendingMode: null };
}

// ---------- settings: the hour she is inside cannot be deleted (#130) ----------
//
// Sara, in real use on 2026-08-30: "בזמן של העצירה אני תמיד יכולה לבטל
// מפה. עכשיו עשיתי לי משעה מסוימת לשעה מסוימת שיהיה לי חסום, והסרתי את
// זה בהגדרות." Her ruling on the same issue: "אני רוצה שלא תהיה אפשרות
// לעזוב את זה בזמן שזה חסום."
//
// So: adding a quiet window stays instant, removing one stays instant, and
// there is exactly one exception — the window that is stopping her RIGHT
// NOW cannot be removed while it is running. Every other window in her
// list, and that same window at every other hour, is still one click away.
//
// This is deliberately the SMALLEST of the three options #130 weighed, and
// it is the only one that leaves §1 principle 4 standing: she is never held
// for longer than the window she set herself, she can plan and re-plan
// freely at any other moment, and the way out of the moment itself is the
// one the product already built for it — the "קשה לי עכשיו" valve (#87),
// which files the day as a day she released rather than a day she fell.
// requestModeChange above is NOT the model for this and is untouched: its
// asymmetry (tightening waits a night, loosening is immediate) is about a
// choice that would hold her for days, and it stays exactly as it is.
//
// ---- THIS IS A SECOND COPY OF background.js's activeWindow(), on purpose ----
// This project has no module system and no build step, so a screen that
// needs the engine's answer has to write the engine's rule out again. It is
// the same bargain dashboard.js's normaliseShabbatEdges strikes with
// background.js's normaliseEdges, and the same one DAY_RESET_HOUR lives
// with across three files. The bargain only holds because a test refuses to
// let the two drift: she-cannot-delete-the-hour-she-is-inside.mjs runs this
// predicate and the engine's own activeWindow over the same clock, minute
// by minute, across a whole week, and fails if they ever disagree. Change
// one, change the other.
//
// The three things the engine already gets right, which this copy keeps:
//   · A window whose close is not after its open runs THROUGH MIDNIGHT, and
//     the hours past midnight belong to the day it started on. A Tuesday
//     23:00-06:00 window is still Tuesday's window at two on Wednesday
//     morning.
//   · The weekday is the calendar's (getDay), not DAY_RESET_HOUR's. A woman
//     who says "from eleven at night on Tuesday" means the Tuesday on her
//     wall; reading the day-boundary weekday here would shift that same
//     window a second time. background.js carries the full note.
//   · `w.scope` — the legacy field some machines still have stored from
//     before #37 deleted the concept — is never read. A window is
//     browser-wide whatever that field says.
//
// `now` is always passed in. Nothing in this file reads the ambient clock
// (see the header note); dashboard.js hands it a real Date, and the tests
// hand it whichever minute they are asking about.
function quietWindowMinutes(now) {
  return now.getHours() * 60 + now.getMinutes();
}

function quietWindowClock(str) {
  const [h, m] = String(str).split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}

function quietWindowActive(w, now) {
  if (!w || !w.from || !w.to) return false;
  const day = now.getDay();
  const mins = quietWindowMinutes(now);
  const from = quietWindowClock(w.from);
  const to = quietWindowClock(w.to);
  const overnight = to <= from;
  const startedToday = (w.days || []).includes(day);
  const startedYesterday = (w.days || []).includes((day + 6) % 7);
  if (!overnight) return startedToday && mins >= from && mins < to;
  return (startedToday && mins >= from) || (startedYesterday && mins < to);
}

// Asked per window rather than "which one window is active", because two
// windows can overlap: at an hour covered by both, deleting either one is
// still her walking out of a block she is inside, so both are held. The
// engine's activeWindow() returns only the first match because all it needs
// is a yes or no; this screen needs the answer for every row it draws.
function canRemoveQuietWindow(w, now) {
  return !quietWindowActive(w, now);
}

// ---------- the manual holiday off-switch, and why it is not here ----------
// Sara, 2026-08-23: "כל העניין של החג לא צריך בכלל, מיותר". Issue #20's
// `holidayDates` key, its two helpers, its settings block and its judgement
// branch are all gone. What remains is this note and the one in
// docs/data-model.md, so that nobody re-derives the feature from an
// orphaned storage key on somebody's machine: a stored `holidayDates` is
// now written by no version and read by none. See
// a-retired-holiday-key-changes-nothing.mjs.

// ---------- settings: the week's own "להתקדם / להישאר" (#30 wrote the
// field, #20 is the first reader — docs/data-model.md's own note) ----------
// Direct storage read/write territory, per #30's own architecture decision
// (docs/data-model.md: "לא דרך הודעה למנוע" — same shape popup.js already
// uses for pendingStation/fallAcked). This is the pure half: what the patch
// should be, never the writing of it.
function applyWeekChoice(k, choice, todayStr) {
  if (!k.pendingWeekChoice) return null;
  if (choice === "stay") {
    // Restoring previousLimit is not enough on its own (issue #102 review):
    // the same seven kept days that earned the engine's own drop still sit
    // under the restored (higher) target, which targetSuggestion would read
    // as freshly earning that exact drop again — offering her, on the very
    // same render, the cut she just said "להישאר" to. Silencing this exact
    // from-value the same way a dashboard-originated "להישאר" already does.
    return {
      rule: { ...k.rule, limitMinutes: k.pendingWeekChoice.previousLimit },
      pendingWeekChoice: null,
      dismissedSuggestion: { from: k.pendingWeekChoice.previousLimit },
    };
  }
  // "advance" — the lower limit is already written (docs/data-model.md: the
  // descent applies immediately), so there is nothing left to change but
  // clearing the choice itself. It also stamps targetChangedOn (issue #102):
  // the SAME seven kept days that earned the engine's own descent must not
  // immediately earn a second, unrelated one from targetSuggestion's card —
  // one source of truth for "when did her target last move".
  return { pendingWeekChoice: null, targetChangedOn: todayStr };
}

// ---------- issue #102: the 2a dashboard's own numbers ----------
//
// "כל מספר מחושב מהנתונים" — the four additions below feed the 2a visual
// layer and nothing else. Same house rules as everything above: no DOM, no
// chrome, todayStr always arrives pre-computed.

// H:MM, minutes zero-padded — the same reading chat-engine.js's
// placeholders.formatClock gives {{יעד}}/{{נותר}}. Written out here rather
// than reached through window.ChatEngine because this file must stay
// runnable in a bare node script with no module in sight (the same reason
// shared.js mirrors DAY_RESET_HOUR).
function formatClock(totalMinutes) {
  const m = Math.max(0, Math.round(totalMinutes));
  return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`;
}

// One day's measured minutes across this kabbalah's own places — the mirror
// of export.js's usageMinutesForDay, reading the same `usage:<day>` keys
// background.js writes ({place: seconds}).
function usageMinutesForDay(store, dayStr, places) {
  const usage = store[`usage:${dayStr}`] || {};
  let seconds = 0;
  for (const place of places || []) seconds += usage[place] || 0;
  return Math.round(seconds / 60);
}

// "השבוע החזרת לעצמך X שעות" — the sum, over the last 7 calendar days
// including today, of max(0, baselineMinutes − actual) per kabbalah; the
// exact window and arithmetic export.js's weeklyReturnedMinutes already
// calls "this week", so the board and the export can never tell her two
// different stories about the same seven days. A kabbalah with no baseline
// (baselineMinutes == null) is omitted outright — an unknown starting point
// is not a zero one.
function returnedThisWeekMinutes(kabbalot, store, todayStr) {
  let total = 0;
  for (const k of kabbalot || []) {
    if (k.baselineMinutes == null) continue;
    // An unknown creation date is "do not credit", not "credit everything"
    // (review, blocker): the old `k.createdAt && day < k.createdAt` guard
    // was falsy — and so entirely skipped — for a kabbalah with no
    // createdAt at all, which meant the ONE case with no age information
    // whatsoever got the full, completely unguarded week. Onboarding
    // always writes createdAt now; this only reaches pre-createdAt pilot
    // records, and they get zero credit rather than a fabricated week.
    if (!k.createdAt) continue;
    // i starts at 1, not 0: "החזרת" is past tense, and a day that has not
    // ended cannot be counted as returned — a systemic fix, not an
    // install-day-only one, since a day with no usage:<day> key reads as
    // zero usage and zero usage under a baseline earns FULL credit for an
    // unfinished day, every day, at every hour (review, blocker). The
    // window is the previous 7 COMPLETED days (yesterday back through a
    // week ago) — shifted back one day, not shrunk to six, so "this week"
    // stays the same span everywhere else in this file already uses it.
    for (let i = 1; i <= 7; i++) {
      const day = daysAgoStr(todayStr, i);
      // A day before this kabbalah existed has no usage:<day> key, which
      // reads as zero usage — and zero usage under a baseline earns FULL
      // credit, fabricating "hours returned" for days she never lived
      // under this kabbalah at all. monthCalendar and overviewStats
      // already guard this; this loop did not.
      if (day < k.createdAt) continue;
      total += Math.max(0, k.baselineMinutes - usageMinutesForDay(store, day, k.places));
    }
  }
  return total;
}

// Nearest half hour, as export.js's own hour arithmetic already rounds it
// (15-29 minutes rounds UP to half an hour and still shows); null only
// when the total rounds all the way down to zero, so the renderer hides
// the line instead of announcing "0 שעות" — a claim with nothing
// underneath it.
//
// A bare number handed to a template that appends " שעות" is not Hebrew
// (issue #102 review, blocker) — "0.5 שעות", "1 שעות", "2 שעות" are
// ungrammatical, and those three are exactly the MOST COMMON values in a
// real first week (a brand-new kabbalah has little to return yet). Hebrew
// has its own words for these — a half, the singular, the dual — so this
// returns the complete phrase, not a number for a caller to decorate;
// nothing outside this function should ever append "שעות" to its result.
function formatReturnedHours(minutes) {
  const value = Math.round((minutes / 60) * 2) / 2;
  if (value < 0.5) return null;
  if (value === 0.5) return "חצי שעה";
  if (value === 1) return "שעה";
  if (value === 1.5) return "שעה וחצי";
  if (value === 2) return "שעתיים";
  if (value === 2.5) return "שעתיים וחצי";
  // Three and up: Hebrew has no special word past the dual, but a bare
  // decimal ("3.5 שעות") reads as a foreign register right next to
  // "שעתיים וחצי" the line above (review, minor) — carry the same
  // "וחצי" construction through instead: a whole number is a plain count,
  // a half-hour remainder becomes "{n} וחצי שעות" (n = the whole-hour part).
  if (Number.isInteger(value)) return `${value} שעות`;
  return `${Math.floor(value)} וחצי שעות`;
}

// The "מצב היום" row: how much of today's quota is left, and how much of it
// is spent (the 2a progress bar fills with time USED — 35 of 60 minutes is
// a 58% bar, the design's own 0:25-remaining row). A window kabbalah has no
// quota to count down (background.js's own note at remainingFor) — null,
// and the renderer shows its hours instead of a bar.
// This always sums usage across ALL of k.places — the same aggregate branch
// remainingFor falls back to when no single place is given. Under
// FALL_ON === "any-place" mode, background.js's own remainingFor can instead
// stop her on ONE place's own per-place limit before the aggregate here
// would; this row can read "time left" a moment after the door already
// closed on the place she is actually on.
function remainingToday(k, usageToday) {
  if (k.rule?.kind !== "dailyLimit") return null;
  const limit = k.rule.limitMinutes || 0;
  const usedSeconds = (k.places || []).reduce((s, p) => s + ((usageToday || {})[p] || 0), 0);
  const usedMin = Math.round(usedSeconds / 60);
  return {
    limit,
    usedMin,
    remainingMin: Math.max(0, limit - usedMin),
    // A limit of 0/undefined is "בכלל לא" — no quota to divide against, so
    // there is no ratio to compute. Kept perfectly at zero usage reads 0%,
    // never a maxed red bar for the exact discipline the kabbalah asks for;
    // any usage at all against "not at all" is a full violation, 100%.
    usedPercent: limit
      ? Math.min(100, Math.round((usedMin / limit) * 100))
      : (usedMin > 0 ? 100 : 0),
  };
}

// ---------- issue #102: the monthly success calendar ----------
//
// One grid per kabbalah, the current calendar month of `todayStr`,
// Sunday-first (Date#getDay() already numbers Sunday 0 — the same numbering
// quietWindows' `days` uses). Cells outside the month are null pads.
//
// Statuses arrive through dayStatusMap by default, and pass through this
// function UNTOUCHED — issue #87 (built in parallel) teaches dayStatusMap a
// third judged status, "released", and the moment it lands every released
// day flows into the grid with no edit here. That is why `statuses` is also
// a parameter: a test can hand this function the post-#87 shape today.
//
// percent is kept ÷ judged over the month (judged = kept + fell + released;
// a released day is a day she chose, but not a day she kept — it sits in
// the denominator). No judged days → null, the same honesty rule
// weeklyStandingPercent already follows: a percentage with nothing real
// underneath it is not a positive number.

const HEBREW_MONTHS = [
  "ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני",
  "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר",
];

function monthCalendar(k, events, todayStr, statuses = dayStatusMap(events, k.id)) {
  const today = parseDay(todayStr);
  const year = today.getFullYear();
  const month = today.getMonth();
  const first = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells = [];
  for (let i = 0; i < first.getDay(); i++) cells.push(null);

  let judged = 0;
  let kept = 0;
  for (let num = 1; num <= daysInMonth; num++) {
    const day = calendarDate(new Date(year, month, num));
    let status = statuses[day];
    if (status) {
      judged++;
      if (status === "kept") kept++;
    } else if (k.createdAt && day < k.createdAt) {
      status = "before";
    } else if (day > todayStr) {
      status = "future";
    } else if (day === todayStr) {
      status = "open"; // today, still being lived — no verdict to paint
    } else {
      status = "skipped"; // a past day the engine never judged (Shabbat, a marked holiday)
    }
    cells.push({ day, num, status, isToday: day === todayStr });
  }
  while (cells.length % 7) cells.push(null);

  const weeks = [];
  for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));

  return {
    monthLabel: HEBREW_MONTHS[month],
    weeks,
    percent: judged ? Math.round((kept / judged) * 100) : null,
  };
}

// ---------- issue #102: the suggestion card's own rule ----------
//
// Seven consecutive kept days ending YESTERDAY earn an offer to lower the
// target to 75%, rounded to the nearest five minutes, never below the
// 15-minute floor (the same PLAN_FLOOR_MINUTES background.js's ladder and
// onboarding's DIAL_MIN already stand on). Deliberately strict: a day the
// engine never judged (Shabbat swallowed whole, a marked holiday) is not
// "kept", so it does not count toward the seven — flagged for Sara in the
// issue #102 report, because a woman whose Shabbat is always skipped can
// only earn this through the engine's own weekly ladder (settleWeek's
// 5-of-a-week bar), which remains the primary path and outranks this card
// via pendingWeekChoice below.
//
// Three silencers, each a field the dashboard itself writes:
//   · pendingWeekChoice — the ENGINE already lowered the target this week
//     and is waiting for her word; one offer at a time, and the engine's
//     own comes first (dashboard.js renders that one through this same
//     card — see suggestionFor()).
//   · dismissedSuggestion {from} — she said "להישאר" at this exact target;
//     asking again every morning would turn a suggestion into a nag.
//   · targetChangedOn — the day a target last changed through this card.
//     The seven days must all be ON or AFTER it: days kept against an older
//     (higher) target say nothing about the new one, and without this guard
//     accepting 60→45 would re-offer 45→35 the very same second, off the
//     very same days.
function targetSuggestion(k, events, todayStr) {
  if (k.rule?.kind !== "dailyLimit") return null;
  if (k.pendingWeekChoice) return null;
  const from = k.rule.limitMinutes;
  if (typeof from !== "number") return null;

  const to = Math.max(15, Math.round((from * 0.75) / 5) * 5);
  if (to >= from) return null;
  if (k.dismissedSuggestion && k.dismissedSuggestion.from === from) return null;

  const statuses = dayStatusMap(events, k.id);
  for (let i = 1; i <= 7; i++) {
    const day = daysAgoStr(todayStr, i);
    if (statuses[day] !== "kept") return null;
    if (k.targetChangedOn && day < k.targetChangedOn) return null;
  }
  return { from, to };
}
