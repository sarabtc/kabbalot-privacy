// בחרתי בי — service worker: active-tab time tracking + gentle enforcement.
// The enforcement serves the kabbalah, never the other way around (PRD §2.5).

const IDLE_THRESHOLD_SECONDS = 60;
const GRACE_MINUTES = 5;
const MAX_CHUNK_SECONDS = 120; // see flushActiveTime

// ---- issue #6: three micro-decisions, in one place ----
// These are the issue's own *proposals*. Sara has not approved them, and #6
// stays open until she does. What is built here is the mechanism, so that
// answering the question is an edit to the two constants below rather than a
// rebuild of four screens — #16, #19, #21 and #30 all wait on knowing when a
// day ends and what Shabbat means, and none of them should have to wait on a
// decision that is really one number.
//
// The hour her day turns over, on her own clock. The proposal is 03:00: a
// woman still reading at half past midnight has not started a new day, and
// handing her a fresh quota at that hour would be the product siding against
// her at the moment she is least able to argue.
//
// If Sara picks a different hour, this one number is the whole change. Every
// day-keyed thing in the product — usage:, graceOn:, breach:, lastDay, the
// streak evaluation, and the Sunday the shared grace pool starts on — reads
// the day through dateStr() below, so they cannot drift a night apart from
// each other. The same number is mirrored in shared.js (the screens) and
// export.js, because this project has no module system; a test checks that
// all three still say the same thing.
const DAY_RESET_HOUR = 3;

// ---- Sara's ruling, 2026-08-23: the week is not a calendar ----
//
// HER WORDS: "ששבת לא יהיה, אני רוצה שיהיה מוצאי שבת ויום שישי, ככה זה
// יעבוד, ושזה יהיה מנוסח ככה ושזה יעבוד ככה."
//
// What was here before was a single field called SHABBAT with a fromDay of 5
// and a toDay of 6, and every screen and comment that touched it said "שבת".
// That is a calendar Saturday wearing the name of a day nobody actually
// lives that way: Shabbat runs from Friday afternoon to Saturday night, so
// the two moments that matter to her are the Friday hour it comes in and the
// motzash hour it goes out. The product now names exactly those two, in her
// own words, and she sets them herself (dashboard settings).
//
// SHE SETS THEM, OR THESE DEFAULTS DO. There is no zmanim call and there
// never will be — docs/packaging.md Gate 1 fails the build on any network
// primitive, and nothing-leaves-the-device.mjs is the scanner it reuses. So
// the two hours are either hers or these, and these stay deliberately wide:
// 15:00 is earlier than candle lighting anywhere in the country, 21:00 is
// later than havdalah. Widening only ever measures less, which is the safe
// direction to be wrong in; narrowing is hers to do knowingly.
//
// The stored override lives under "shabbatEdges" and is read through
// shabbatEdges() below, which falls back field by field, so a half-written
// or hand-mangled key can never leave the engine without a Shabbat at all.
const SHABBAT_EDGES_DEFAULT = { fridayFrom: "15:00", motzashFrom: "21:00" };

// The two weekdays the edges hang on. Not settable, and not a proposal: the
// arc starts on a Friday and ends on a Saturday night because that is what
// Shabbat is. Only the hours are hers.
const FRIDAY = 5;
const SATURDAY = 6;

// ---- issue #82: what counts as a fall when one kabbalah holds several
// ---- places, each carrying its own daily target ----
//
// This constant is written here, beside the two above, for exactly the same
// reason and in exactly the same shape issue #6 used: it is a *proposal*.
// Sara has not confirmed it, and until she does, what is built is the
// mechanism — so that answering the question is an edit to this one line
// rather than a rebuild of the engine and three screens.
//
// The question the rebuilt onboarding raised and could not close on its own:
// she says she spends five hours on one site and one on another, and asks
// for an hour back from the first and half an hour from the second. That is
// two targets under one streak. If she keeps the second and blows through
// the first, has she fallen?
//
// Three honest answers, and this is the vocabulary for all three:
//
//   "any-place"   — exceeding any single place is a fall. The strictest, and
//                   the one built as the default: each promise she made is a
//                   promise in its own right, and a good hour on her mail
//                   does not buy back a bad evening on video. It is also the
//                   only one of the three under which the stop page can
//                   honestly appear on the place she is actually sitting on.
//   "total"       — only the sum matters, the way a one-place kabbalah has
//                   always been judged. Kinder, and it lets one place pay
//                   for another — which is either the flexibility she wanted
//                   or the loophole that empties the promise, depending on
//                   the woman.
//   "every-place" — a fall only when every place was exceeded. Kindest, and
//                   almost certainly too kind to mean anything.
//
// Changing this word is the whole change. Everything that judges a day
// (keptToday), stops a page (pastHerRule), counts down (timerFor, checkLimit)
// and warns (checkLimit) reads the same two helpers below, so they cannot
// drift apart from each other. A kabbalah written before this build — one
// with no `placeGoals` — is judged on its total whatever this says, because
// there are no per-place numbers to judge it on.
const FALL_ON = "any-place";

// The third decision — audio or video playing in a background tab is not
// counted — needs no constant here, because the engine has never counted
// anything else. Minutes are credited to `activeSession`, and a session is
// only ever opened for the active tab of the focused window (setActiveTab,
// and the query both followActiveTab and resumeSession make); the browser
// losing focus closes it outright. A YouTube-music tab left playing behind
// her work is therefore already uncounted, and there is nothing to switch
// off. Adding a flag that only restates the architecture would be a value
// nobody reads. What the proposal gets instead is a test that fails the day
// this stops being true: tests/only-the-tab-in-front-of-her.mjs.

// Chrome shuts this service worker down after about thirty seconds of quiet
// and starts it again on the next event. Anything held in a variable here is
// gone by then — which is why the session below lives in storage instead.
// It is the difference between counting two hours and counting ten minutes.
async function getSession() {
  const { activeSession } = await chrome.storage.local.get("activeSession");
  return activeSession || null;
}

async function setSession(session) {
  await chrome.storage.local.set({ activeSession: session });
}

function domainOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

// The address without the page: "https://her-bank.example/". What is kept
// about a page that belongs to no kabbalah, so that nothing is remembered
// about her banking but the fact that a browser was open on it.
function originOf(url) {
  try {
    return `${new URL(url).origin}/`;
  } catch {
    return null;
  }
}

// Not every minute in the same place costs her the same thing. An hour-long
// shiur is not what takes the evening; the short clips are, because one ends
// and the next begins. So a place in her kabbalah can be a whole address or
// one corner of it — "her-place.example" or "her-place.example/corner" — and
// only what she actually named is measured.
//
// Returns the place this url belongs to, or null if it is none of her
// business. The most specific match wins, so naming a corner does not drag
// the whole address in with it.
function placeFor(url, places = []) {
  const host = domainOf(url);
  if (!host) return null;

  let path = "/";
  try {
    path = new URL(url).pathname || "/";
  } catch {
    // not a real url — nothing to match
  }

  let best = null;
  for (const place of places) {
    if (typeof place !== "string") continue;
    const slash = place.indexOf("/");
    const placeHost = slash === -1 ? place : place.slice(0, slash);
    if (placeHost !== host) continue;

    const placePath = slash === -1 ? "" : place.slice(slash).replace(/\/$/, "");
    const matches =
      !placePath || path === placePath || path.startsWith(`${placePath}/`);
    if (matches && (!best || place.length > best.length)) best = place;
  }
  return best;
}

// Fix (2026-08-25, Sara's report): "אני רוצה ששם הקבלה יהיה לפי שם האתר" —
// same change as nameFrom() in onboarding-model.js, duplicated here rather
// than imported because background.js is the service worker, a separate
// script context that never loads that file. A "place" string is `host` or
// `host/path` — exactly the shape placeFor, just above, already parses —
// so a bare host reads as-is ("youtube.com") and a host with a corner gets
// that corner named alongside it ("youtube.com/shorts" → "youtube.com
// (shorts)"). Used only by migrateToKabbalot, below, for a kabbalah
// migrated from the old single-kabbalah build with no nickname of its own.
// Fix (Founder Ruling 2 / Minor 10, 2026-08-26): same two guards as
// onboarding-model.js's own placeDisplayName, and for the same two reasons
// — see that copy's own comment for the full reasoning. An empty host
// ("/shorts") or a punycode A-label ("xn--9dbhtj5b.co.il", what a Hebrew
// domain normalises to) both now return "", so legacyKabbalahName's own
// `|| "המקום שלי"` below catches them the same way it already catches no
// domains at all.
function placeDisplayName(place) {
  const slash = place.indexOf("/");
  const host = slash === -1 ? place : place.slice(0, slash);
  if (!host || /(^|\.)xn--/i.test(host)) return "";
  if (slash === -1) return host;
  const corner = place.slice(slash + 1);
  return corner ? `${host} (${corner})` : host;
}

// "המקום שלי" is the last-resort fallback, for a migrated kabbalah that
// carries no places at all to name itself after, or none placeDisplayName
// can put a name to (Founder Ruling 2 / Minor 10, above).
//
// Fix (Important 6, 2026-08-26): capped at the same 24 characters
// nameFrom() (onboarding-model.js) and docs/messages.md's {{שם}} variable
// both require — this used to return an unbounded string, so a 38-character
// host produced a 38-character name here and a 24-character one there.
// Tested as an agreement between the two, not two separately-pinned
// numbers, in the-kabbalah-is-named-for-what-she-chose.mjs.
function legacyKabbalahName(domains) {
  const first = (domains || []).find((d) => typeof d === "string" && d);
  const generated = first ? placeDisplayName(first) : "";
  return (generated || "המקום שלי").slice(0, 24);
}

// Every place named across the whole list, for the questions that do not
// care which kabbalah a page belongs to — only whether it belongs at all.
function allPlaces(kabbalot) {
  return kabbalot.flatMap((k) => k.places);
}

// The kabbalah a url belongs to — the one whose place matches it best.
function kabbalahFor(url, kabbalot) {
  let best = null;
  let bestPlace = null;
  for (const k of kabbalot) {
    const place = placeFor(url, k.places);
    if (place && (!bestPlace || place.length > bestPlace.length)) {
      best = k;
      bestPlace = place;
    }
  }
  return best;
}

// Her day, not Greenwich's — and not the calendar's either. toISOString()
// rolls the day over at 02:00 or 03:00 her time, so an evening that runs
// past midnight was counted against the day before — enough to break a
// streak she actually kept, or to count one twice. Her own midnight is not
// much better: at 00:30 she is still inside the evening she started, so the
// day turns at DAY_RESET_HOUR instead.
//
// This is the one function every day in this product goes through. If two
// places worked the day out for themselves they would disagree for exactly
// three hours a night — the popup showing a day the streak had already
// closed — and it would look like a data bug for weeks before anyone found
// the second piece of arithmetic.
function dateStr(d = new Date()) {
  return calendarDate(dayDate(d));
}

// The calendar date a Date falls on, written out. A smaller question than
// dateStr(): this one formats what it is handed and asks nothing about
// boundaries, which is exactly what the few callers below want — they are
// already holding the day they mean.
function calendarDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// The calendar date her day is filed under, as a Date at local midnight:
// before the reset hour she is still in yesterday. Built from the local
// calendar fields rather than by subtracting three hours in milliseconds,
// because on the two mornings a year the clocks move, subtracting hours
// lands on the wrong day and nobody would ever work out why.
function dayDate(d = new Date()) {
  const back = d.getHours() < DAY_RESET_HOUR ? 1 : 0;
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() - back);
}

// "2026-08-13" back into the date it is filed under, at local midnight.
// new Date(str) would read it as UTC midnight, which is the same bug from
// the other direction. Note this is the day's *label*, not the moment it
// begins — that is DAY_RESET_HOUR hours later. Everything that uses it uses
// it as a cursor for counting whole days, where the label is all it needs.
function parseDay(str) {
  const [y, m, d] = String(str).split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

function todayKey() {
  return `usage:${dateStr()}`;
}

// The grace budget resets weekly, and the week has to start on the same
// boundary the days do. Keyed by the Sunday it begins — no year-end
// arithmetic to get wrong, and it reads as what it is.
//
// Which Sunday is read off the day she is actually in, not off the raw
// clock: at one in the morning on a Sunday her day is still Saturday, and so
// is her week. Asking the clock here would hand her a fresh pool of graces
// three hours early, once a week, at the hour she is least likely to be at
// her best — and the day's own accounting would still be filing those
// minutes under Saturday.

// The Sunday a day belongs to, as a Date. Shared by weekKey() below and by
// the plan's own weekly review (issue #30) — one place a week is worked out,
// not two, for the same reason dateStr() is the only way to work out a day.
function sundayOf(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay());
}

// The bare week label a moment falls in — no "grace:" prefix, because this
// is not a storage key, just the Sunday written out. weekKey() answers "what
// week is she in right now"; this answers the same question for a day
// already sitting on the day it means, the same split calendarDate() has
// from dateStr(), and it is what the per-kabbalah plan below is keyed by.
function weekLabel(d) {
  return calendarDate(sundayOf(d));
}

function weekKey() {
  return `grace:${weekLabel(dayDate())}`;
}

// The weekly grace pool is shared: three five-minute graces for all the
// kabbalot together, not three each. The pool size is law, not data.
const GRACE_POOL_PER_WEEK = 3;

// ---- one kabbalah becomes a list ----
// Sara's decision (14.8): every kabbalah is its own entity, with its own
// streak and its own road. A device from the old build carries one
// kabbalah — it walks over into a list of one, losing nothing, and the
// old keys are cleared so there is exactly one place the truth lives.
// `warnedOn` is here for the same reason as the rest: it was one marker for
// the whole browser, and `warnedOnBy` replaced it with one per kabbalah. A
// key nothing reads anymore does not get to sit in her storage.
//
// `morningAfterOpenedOn` is the newest arrival and the shortest-lived. It
// existed only to stop issue #19's self-opening tab from opening twice in a
// day; the tab is gone and the badge that replaced it is a state, not an
// event, so nothing needs the date anymore (see syncFallBadge). A device
// that ran the merged build for a day still has the key, so it is swept up
// here rather than left behind as a fossil that looks meaningful.
const LEGACY_KEYS = [
  "kabbalah", "streak", "longestStreak", "daysKept", "journeySteps",
  "stationsReached", "pendingStation", "fellOn", "fallAcked", "pendingEvents",
  "warnedOn", "morningAfterOpenedOn",
];

async function migrateToKabbalot() {
  const data = await chrome.storage.local.get([
    "kabbalot", "events", ...LEGACY_KEYS,
  ]);
  const updates = {};
  const stale = [];

  if (!data.kabbalot && data.kabbalah) {
    updates.kabbalot = [{
      id: `k_${crypto.randomUUID()}`,
      name: data.kabbalah.nickname || legacyKabbalahName(data.kabbalah.domains),
      // Important 4 (onboarding-model.js's isGeneratedKabbalahName): a
      // migrated kabbalah with no old nickname gets its name from the
      // place, exactly like a fresh onboarding run with nothing typed —
      // flagged the same way, so a later dashboard edit can refresh it if
      // the place changes, and never touches an old nickname she did type.
      nameIsGenerated: !data.kabbalah.nickname,
      rule: { kind: "dailyLimit", limitMinutes: data.kabbalah.dailyLimitMinutes },
      places: data.kabbalah.domains || [],
      baselineMinutes: data.kabbalah.baselineMinutes ?? null,
      // She never chose a mode, because the old build never asked. Companion
      // is the gentler of the two, and a migration is no place to take
      // something away from her.
      mode: "companion",
      streak: data.streak || 0,
      longestStreak: data.longestStreak || 0,
      daysKept: data.daysKept ?? data.journeySteps ?? 0,
      stationsReached: data.stationsReached || 0,
      pendingStation: data.pendingStation || null,
      fellOn: data.fellOn || null,
      fallAcked: data.fallAcked !== false,
      createdAt: dateStr(),
    }];
  }
  if (!data.events && data.pendingEvents) updates.events = data.pendingEvents;

  for (const k of LEGACY_KEYS) {
    if (k in data) stale.push(k);
  }

  if (Object.keys(updates).length) await chrome.storage.local.set(updates);
  if (stale.length) await chrome.storage.local.remove(stale);
}

// Chrome dispatches the waking event as soon as the top level finishes —
// it does not wait for this promise. Every door into the worker waits on
// the same single migration, so the one boot where a device converts
// cannot race itself.
const migrated = migrateToKabbalot();

async function getKabbalot() {
  const { kabbalot } = await chrome.storage.local.get("kabbalot");
  return kabbalot || [];
}

async function setKabbalot(kabbalot) {
  await chrome.storage.local.set({ kabbalot });
}

// ---- the journey: measured in days, forward-only ----
// The road is time. A day she stood in her kabbalah is a day walked, and it
// is never taken back — a fall resets the streak, never the road (PRD: the
// answer to "all or nothing"). Minutes live in the treasure, not here.

const JOURNEY_STAGES = [
  { until: 3, name: "ההתחלה" },
  { until: 7, name: "השבוע הראשון" },
  { until: 14, name: "אחרי ההתלהבות" },
  { until: 18, name: "שמונה עשר" },
  { until: 30, name: "החודש" },
  { until: 40, name: "ארבעים יום" },
];
const STAGE_EVERY_AFTER = 30; // beyond forty days, another month each time

function stageEnd(index) {
  if (index < JOURNEY_STAGES.length) return JOURNEY_STAGES[index].until;
  const past = index - JOURNEY_STAGES.length + 1;
  return JOURNEY_STAGES[JOURNEY_STAGES.length - 1].until + past * STAGE_EVERY_AFTER;
}

function stagesAtDays(days) {
  let count = 0;
  while (days >= stageEnd(count)) count += 1;
  return count;
}

// Each kabbalah walks its own road. The kabbalah object is mutated in
// place; the caller saves the list.
async function addJourneyDay(k) {
  const next = (k.daysKept || 0) + 1;
  const reached = k.stationsReached || 0;
  const unlocked = stagesAtDays(next);
  k.daysKept = next;
  if (unlocked > reached) {
    k.pendingStation = { index: reached, day: next };
    k.stationsReached = unlocked;
    await recordEvent("station_reached", { index: reached, day: next }, k.id);
  }
}

// ---- issue #30: the progressive plan's weekly review ----
// The road (above) never goes back down. The plan does — a dailyLimit
// kabbalah is set up to ask for less at the start on purpose (PRD §4.2,
// feature 0: "the system always offers less than she is ready to commit
// to"), and each week that goes well the target itself descends a step
// (onboarding's own worked example: 1:45 → 1:30 → 1:15). This is a second,
// separate thing from the streak: a fall resets the streak every day: a week
// only ever *raises the bar*, and only when she has actually shown she can
// clear it.
//
// PLAN_STEP and PLAN_FLOOR_MINUTES are not new numbers invented here — they
// mirror onboarding-model.js's own PLAN_STEP and DIAL_MIN, the same ladder
// the onboarding dial already promised her. Two files, no module system, the
// same reason DAY_RESET_HOUR and GRACE_POOL_PER_WEEK are each written twice;
// nothing here is a fresh decision.
const PLAN_STEP = 15;
const PLAN_FLOOR_MINUTES = 15;

// A week advances the plan only after at least five days kept in it — never
// a blind schedule. This is PRD.md §4.2 feature 0's own line ("שבוע עם
// לפחות 5 ימי עמידה") and issue #30's own closing criterion, not a number of
// mine: it is not marked unapproved, because nothing here approves it —
// it is already the spec.
const WEEK_ADVANCE_MIN_DAYS = 5;

// A day with no measured minute in it is never reached here at all — the
// loop in evaluatePastDays continues past it before this function is ever
// called. So the answer to "how does a skipped day figure into a week's
// verdict" is the same answer the streak already gives it: it neither helps
// nor hurts the count of five, because it was never one of the days being
// counted — not the numerator, and (deliberately, since the bar is an
// absolute count of five days, not a fraction of the week PRD never asks
// for) not a denominator either.
//
// יום שישי and מוצאי שבת are NOT such days, and used to be treated as if
// they were. See evaluatePastDays for the whole of that change: they call in
// here like any other day, kept or fallen, because the hours the product
// measured on them are hours she actually lived.
//
// Accumulates one judged day into the kabbalah's own week, and turns the
// week the moment a new one is reached — the same "walk forward, judge once"
// shape evaluatePastDays already uses for days, so a week cannot be judged
// twice any more than a day can.
function accumulateWeek(k, day, wasKept) {
  // A kabbalah has nothing to accumulate before it existed. This cannot
  // happen through the normal tick (a fresh kabbalah's lastDay is already
  // caught up to today by the time onboarding can write it — see report),
  // but the guard costs one line and closes the gap outright rather than
  // trusting a timing argument to hold forever.
  if (day < k.createdAt) return;

  const wl = weekLabel(parseDay(day));
  if (k.weekAnchor && wl !== k.weekAnchor) {
    settleWeek(k);
    k.weekAnchor = wl;
    k.weekKeptDays = 0;
  } else if (!k.weekAnchor) {
    // The first day this kabbalah has ever been judged on. There is no
    // previous week to settle — she is only just starting this one.
    k.weekAnchor = wl;
    k.weekKeptDays = 0;
  }
  if (wasKept) k.weekKeptDays = (k.weekKeptDays || 0) + 1;
}

// Lowers this kabbalah's target by one step of the ladder, and returns the
// new daily total — or null when there is nothing left to lower.
//
// A kabbalah with per-place goals (#82) takes the step off the place with
// the most room, and that place's own giveBackMinutes grows by exactly what
// its limit lost, so the record's arithmetic still holds afterwards: spend
// minus give-back is the place's limit, and the places sum to the
// kabbalah's. Spreading a fifteen-minute step across four places in slivers
// of four minutes would be a distribution she never chose and a number no
// screen could say out loud — and it would drift the sum by rounding every
// single week.
function descendOneStep(k) {
  const limits = placeLimits(k);
  if (!limits) {
    const proposed = Math.max(PLAN_FLOOR_MINUTES, k.rule.limitMinutes - PLAN_STEP);
    return proposed < k.rule.limitMinutes ? proposed : null;
  }
  let widest = null;
  for (const pair of limits) if (!widest || pair[1] > widest[1]) widest = pair;
  const [place, limit] = widest;
  const next = Math.max(PLAN_FLOOR_MINUTES, limit - PLAN_STEP);
  if (next >= limit) return null;
  const goal = k.placeGoals[place];
  k.placeGoals = {
    ...k.placeGoals,
    [place]: {
      ...goal,
      limitMinutes: next,
      giveBackMinutes: goal.giveBackMinutes + (limit - next),
    },
  };
  return limits.reduce((sum, [p, l]) => sum + (p === place ? next : l), 0);
}

// Turns the week that just ended: judges it against the five-day bar, and —
// for a kabbalah whose promise is a daily quota — proposes the next step
// down when she has earned it. The kabbalah object is mutated in place, like
// addJourneyDay; the caller saves the list.
function settleWeek(k) {
  const kept = k.weekKeptDays || 0;

  // Whatever choice was pending from an earlier week she never answered is
  // replaced by this week's own verdict, not stacked behind it — a week
  // that turns twice over is exactly the bug class #6 already found once
  // (lastDay walking backwards), and a second unanswered choice sitting
  // under the first would be the same shape of mistake with a different
  // name. See the report: this means an unanswered choice does not persist
  // indefinitely once another week has already turned past it.
  k.pendingWeekChoice = null;

  if (kept >= WEEK_ADVANCE_MIN_DAYS) {
    k.consecutiveGoodWeeks = (k.consecutiveGoodWeeks || 0) + 1;

    // Only a daily quota has a number to lower — a window rule has hours,
    // not a duration, and nothing here invents a target for it to descend
    // toward (see report).
    if (k.rule?.kind === "dailyLimit") {
      const previousLimit = k.rule.limitMinutes;
      const proposed = descendOneStep(k) ?? previousLimit;
      // Already at the floor: a good week is still a good week —
      // consecutiveGoodWeeks above still grew — but there is nothing left
      // to offer her a choice about, so none is raised.
      if (proposed < previousLimit) {
        k.rule = { ...k.rule, limitMinutes: proposed };
        // The drop is applied right away — "automatic, but adjustable"
        // (PRD §4.2) — and this is the adjustment sitting ready for her:
        // the moment she next opens the popup, whichever she picks moves
        // her forward (issue #30). Advancing means leaving this alone;
        // staying means writing rule.limitMinutes back to previousLimit
        // and clearing this field — the same direct-storage shape
        // pendingStation already uses (popup.js clears it once she has
        // seen it), not a message round trip through this file.
        k.pendingWeekChoice = { previousLimit, newLimit: proposed };
      }
    }
  } else {
    // A week that did not clear five days breaks the streak of good
    // weeks — not because it is a fall (it is judged nowhere near that
    // vocabulary), but because "two weeks in a row" means what it says.
    k.consecutiveGoodWeeks = 0;
  }
}

// ---- issue #30: earning a second kabbalah ----
// "מרוויחים, לא מוסיפים" — the offer is never the default; it is what the
// character raises once a kabbalah has actually shown two weeks of standing
// in it. SECOND_OFFER_MIN_GOOD_WEEKS and SECOND_OFFER_DECLINE_WEEKS are the
// issue's own stated numbers ("אחרי שבועיים רצופים עם 5+ ימי עמידה" and "סירוב
// ... בעוד שבועיים"), not invented here — see report for the one place this
// file adds a number the issue does not already give it.
const SECOND_OFFER_MIN_GOOD_WEEKS = 2;
const SECOND_OFFER_DECLINE_WEEKS = 2;

// Which kabbalah, if any, has earned the offer. When more than one has,
// the one with the longest road is named — deterministic, and the one that
// has earned it most plainly.
function secondOfferCandidate(kabbalot) {
  let best = null;
  for (const k of kabbalot) {
    if ((k.consecutiveGoodWeeks || 0) < SECOND_OFFER_MIN_GOOD_WEEKS) continue;
    if (!best || (k.daysKept || 0) > (best.daysKept || 0)) best = k;
  }
  return best;
}

// Read-only: is this the moment to raise the offer, and about which
// kabbalah. A decline is a plain cooldown in milliseconds — like
// graceUntil, not a week label — because "in two weeks" is a duration she
// was told, not a boundary tied to Sunday.
async function secondOfferStatus() {
  const data = await chrome.storage.local.get([
    "kabbalot",
    "secondOfferDeclinedUntil",
  ]);
  const candidate = secondOfferCandidate(data.kabbalot || []);
  if (!candidate) return { eligible: false };
  if (data.secondOfferDeclinedUntil && Date.now() < data.secondOfferDeclinedUntil) {
    return { eligible: false };
  }
  return {
    eligible: true,
    kabbalahId: candidate.id,
    kabbalahName: candidate.name,
    days: candidate.daysKept || 0,
  };
}

// ---- the local event journal ----
// Everything stays on her machine — chrome.storage.local, nothing else.
// The journal feeds the export screen ("הסיפור שלך במספרים") and the
// pilot's KPI counting. An event that belongs to one kabbalah says so.

async function recordEvent(type, meta = {}, kabbalahId = null) {
  const { events = [] } = await chrome.storage.local.get("events");
  const entry = { type, occurredAt: new Date().toISOString(), meta };
  if (kabbalahId) entry.kabbalahId = kabbalahId;
  events.push(entry);
  await chrome.storage.local.set({ events: events.slice(-500) });
}

// Usage is kept per day, forever, in a store that is not unlimited. Six
// weeks is far more than the thirty days the day-by-day accounting can
// reach back over, and keeps a month of history readable on the device.
const KEEP_DAYS = 45;

async function pruneOldDays() {
  const all = await chrome.storage.local.get(null);
  // Counted back in whole days from the day she is in, not in milliseconds
  // from now: the keys being compared are day labels, and forty-five times
  // 86,400,000 is not forty-five days in a year that has a clock change in
  // it. Off by one day here would quietly delete a day still on the screen.
  //
  // Honest note: no test in this suite can tell the two forms apart. They
  // differ only across a daylight-saving transition, and the suite has to
  // give the same answer in every timezone, so there is nowhere to stand and
  // ask the question. It is written this way because it is the correct
  // arithmetic, and because it puts pruning through dayDate() like every
  // other place in this file that names a day.
  const today = dayDate();
  const cutoff = calendarDate(
    new Date(today.getFullYear(), today.getMonth(), today.getDate() - KEEP_DAYS)
  );
  const stale = Object.keys(all).filter((k) => {
    const m = /^(usage|graceOn|grace|breach|released):(\d{4}-\d{2}-\d{2})$/.exec(k);
    return m && m[2] < cutoff;
  });
  if (stale.length) await chrome.storage.local.remove(stale);
  return stale.length;
}

// onboarding.js deletes an abandoned draft the moment it notices one on
// reopening the onboarding tab — but a girl who starts onboarding and never
// comes back never triggers that moment at all. This is the same 24-hour
// line onboarding-model.js's resumeTarget() already draws (its own
// DRAFT_TTL_MS, duplicated as a plain number here: this file and
// onboarding.js are separate script contexts with no shared module system,
// same as every other constant these files do not share). Riding the daily
// prune means an onboarding she walked away from is never left more than a
// day past the point the product itself stopped honouring it (issue #39).
const ONBOARDING_DRAFT_TTL_MS = 86400000;

async function pruneOnboardingDraft() {
  const { onboardingDraft } = await chrome.storage.local.get("onboardingDraft");
  if (!onboardingDraft) return;
  if (Date.now() - (onboardingDraft.savedAt || 0) > ONBOARDING_DRAFT_TTL_MS) {
    await chrome.storage.local.remove("onboardingDraft");
  }
}

// Pruning rides the minute tick but runs once a day. A second alarm would
// be re-created — and its countdown reset — on every worker wake, so its
// period would never actually elapse; the day marker in storage is the
// truth about whether today's sweep already happened.
async function pruneDaily() {
  const { lastPruned, warnedOnBy } = await chrome.storage.local.get([
    "lastPruned", "warnedOnBy",
  ]);
  const today = dateStr();
  if (lastPruned === today) return;
  await chrome.storage.local.set({ lastPruned: today });

  // warnedOnBy is keyed by kabbalah and only ever asked about today, so
  // yesterday's answers are dead weight — and a kabbalah she has since
  // deleted would sit in there forever. Dropping everything that is not
  // today keeps the key the size of her list, at no cost.
  if (warnedOnBy) {
    const stillToday = Object.fromEntries(
      Object.entries(warnedOnBy).filter(([, day]) => day === today)
    );
    await chrome.storage.local.set({ warnedOnBy: stillToday });
  }
  await pruneOldDays();
  await pruneOnboardingDraft();
  // A valve she never came back to is dropped on the first tick of the next
  // product day (issue #87) — syncValveAlarm is where "not today any more"
  // is decided, so the rule lives in one place.
  await syncValveAlarm();
}

// End-of-day accounting: a day within the kabbalah (graces included — a
// grace is a choice, not a fall) grows the streak; beyond it is a fall.
// The streak resets, but she does not (PRD §3.4).

// #20 — a switch waiting for the day it was scheduled to take effect on.
// The only direction that is ever staged this way is companion → commitment
// (see docs/data-model.md's `pendingMode`): a decision to lock the kabbalah
// down that has to survive one full night before it actually applies. The
// reverse direction (commitment → companion) is written immediately by
// dashboard.js and never touches this field at all — see that file's
// requestModeChange() for the one place both directions are decided.
//
// Mutates `kabbalot` in place and returns whether anything changed, the same
// shape accumulateWeek()/descendOneStep() already use below, so the one
// caller (evaluatePastDays) can fold it into whichever storage write it was
// already about to make rather than writing storage a second time.
function applyDuePendingModes(kabbalot, today) {
  let changed = false;
  for (const k of kabbalot) {
    if (k.pendingMode && today >= k.pendingMode.effectiveOn) {
      k.mode = k.pendingMode.mode;
      k.pendingMode = null;
      changed = true;
    }
  }
  return changed;
}

async function evaluatePastDays() {
  const data = await chrome.storage.local.get([
    "kabbalot",
    "lastDay",
    "shabbatEdges",
    "holidayDates",
    "hardDayValve",
  ]);
  const kabbalot = data.kabbalot || [];
  const edges = normaliseEdges(data.shabbatEdges);
  const today = dateStr();

  // issue #87 — a hard-day valve still living for a given day (accepted for
  // it, and not yet past its own grace — VALVE_CARRYOVER_MS, defined below)
  // marks that exact day off-limits to the ordinary clock. The grace that
  // lets a valve survive the 03:00 turn is exactly what makes this race
  // possible: she can accept at 02:58 and still be inside the ten minutes,
  // or standing at the ready screen, after this tick has already walked
  // past that day and judged it by usage alone. Judge first and let her
  // release after, and streak/fellOn contradict the `released` record for
  // the same day — or a `fall` event sits beside a `released` one, a
  // combination nothing downstream expects. See the loop below for where
  // this actually stops the walk.
  // A corrupted record (unreachable through any product write, but silent
  // and permanent if it ever happened — a bad migration, a hand-edited
  // profile) could carry a `readyAt` months away with a `day` that still
  // falls inside the walk: the grace above would then call it live forever,
  // and this walk would never advance past that day again. The cheap belt:
  // a valve can only ever legitimately be today's or yesterday's product
  // day (acceptValve() writes `day: dateStr()`, and the grace bridges at
  // most one day-turn), so anything else is treated as never having been
  // able to hold the walk, whatever its readyAt claims.
  const todayDayDate = dayDate();
  const yesterday = calendarDate(
    new Date(todayDayDate.getFullYear(), todayDayDate.getMonth(), todayDayDate.getDate() - 1)
  );
  const pendingValveDay =
    data.hardDayValve &&
    (data.hardDayValve.day === today || data.hardDayValve.day === yesterday) &&
    Date.now() <= data.hardDayValve.readyAt + VALVE_CARRYOVER_MS
      ? data.hardDayValve.day
      : null;

  // A lastDay ahead of today is not a day to walk back to. Nothing is judged
  // and, above all, nothing is written: the line below would otherwise move
  // lastDay *backwards*, and the day it stepped back over would be settled a
  // second time when the clock caught up — a streak counted twice, or a fall
  // recorded twice with fallAcked raised again, which puts the morning-after
  // screen in front of her for a day she has already faced.
  //
  // Three ways it happens, and none of them are hypothetical. She moves the
  // system clock back. She flies west over enough timezones. Or the day
  // boundary itself moves under a settled store — which is exactly what
  // installing #6 does to a device updated between midnight and the reset
  // hour: the last tick before the update wrote today's date by the old
  // reckoning, and the first tick after reads the day before it.
  //
  // Waiting is the safe direction. If a clock is set back a year this device
  // judges nothing until it catches up, and that is the better failure:
  // judging is destructive and cannot be undone, waiting costs her a streak
  // day she can still earn tomorrow. The same caution applies to a pending
  // mode switch: it is not applied either, on the same "wait rather than
  // act on a clock we do not trust yet" logic — a day that has not truly
  // arrived cannot be the day it takes effect on.
  if (data.lastDay && data.lastDay > today) return;

  // Applied on every tick, whether or not there is a day to walk — a switch
  // requested this morning has to take hold the moment "tomorrow" actually
  // arrives, not only the next time she happens to fall or keep a day.
  const pendingChanged = applyDuePendingModes(kabbalot, today);

  if (!data.lastDay || data.lastDay === today || !kabbalot.length) {
    const updates = { lastDay: today };
    if (pendingChanged) updates.kabbalot = kabbalot;
    await chrome.storage.local.set(updates);
    return;
  }

  // Evaluate every day since the last visit (cap 30); a day with no usage
  // is a day the kabbalah was kept. Each kabbalah is judged on its own —
  // a fall in one never touches another (decision 3).
  const start = parseDay(data.lastDay);
  const end = parseDay(today);
  for (
    let d = new Date(start), i = 0;
    d < end && i < 30;
    d.setDate(d.getDate() + 1), i++
  ) {
    // The cursor is already sitting on the day it means — calendarDate reads
    // it off rather than asking dateStr(), which would take a midnight and
    // hand back the day before.
    const day = calendarDate(d);

    // issue #87 — this exact day is still a live hard-day valve's own day:
    // stop the walk here, without judging it and without moving lastDay
    // past it. Same doctrine as the lastDay-ahead-of-today guard above —
    // waiting is the safe direction. lastDay becomes this day itself (the
    // same shape the "nothing to walk yet" early return above already
    // uses for today), so the next tick's walk starts right back here: once
    // she has released (this day now reads `released`, its own branch
    // below) or the valve has expired past its grace (pendingValveDay is
    // null on the next tick, an ordinary judgment), the walk continues.
    // kabbalot is written too — days before this one, already judged
    // earlier in this same walk, are not re-judged the next time around.
    if (pendingValveDay && day === pendingValveDay) {
      await chrome.storage.local.set({ kabbalot, lastDay: day });
      return;
    }

    const dayData = await chrome.storage.local.get([
      `usage:${day}`, `graceOn:${day}`, `breach:${day}`, releasedKey(day),
    ]);
    const usage = dayData[`usage:${day}`] || {};
    const g = dayData[`graceOn:${day}`];
    const released = Boolean(dayData[releasedKey(day)]);

    // A day with not one measured minute in it is not judged. There is
    // nothing here to keep and nothing to break: it is passed over whole,
    // and the streak comes out the other side untouched — not grown, not
    // reset, and the road no longer.
    //
    // With the default edges no such day exists, and that is the point: her
    // day runs 03:00 to 03:00, so יום שישי has twelve measured hours in it
    // (03:00 until the Friday edge) and מוצאי שבת has six (the motzash edge
    // until 03:00). Both are ordinary, measured, lived hours. This branch is
    // for the woman who widens the arc far enough to swallow one whole.
    const shabbatMinutes = shabbatMinutesIn(day, edges);
    if (shabbatMinutes >= MINUTES_PER_DAY) continue;

    for (const k of kabbalot) {
      // A rule we do not understand is passed over rather than guessed at. It
      // cannot happen today, but a kabbalah with no rule at all would throw
      // here — and this loop runs before the day is written, so one broken
      // kabbalah would leave lastDay stale and take every future tick with it.
      if (k.rule?.kind !== "window" && k.rule?.kind !== "dailyLimit") continue;

      // issue #87 — she released this day herself. It counts against the
      // streak exactly like a fall (otherwise the streak means nothing), but
      // no `fall` event is written: popup.js already journaled a `released`
      // entry per kabbalah the moment she pressed, and that third state is
      // what the morning-after screen, the dashboard and the export read.
      // Usage is not consulted at all — a released day is released whether
      // she then stayed under her limit or not. It sits after the Shabbat
      // and holiday skips above on purpose: those days were measured and
      // could still block her live, but this end-of-day judgement is
      // deliberately not made on them, and a day never judged has nothing
      // for a release to override. A release landing on one of them costs
      // her nothing beyond what the skip already forgave — a kindness
      // that falls out of the ordering, not a claim that nothing happened
      // that day.
      if (released) {
        k.streak = 0;
        k.fellOn = day;
        k.fallAcked = false;
        accumulateWeek(k, day, false);
        continue;
      }

      // Whose day a grace forgives is not the same question as whose budget
      // it came out of. The weekly pool is shared on purpose — three for all
      // the kabbalot together — but the forgiveness is this kabbalah's alone:
      // five minutes she asked for here must not quietly widen another
      // kabbalah's day, on a day she never asked it for anything. Two
      // separable decisions, and this is the deliberate combination.
      // A day written by the old build holds a bare number, which meant
      // everyone; it is still read that way rather than rewritten.
      const graces = typeof g === "number" ? g : (g?.[k.id] || 0);

      // A window kabbalah has no quota to exceed, so its usage total says
      // nothing about the promise. What is weighed instead is the time spent
      // inside the hours she said she is not there — and a day with none
      // recorded is a day she was not there, which is the whole of keeping it.
      // The same +2 as the quota case, for a different reason: the breach is
      // counted at minute granularity against a window whose edges are
      // minutes too, so a sitting that ends on the boundary can round up.
      //
      // A quota kabbalah that carries per-place targets (issue #82) is
      // judged place by place instead of on one sum — see keptToday and the
      // FALL_ON constant at the top of this file, which is the one line that
      // says what "exceeded" means across several of them.
      const kept =
        k.rule.kind === "window"
          ? (dayData[`breach:${day}`]?.[k.id] || 0) / 60 <=
            graces * GRACE_MINUTES + DAY_TOLERANCE_MINUTES
          : keptToday(k, usage, graces * GRACE_MINUTES + DAY_TOLERANCE_MINUTES);

      if (kept) {
        k.streak = (k.streak || 0) + 1;
        k.longestStreak = Math.max(k.longestStreak || 0, k.streak);
        await recordEvent("day_success", { day }, k.id);
        await addJourneyDay(k);
        // The plan's own week (issue #30) grows on the same kept day the
        // streak does — but it is a second, separate ledger: a fall resets
        // the streak every time, and only resets the plan's run of good
        // weeks once a whole week has actually gone badly.
        accumulateWeek(k, day, true);
      } else {
        // WHAT CHANGED HERE, AND WHY IT IS THE MOST IMPORTANT LINE IN THIS
        // FILE THIS WEEK. There used to be a branch above this one: a day
        // the Shabbat arc merely *touched* could be counted kept, but could
        // never be counted a fall. With the day boundary at 03:00 and the
        // arc at Friday 15:00 to Saturday 21:00, no day is ever wholly
        // inside — so that branch caught every Friday and every Saturday.
        // Two days in seven, four of the pilot's fourteen, on which the
        // number could go up and could not come down. That is not a
        // measurement, and the pilot is measuring it.
        //
        // Its stated reason was "she never promised anything about hours the
        // product refused to watch" — and that reason is exactly what Sara's
        // ruling dissolves. The product does not refuse to watch Friday
        // morning or מוצאי שבת. It watches them, they are ordinary hours of
        // ordinary days, and the arc between them is named at both ends now.
        //
        // The generosity that survives is the honest one, and it needs no
        // branch: the unmeasured minutes were never charged to her, because
        // usage: simply did not grow while they ran. Her quota on יום שישי
        // is her whole daily quota, spent across twelve waking hours instead
        // of twenty-one. Judging these days can only ever have made her
        // budget *larger*, never smaller.
        k.streak = 0;
        k.fellOn = day;
        k.fallAcked = false;
        await recordEvent("fall", { day }, k.id);
        accumulateWeek(k, day, false);
      }
    }
  }

  // One write settles the day: a reader must never see the new streaks
  // with yesterday's lastDay, or the day would be counted twice.
  await chrome.storage.local.set({ kabbalot, lastDay: today });
}

// ---- the hard-day valve: the ten minutes (issue #87) ----
//
// popup.js writes one absolute instant, `hardDayValve.readyAt`, the moment
// she accepts, and never a countdown (docs/messages.md, "שסתום היום
// הקשה": "רגע מוחלט אחד… הוא לא מתחיל מחדש אף פעם, והיא לא נשאלת שוב").
// Everything about *time* is this worker's job, through chrome.alarms —
// already a permission — so that closing the popup, the browser or the
// machine changes nothing:
//   · a write of hardDayValve (storage listener below) arms VALVE_ALARM for
//     readyAt exactly — `when`, not `periodInMinutes`;
//   · the alarm landing flips `ready: true` (markValveReady), which an open
//     popup sees through its own storage listener and a closed one reads on
//     its next open. The popup also accepts Date.now() >= readyAt on its
//     own, so a lost alarm is never a wall — but `ready` is what keeps a
//     clock set *backwards* from un-earning minutes that already passed;
//   · boot (syncValveAlarm in the wake-up chain) re-arms an alarm the
//     teardown lost, or settles an instant that passed while the worker
//     slept;
//   · a valve from a previous product day is dropped, unrecorded. "ואם היא
//     לא חוזרת, זה עצמו התשובה." No notification is ever sent about it.
const VALVE_ALARM = "hard-day-valve";

// A valve she is still inside — waiting out the ten minutes, or standing at
// the ready screen for her to press release — is not lost the instant the
// product day turns under her. She may accept at 02:58 and this worker may
// tick again at 03:04: hardDayValve.day (the evening before) and dateStr()
// (the new day) now disagree, but the ten minutes she is living through do
// not care what the calendar just did. So "stale" is day !== dateStr() *and*
// more than this long past her own readyAt — a grace, not a second window,
// wide enough to cover the ten minutes plus however long she takes to
// notice the screen once it is ready — one hour. Mirrored in popup.js's
// copy of this same name, the same way DAY_RESET_HOUR is mirrored across
// files; a test checks the two still agree.
const VALVE_CARRYOVER_MS = 60 * 60 * 1000;

function releasedKey(day) {
  return `released:${day}`;
}

// Whether she released this product day (popup.js writes the key the moment
// she presses the one button). Read, never written, here.
//
// FINDING 10 (whole-branch review) — releaseDay() (popup.js) keys the write
// on the valve's own day, not dateStr() at the moment she presses; a
// release inside the 03:00 carryover grace can land under yesterday's key
// while this default reads today's. See the broadcast listener below for
// the full note; the live consequence here is the same small one.
async function dayReleased(day = dateStr()) {
  const key = releasedKey(day);
  const data = await chrome.storage.local.get(key);
  return Boolean(data[key]);
}

async function markValveReady() {
  const { hardDayValve } = await chrome.storage.local.get("hardDayValve");
  if (!hardDayValve || hardDayValve.ready) return;
  await chrome.storage.local.set({ hardDayValve: { ...hardDayValve, ready: true } });
}

async function syncValveAlarm() {
  const { hardDayValve } = await chrome.storage.local.get("hardDayValve");
  if (!hardDayValve) {
    await chrome.alarms.clear(VALVE_ALARM);
    return;
  }
  // issue #87 — whole-branch review, FINDING 5. popup.js's pendingValve()
  // guards the same corruption on its side; this is this file's own choke
  // point. A non-numeric readyAt would reach chrome.alarms.create below
  // with { when: NaN } — an alarm that (per the API) never actually fires,
  // leaving a valve that can never resolve on its own. Dropped exactly
  // like a stale one, before either the day-mismatch check or the alarm
  // call ever sees it.
  if (!Number.isFinite(hardDayValve.readyAt)) {
    await chrome.storage.local.remove(["hardDayValve", "hardDayValveNote"]);
    await chrome.alarms.clear(VALVE_ALARM);
    return;
  }
  // A day mismatch alone is not stale — see VALVE_CARRYOVER_MS above; only
  // past the grace, on top of the day having turned, is it dropped.
  if (hardDayValve.day !== dateStr() && Date.now() > hardDayValve.readyAt + VALVE_CARRYOVER_MS) {
    await chrome.storage.local.remove(["hardDayValve", "hardDayValveNote"]);
    await chrome.alarms.clear(VALVE_ALARM);
    return;
  }
  if (hardDayValve.ready) {
    await chrome.alarms.clear(VALVE_ALARM);
    return;
  }
  if (Date.now() >= hardDayValve.readyAt) {
    await markValveReady();
    return;
  }
  chrome.alarms.create(VALVE_ALARM, { when: hardDayValve.readyAt });
}

// ---- the morning after a fall: how she finds it (was issue #19's tab) ----
//
// evaluatePastDays() above has known about a fall since #13 — a kabbalah
// that broke sits with fellOn set and fallAcked: false until something shows
// her the screen and records her choice.
//
// Issue #19 gave that a door by calling chrome.tabs.create() from this boot
// chain: on the first service-worker wake of the morning, a browser tab
// opened by itself, titled "בוקר טוב — קבלות", showing that she had broken a
// commitment about her screen habits. THAT IS GONE, and this is why.
//
// She did not click anything. The morning after a fall is the moment this
// product is least entitled to take the screen by force, and a browser tab
// is the least discreet surface there is: it appears in the tab strip with a
// title anyone walking past can read, on a computer that in this pilot's own
// audience is very often shared with a husband or a child. The product
// already decided this about a much smaller surface — issue #21's check-in
// notification was shaped around discretion, and whether the extension's
// name should even be explicit is still an open question. A screen that
// announces a private failure to a room is not a default to arrive at by
// accident, and accident is exactly how it arrived: two branches merged in
// the same hour, and nobody chose it.
//
// docs/messages.md group 3 also forbade what the two doors did together.
// Its usage rule is "אף פעם לא שתי הודעות קימה באותו יום" — never two rising
// messages in one day — and main shipped a tab that opened by itself AND a
// popup that rendered its own copy of the same moment.
//
// THE COUNTER-ARGUMENT, WHICH IS REAL: a screen she has to go looking for is
// a screen many women will never see, and the morning after a fall is
// exactly when this product has something worth saying. So the answer is not
// silence. It is a badge on the extension's own icon — a single dot, no
// words, meaningless to anyone but her, that she chooses to act on. The
// signal survives; the intrusion does not. DESIGN.md does not describe a
// badge, so it is FLAGGED FOR SARA as an invented surface — but it carries
// no Hebrew and no message, and it is the quietest thing in a browser that
// can still be noticed.
//
// The dot is "•" (U+2022) — the same glyph DESIGN.md §7.1 already chose for
// the export screen precisely because it is a plain typographic mark and NOT
// an emoji. the-character-carries-the-warmth.mjs enforces that rule and this
// stays inside it.
const FALL_BADGE_TEXT = "•";
// --primary from DESIGN.md §2.8. A service worker cannot read a CSS custom
// property, so this is the one place in the product where a token value is
// retyped outside tokens.css. It is not left to drift:
// no-colour-is-typed-twice.mjs asserts this constant still equals
// tokens.css's --primary, which is what a token reference would have bought.
const FALL_BADGE_COLOR = "#7C5CE0";

// Whether an unanswered fall is waiting, and the badge that says so. Driven
// off the same `fellOn && !fallAcked` the popup's screen reads, and off
// nothing else — no second stored flag, no "have we shown it yet" date. That
// is deliberate: the old tab needed `morningAfterOpenedOn` because opening a
// tab is an event that must not repeat, but a badge is a *state*. It is
// simply true while she has not answered and false the moment she has, so
// there is no bookkeeping key left to go stale, walk backwards, or disagree
// with the screen. `morningAfterOpenedOn` is now dead and is removed below.
//
// This is also what makes "acknowledging it in one place settles it
// everywhere" structural rather than something two files have to remember:
// the popup writes fallAcked, the storage listener below re-runs this, and
// the badge clears itself without the popup knowing a badge exists.
async function syncFallBadge() {
  if (!chrome.action?.setBadgeText) return;
  const { kabbalot = [] } = await chrome.storage.local.get("kabbalot");
  const waiting = kabbalot.some((k) => k.fellOn && !k.fallAcked);
  try {
    await chrome.action.setBadgeText({ text: waiting ? FALL_BADGE_TEXT : "" });
    if (waiting && chrome.action.setBadgeBackgroundColor) {
      await chrome.action.setBadgeBackgroundColor({ color: FALL_BADGE_COLOR });
    }
  } catch {
    // A narrower test double, or a Chrome that refuses the call — the badge
    // failing must never crash the boot chain that settled her data a moment
    // ago. She still meets the screen the moment she opens the popup; the
    // badge only decides whether she is nudged to.
  }
}

// The badge follows her data wherever it is written from. The popup flips
// fallAcked straight to storage (docs/data-model.md's own architectural note:
// popup writes do not go through this worker), so without this listener the
// dot would sit there until the next service-worker wake — telling her
// something is waiting that she has already answered.
chrome.storage.onChanged?.addListener?.((changes, area) => {
  if (area !== "local") return;
  if (changes.kabbalot) syncFallBadge();
  // The valve's instant is written by the popup (issue #87); the alarm for
  // it is this worker's — see syncValveAlarm above.
  if (changes.hardDayValve) syncValveAlarm();
  // issue #87 — releaseDay() (popup.js) writes released:<day> the instant
  // she presses the one button, and a stop screen already on some other tab
  // must not sit there waiting for content.js's own 30-second poll to
  // notice. Reuses the exact broadcast the grace grant already sends
  // (sendToTab, { type: "kabbalot-release" }, below) rather than a screen
  // of its own — the page only ever needed to be told "you may reload
  // without being stopped", the same thing grace already tells it.
  //
  // Gated two ways, both load-bearing:
  //   · changes["released:<today>"] is one exact property on `changes` —
  //     a write under any other day's key is a different property and is
  //     simply not here, so pruneOldDays()'s daily sweep of yesterday's
  //     (and older) released:<day> keys can never trip this branch,
  //     whatever it removes.
  //   · newValue must exist — a removal fires onChanged with only oldValue
  //     set, so even a (today-keyed) removal cannot broadcast
  //     kabbalot-release and lift a live stop screen for nothing she did.
  //
  // FINDING 10 (whole-branch review) — releaseDay() keys the write on the
  // valve's own day, not dateStr() at the moment she presses: releasing
  // inside the 03:00 carryover grace (a valve accepted just before the
  // turn, resolved just after it) writes released:<the evening before>,
  // and this exact-today gate never sees it — no broadcast, and
  // blockStateFor()/dayReleased() above stay unaware of it too. Left as-is:
  // the new product day starts at zero usage regardless, so the practical
  // gap is small, but this is the one place popup.js and this file key the
  // same press on different days.
  if (changes[releasedKey(dateStr())]?.newValue) {
    broadcastRelease();
  }
});

async function broadcastRelease() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) sendToTab(tab.id, { type: "kabbalot-release" });
}

async function flushActiveTime() {
  const session = await getSession();
  if (!session || !session.domain || !session.since) return;

  const now = Date.now();
  let seconds = Math.round((now - session.since) / 1000);
  await setSession({ ...session, since: now });
  if (seconds <= 0) return;

  // The tick runs every minute, so a gap much larger than that means the
  // machine slept or the browser was closed with the tab still open. Sleep
  // is not time she spent there, and crediting it would quietly cost her a
  // day she kept. Count a minute of it and no more.
  if (seconds > MAX_CHUNK_SECONDS) seconds = MAX_CHUNK_SECONDS;

  // Shabbat: nothing inside it is measured, on any place, for any kabbalah —
  // the day's usage does not grow and no breach is written. The session clock
  // above was already reset, so the dropped seconds are dropped and not
  // banked, for the same reason the place check below drops its own: a
  // stretch that was never ours to measure must not pile up and then land on
  // whatever she opens next.
  seconds = secondsOutsideShabbat(now, seconds, await shabbatEdges());
  if (seconds <= 0) return;

  // Only what she named is accounted for. Note this return comes *after* the
  // clock above was reset: the minutes she spends somewhere that is not hers
  // must not pile up and then land on the next place she opens.
  const place = session.place;
  if (!place) return;

  const key = todayKey();
  const stored = await chrome.storage.local.get([key, "kabbalot"]);
  const usage = stored[key] || {};
  usage[place] = (usage[place] || 0) + seconds;
  await chrome.storage.local.set({ [key]: usage });

  // A window kabbalah has no quota to exceed, so the day's total says nothing
  // about the promise and every day would look kept. What is counted instead
  // is the time spent inside the hours she said she is not here — the only
  // thing there is to keep or not keep. It is counted beside the day's usage,
  // never instead of it: the treasure screen still owes her those minutes.
  const k = kabbalahFor(session.url || "", stored.kabbalot || []);
  if (k?.rule?.kind !== "window") return;

  const end = new Date(now);
  if (!ruleWindowActive(k.rule, end)) return;

  // Only the part of this chunk that actually fell inside her hours. The
  // chunk covers the last `seconds` seconds; if the window opened partway
  // through it, the minutes before it opened were hers to spend and are not
  // a breach. Charging the whole chunk mattered: after the worker sleeps and
  // wakes, a chunk is the full MAX_CHUNK_SECONDS, which is exactly the two
  // minutes the day's judgement forgives — so a single second inside her
  // hours could spend the entire tolerance, and a minute of it could take
  // the day. Worst of all for a commitment kabbalah on a window rule, which
  // can never buy the extra graces × 5 and lives on those two minutes alone.
  //
  // The closing edge is deliberately not symmetrical: a chunk flushed after
  // the window has shut is not counted at all, so the last seconds before
  // closing time are forgiven. That errs in her favour, which is the only
  // direction this product is willing to be wrong in.
  const openedAt = windowStartedAt(k.rule, end);
  const breachSeconds = Math.round(
    (now - Math.max(now - seconds * 1000, openedAt.getTime())) / 1000
  );
  if (breachSeconds <= 0) return;

  // Keyed by the day these seconds were actually spent in — which, since #6,
  // is the same thing as the night they belong to.
  //
  // This line used to key by the day the window *opened* (dateStr(openedAt)),
  // and it had to: a 23:00–01:00 window sat through until half past midnight
  // was one sitting, and the calendar filed the second half under tomorrow —
  // two breaches, two falls, the second of them for time that belonged to the
  // first night. The day boundary now does that job properly. Her day ends at
  // DAY_RESET_HOUR, so 23:50 and 00:10 are the same day to begin with, and
  // keeping the old special case on top of it would double the correction:
  // an "all of Thursday" window opens at 00:00, which is Wednesday's day, and
  // Thursday evening's trespass would be filed against Wednesday.
  //
  // So there is now exactly one way a day is worked out in this file, and no
  // exceptions to it. If Sara answers #6 with midnight, an evening that runs
  // past twelve becomes two days again — but that is then what she has said a
  // day is, and the engine agreeing with her is the whole point.
  const breachKey = `breach:${dateStr(end)}`;
  const storedBreach = await chrome.storage.local.get(breachKey);
  const breach = storedBreach[breachKey] || {};
  breach[k.id] = (breach[k.id] || 0) + breachSeconds;
  await chrome.storage.local.set({ [breachKey]: breach });
}

async function setActiveTab(tab) {
  await migrated;
  await flushActiveTime();
  const url = (tab && tab.url) || "";
  const domain = domainOf(url);
  if (!domain) {
    await setSession(null);
    await checkSprint();
    return;
  }

  // Only what she named is measured. A site that belongs to no kabbalah is
  // none of this product's business, and not counting it is the same promise
  // as not sending it anywhere. A page on the same address but outside the
  // corner she chose is outside her kabbalah too, and stays uncounted.
  const kabbalot = await getKabbalot();
  const place = placeFor(url, allPlaces(kabbalot));

  // The session still has to say where she is — the browser-wide quiet hours
  // ask, and so does the next tick. But how much of "where" is needed depends
  // on whether the page is hers to account for. Inside a kabbalah the whole
  // address is needed, because a place can be one corner of a site
  // ("site.example/corner") and only the path can tell. Outside one, the
  // address alone is enough for every question anyone asks, so the path and
  // the query — the article she read, the account she opened, what she
  // searched for — are never written down at all.
  // The fallback is unreachable (a url that produced a domain parses), and it
  // is written to fail closed anyway: if it ever fired, storing the full url
  // would be the exact opposite of what this line is for.
  await setSession({
    url: place ? url : originOf(url) ?? `https://${domain}/`,
    domain,
    place,
    tabId: tab.id,
    since: Date.now(),
  });
  await checkSprint();
  await checkLimit();
}

// ---- "קבלה של עכשיו" — voluntary mini-commitment sprints ----
// Standing in it adds the minutes to her accumulating treasure. Breaking
// it is never a fall and never judged.

async function grantSprintIfDone() {
  const { sprint, treasureMinutes = 0 } =
    await chrome.storage.local.get(["sprint", "treasureMinutes"]);
  if (!sprint || Date.now() < sprint.until) return false;

  await chrome.storage.local.set({
    sprint: null,
    treasureMinutes: treasureMinutes + sprint.minutes,
  });
  await recordEvent("sprint_success", { minutes: sprint.minutes });

  // A sprint grows the treasure, never the road: the journey is measured in
  // days kept, the treasure in minutes returned.
  chrome.notifications?.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "עמדת בקבלה של עכשיו",
    message: `${sprint.minutes} דקות נוספו לאוצר שלך. איזה כוח יש לך.`,
  });
  return true;
}

async function checkSprint() {
  const { sprint } = await chrome.storage.local.get("sprint");
  if (!sprint) return;

  if (Date.now() >= sprint.until) {
    await grantSprintIfDone();
    return;
  }

  // Visiting any kabbalah place ends the sprint early — softly.
  const kabbalot = await getKabbalot();
  const session = await getSession();
  if (session?.url && placeFor(session.url, allPlaces(kabbalot))) {
    await chrome.storage.local.set({ sprint: null });
    const owner = kabbalahFor(session.url, kabbalot);
    await recordEvent("sprint_broken", { minutes: sprint.minutes }, owner?.id ?? null);
    chrome.notifications?.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "הקבלה של עכשיו הסתיימה מוקדם",
      message: "זה בסדר גמור. האוצר שלך שמור, וניסיון חדש מחכה לך",
    });
  }
}

// ---- gentle enforcement ----

// ---------- Fix (Founder Ruling 1, 2026-08-26) ----------
// docs/messages.md §7א, T-02/T-03 used to carry {{שם}} — the kabbalah's own
// name — in the title. That was safe when the name was always something
// she typed herself (a real nickname); it stopped being safe the moment
// nameFrom()'s own fallback (2026-08-25) started defaulting to the SITE
// itself. A desktop notification renders outside the browser entirely —
// docs/qa-full-day.md's own promise is that nothing here is readable by
// another person in the room without her having opened anything — and
// "עוד 10 דקות ביוטיוב" on her lock screen breaks that promise in a way a
// typed nickname never did.
//
// The fix is not to sanitise the name (strip anything that looks like a
// domain, guess whether it was typed or generated) — the founder's own
// instruction is explicit: do not do that, since she may have typed a real
// site name herself as her nickname on purpose, and this is about what the
// PRODUCT chooses to display, not about the name's own content. So the
// notification simply stops reading `name` at all: T-02/T-03 are reworded
// to the shape T-01 already uses ("...מהקבלה של היום") — approved, and
// already neutral, since it never named which kabbalah either. `k` is no
// longer read here at all — see notifyTenMinuteWarning's own signature.
//
// truncateName() (which existed only to clip {{שם}} for this one call
// site) is now dead — nothing here carries a name to clip — and is removed
// rather than kept as an unused fossil.
//
// UNAPPROVED: neither line below is docs/messages.md's own T-02/T-03 (which
// this replaces) or any other line in that document. Reviewed with
// avshalom-hebrew-expert, hebrew-writing-skill and make-human-lite; listed
// in the report for Sara's approval.
const TEN_MIN_NOTICES = [
  {
    title: "עוד 10 דקות מהקבלה של היום",
    message: "זמן טוב לסיים את מה שאת באמצע.",
  },
  {
    title: "10 הדקות האחרונות מהקבלה של היום",
    message: "בלי לחץ, רק שתדעי.",
  },
];

// A pool of two does not need docs/messages.md's full "no immediate repeat"
// history machinery (built for pools of seven-plus lines said many times a
// session) — this notice fires at most once a day per kabbalah, so a plain
// random pick already means she is unlikely to see the same line twice in a
// row across days, at a fraction of the storage and code.
function notifyTenMinuteWarning() {
  const { title, message } =
    TEN_MIN_NOTICES[Math.floor(Math.random() * TEN_MIN_NOTICES.length)];
  chrome.notifications?.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
  });
}

async function checkLimit() {
  const session = await getSession();
  if (!session?.domain || session.tabId == null) return;

  // One source of truth: the page asking on load and the minute tick must
  // never disagree about whether she is meant to be here right now.
  const state = await blockStateFor(session.url || `https://${session.domain}/`);

  if (state.blocked) {
    sendToTab(session.tabId, { type: "kabbalot-block", ...state });
    return;
  }
  if (state.graceUntil) return; // mid-grace: never interrupt a choice
  if (state.released) return; // issue #87: nothing is measured against her today

  const data = await chrome.storage.local.get([
    "kabbalot",
    todayKey(),
    "warnedOnBy",
  ]);
  const k = kabbalahFor(session.url || "", data.kabbalot || []);

  // The ten-minute warning belongs to the quota, and the check has to be
  // written down rather than assumed: a window rule carries no limitMinutes,
  // so without this line the arithmetic below runs on undefined and the right
  // answer arrives only because NaN happens to compare false. An hour she
  // named is not a countdown — she knows which hour she chose.
  if (!k || k.rule?.kind !== "dailyLimit") return;

  const usage = data[todayKey()] || {};
  // The warning belongs to the place she is on, when the kabbalah keeps a
  // number for it (issue #82): "ten minutes left" has to mean ten minutes
  // left *here*, or it arrives on the wrong page at the wrong moment.
  const { remainingMin } = remainingFor(k, usage, session.place || null);

  if (remainingMin > 0 && remainingMin <= 10) {
    const today = dateStr();
    const warnedOnBy = data.warnedOnBy || {};
    // One warning per kabbalah per day. The second kabbalah is not a repeat
    // of the first, and being warned about one must never be the reason the
    // other passes in silence.
    //
    // Shabbat is checked here too, and deliberately not folded into the
    // arithmetic above: nothing is measured during Shabbat (usedSeconds
    // cannot grow), but a session that was already inside its last ten
    // minutes on Friday afternoon keeps re-asking this same question on
    // every minute's tick straight through Shabbat, and each of those ticks
    // must land on "no". warnedOnBy is deliberately *not* marked in that
    // case either — the day's one warning is not spent on a notice that
    // never went out. So the very first tick after Shabbat ends (the
    // number has not moved, because nothing moved it) is the one that
    // actually sends it: suppressed for the length of Shabbat, not lost.
    if (warnedOnBy[k.id] !== today && !inShabbat(new Date(), await shabbatEdges())) {
      warnedOnBy[k.id] = today;
      await chrome.storage.local.set({ warnedOnBy });
      sendToTab(session.tabId, {
        type: "kabbalot-warning",
        remaining: Math.ceil(remainingMin),
      });
      // The in-page toast above only reaches her if she happens to be
      // looking at that tab; the browser notification (issue #21) is the
      // one that finds her anywhere. Never sent for a kabbalah that is
      // already blocked — unreachable here regardless, since state.blocked
      // returned out of this function before this code could run at all.
      notifyTenMinuteWarning();
    }
  }
}

// A grace that has run out should not sit in storage looking active.
async function releaseExpiredGrace() {
  const { graceUntil } = await chrome.storage.local.get("graceUntil");
  if (graceUntil && Date.now() >= graceUntil) {
    await chrome.storage.local.remove("graceUntil");
  }
}

function sendToTab(tabId, message) {
  if (tabId == null) return;
  chrome.tabs.sendMessage(tabId, message).catch(() => {
    // Tab may not have the content script (e.g. chrome:// pages) — fine.
  });
}

// Is this page inside the kabbalah, and is she past her time on it right
// now? A page asks this the moment it loads, so a reload cannot be a way
// out and a tab that was already open is not a blind spot.
// A quiet window is a different kind of commitment from a daily quota. A
// quota asks how much; a window says when. A woman who decided she is not
// there at four in the afternoon does not need a counter to tell her that.
//
// Stored as { days: [0-6], from: "16:00", to: "18:00" }, and browser-wide,
// full stop — #37 deleted the kabbalah-scoped variant, which promised an
// hour "only where there is a kabbalah" but could only ever test whether a
// page belonged to *some* kabbalah, not *which one*, so it silently quieted
// every kabbalah's places at once. Times are read on her own clock, like
// every other time here.
function minutesNow(d = new Date()) {
  return d.getHours() * 60 + d.getMinutes();
}

function parseClock(str) {
  const [h, m] = String(str).split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}

// ---- Shabbat (issue #6, proposal) ----
// Neither a quiet window nor a window rule, though it is written in the same
// two words. Those two block a page and say so on the screen. This one is
// quieter than either: inside it the product simply stops counting and stops
// keeping score, and the page in front of her is left exactly as it was. She
// is not asked to promise anything about hours nobody was watching, and she
// is not congratulated for them either.
//
// Blocking is deliberately left alone. A quota she had already spent on
// Friday morning still holds through Shabbat, and a window rule still says
// what it says — neither is a measurement and neither is a judgement, and
// the issue asks only that the measuring stop. A kabbalah that unlocked
// itself for a day and a half would be a promise the product broke on her
// behalf, which is not ours to do.

const MINUTES_PER_DAY = 24 * 60;
const MINUTES_PER_WEEK = 7 * MINUTES_PER_DAY;

// A moment, as minutes since Sunday 00:00 on her own clock.
function weekMinutes(d) {
  return d.getDay() * MINUTES_PER_DAY + minutesNow(d);
}

// Her two hours, or the defaults, field by field. A stored value has to
// look like a clock reading to be believed: anything else (a null left by a
// half-finished write, a number, a string she pasted by mistake) falls back
// to the default for that edge alone rather than taking the other one down
// with it. The one thing this must never do is return an arc of length
// zero, because that is a week with no Shabbat in it at all.
// A real clock reading, plus the one synthetic one this product needs:
// "24:00", the end of a day. The old shape of this pattern also let through
// 24:01 to 24:59, which are not times — and one of the combinations it
// admitted ({ fridayFrom: "24:00", motzashFrom: "00:00" }) produced an arc
// of length zero, the exact thing the paragraph above says must never
// happen.
const CLOCK_RE = /^(?:(?:[01]\d|2[0-3]):[0-5]\d|24:00)$/;

// ---- "00:00" AT THE MOTZASH EDGE MEANS MIDNIGHT AT THE END OF SHABBAT ----
//
// The bug this closes was one picker click wide and it pointed the wrong
// way, which is the only direction this product must never be wrong in.
//
// <input type="time"> cannot express the end of a day: its ceiling is 23:59
// and midnight comes back as "00:00". dashboard.js already knew that about
// the quiet-hours fields and normalised their closing time (normaliseWindowEnd
// there); the Shabbat fields on the same screen were left reading it raw.
//
// So a woman one click past 23:45 stored motzashFrom "00:00", which means
// Saturday 00:00 — Friday midnight — and the arc collapsed from thirty hours
// to nine:
//
//     motzash 21:00  →  arc 1800 min, Saturday keeps  360 measured minutes
//     motzash 23:45  →  arc 1965 min, Saturday keeps  180 measured minutes
//     motzash 00:00  →  arc  540 min, Saturday keeps 1440 — all of it
//
// inShabbat(Saturday 11:00) flipped to false. Shabbat daytime became
// measured, blockable and judged — and since a touched day can now record a
// fall (see evaluatePastDays), that day could break her streak, light the
// badge and put the morning-after screen in front of her, on Shabbat, while
// the settings screen echoed her choice back as though it had taken.
//
// Reading it as the end of Saturday is what she meant by picking midnight,
// and it is also the safe direction: it widens the arc rather than
// collapsing it. Normalised here rather than only in the screen, so a
// hand-edited profile gets the same reading the picker does.
//
// The Friday edge is deliberately NOT given this treatment. "00:00" there
// means Friday 00:00, which is a real and coherent choice — the widest arc
// she can open — and re-reading it as Friday midnight would silence a whole
// extra day she never asked to silence.
function normaliseEdges(stored) {
  const pick = (v, fallback) =>
    typeof v === "string" && CLOCK_RE.test(v) ? v : fallback;
  const motzash = pick(stored?.motzashFrom, SHABBAT_EDGES_DEFAULT.motzashFrom);
  return {
    fridayFrom: pick(stored?.fridayFrom, SHABBAT_EDGES_DEFAULT.fridayFrom),
    motzashFrom: motzash === "00:00" ? "24:00" : motzash,
  };
}

// Every caller of the four functions below is already an async function that
// touches storage, so the edges are read there and handed down rather than
// cached in a module variable: this is a service worker, and a module
// variable is gone thirty seconds after it is written.
async function shabbatEdges() {
  const { shabbatEdges: stored } = await chrome.storage.local.get("shabbatEdges");
  return normaliseEdges(stored);
}

// The minute יום שישי hands the week over, counted from Sunday 00:00.
function shabbatStartMinute(edges = SHABBAT_EDGES_DEFAULT) {
  return FRIDAY * MINUTES_PER_DAY + parseClock(edges.fridayFrom);
}

// How long it runs, in minutes: from the Friday hour to the motzash hour.
// Held as a length rather than as an end point, so nothing downstream has to
// re-derive where it closes.
//
// WHAT THE MODULO IS AND IS NOT DOING. SATURDAY is always the day after
// FRIDAY, so the subtraction below is positive in production and the
// `% MINUTES_PER_WEEK` never fires. An earlier version of this comment
// claimed a motzash hour set earlier in the clock than the Friday hour
// "goes the long way round" — it does not, and it should not: 21:00 Friday
// with a 09:00 motzash is a twelve-hour arc closing on Saturday *morning*,
// which is a strange thing to want but is exactly what those two numbers
// say. The wrap is kept only so the arithmetic is total rather than
// conditional.
//
// Math.max(1) is the floor under the promise normaliseEdges makes: an arc of
// length zero is a week with no Shabbat in it at all, and no reading of any
// two hours she can type should ever produce one. The tightened CLOCK_RE and
// the motzash normalisation both close that door already; this is the belt
// behind them, because the cost of being wrong here is a Shabbat the product
// measures straight through.
//
// It is genuinely unreachable as things stand, and deliberately NOT pinned by
// a test that would pretend otherwise: with the tightened pattern and the
// motzash re-reading both in place, an exhaustive sweep of every pair of
// hours those two admit produces no zero-length arc at all, so deleting this
// Math.max on its own passes the whole suite. It stays because the two guards
// in front of it are exactly the kind that get loosened by someone who has
// not read this far.
function shabbatLength(edges = SHABBAT_EDGES_DEFAULT) {
  const to = SATURDAY * MINUTES_PER_DAY + parseClock(edges.motzashFrom);
  return Math.max(
    1,
    (to - shabbatStartMinute(edges) + MINUTES_PER_WEEK) % MINUTES_PER_WEEK
  );
}

function inShabbat(now = new Date(), edges = SHABBAT_EDGES_DEFAULT) {
  const since =
    (weekMinutes(now) - shabbatStartMinute(edges) + MINUTES_PER_WEEK) %
    MINUTES_PER_WEEK;
  return since < shabbatLength(edges);
}

// How much of the last `seconds` before `now` was outside Shabbat.
//
// The two edges are not treated alike, and both errors run the same way — in
// her favour, which is the only direction this product is willing to be wrong
// in. A chunk still running when Shabbat opens is dropped whole, so the last
// minute or two before it are forgiven. A chunk that outlives havdalah keeps
// only the part after it, because two minutes is exactly the tolerance a
// day's judgement carries: charging her a whole slept-through chunk for a
// moment on the other side of the close could spend the lot, and for a
// commitment kabbalah on a window rule those two minutes are the entire
// allowance there is.
//
// The closing moment is searched for rather than worked out from the
// calendar, so that a Shabbat ending at midnight — where the second before it
// belongs to a different date than the second after — needs no special case.
function secondsOutsideShabbat(now, seconds, edges = SHABBAT_EDGES_DEFAULT) {
  if (inShabbat(new Date(now), edges)) return 0;
  let began = now - seconds * 1000;
  if (!inShabbat(new Date(began), edges)) return seconds;

  let ended = now;
  while (ended - began > 1000) {
    const mid = Math.floor((began + ended) / 2);
    if (inShabbat(new Date(mid), edges)) began = mid;
    else ended = mid;
  }
  return Math.round((now - ended) / 1000);
}

// How many of a day's minutes Shabbat covers — 0, all 1440, or something in
// between. The day named by `dayStr` runs twenty-four hours from
// DAY_RESET_HOUR, and the arithmetic is done on the week as a circle of
// minutes with the day's own start as zero, so the day is simply [0, 1440)
// and there is one comparison to get right instead of four.
function shabbatMinutesIn(dayStr, edges = SHABBAT_EDGES_DEFAULT) {
  const startsAt =
    parseDay(dayStr).getDay() * MINUTES_PER_DAY + DAY_RESET_HOUR * 60;
  const from =
    (shabbatStartMinute(edges) - startsAt + MINUTES_PER_WEEK) % MINUTES_PER_WEEK;
  const length = shabbatLength(edges);

  let covered = Math.max(
    0,
    Math.min(from + length, MINUTES_PER_WEEK, MINUTES_PER_DAY) - from
  );
  // The part that ran past the end of the week and came round to its start —
  // which is where Saturday's own minutes live, the day's zero being Saturday
  // at three in the morning and the week's zero being Sunday at midnight.
  if (from + length > MINUTES_PER_WEEK) {
    covered += Math.min(from + length - MINUTES_PER_WEEK, MINUTES_PER_DAY);
  }
  return Math.min(covered, MINUTES_PER_DAY);
}

function windowLabel(w) {
  return `${w.from}–${w.to}`;
}

// Returns the window she is inside right now, or null.
//
// The weekday read here is the calendar's, not DAY_RESET_HOUR's, and that is
// deliberate: a woman who says "not on Tuesdays, from eleven at night" means
// the Tuesday on her wall, and the hours after midnight are already carried
// by the overnight branch below. Reading the day-boundary weekday here would
// shift that same window a second time and make an hour she chose land on
// the wrong night.
function activeWindow(windows, now = new Date()) {
  const day = now.getDay();
  const mins = minutesNow(now);
  for (const w of windows || []) {
    if (!w || !w.from || !w.to) continue;
    // A stored window that still carries the old scope: "kabbalah" field
    // (#37 — a machine that saved one before the concept was deleted) is
    // read the same as any other window here: `w.scope` is simply never
    // looked at, so it applies browser-wide like everything else in this
    // list, rather than crashing or silently keeping the old, narrower
    // promise it used to make.
    const from = parseClock(w.from);
    const to = parseClock(w.to);

    // A window that ends before it starts runs through midnight, and the
    // part after midnight belongs to the day it started on.
    const overnight = to <= from;
    const startedToday = (w.days || []).includes(day);
    const startedYesterday = (w.days || []).includes((day + 6) % 7);

    if (!overnight) {
      if (startedToday && mins >= from && mins < to) return w;
    } else {
      if (startedToday && mins >= from) return w;
      if (startedYesterday && mins < to) return w;
    }
  }
  return null;
}

// Between them these two answer one question: right now, on this kabbalah, is
// she past what she set? A quota asks how much and needs the day's usage; a
// window asks when and needs only the clock — both read on her own clock, as
// everything here does.

// The hours of one kabbalah's own window rule. Not to be confused with
// `quietWindows`, which is a separate, browser-wide setting with its own
// storage key and its own reason on the page. The two used to almost
// collide — a `scope: "kabbalah"` quiet window tried to say the same thing
// this rule says, and got it wrong (#37) — but that concept is gone now,
// and activeWindow no longer takes anything but the windows and the clock.
function ruleWindowActive(rule, now = new Date()) {
  return Boolean(
    activeWindow([{ days: rule.days, from: rule.from, to: rule.to }], now)
  );
}

// The moment the window she is inside right now opened. Read by the same
// rule activeWindow judges by: a window that ends before it starts runs
// through midnight, and the part after midnight belongs to the day it
// started on. Only meaningful while the window is actually active.
//
// It has one job now: telling flushActiveTime how much of the chunk in hand
// fell after the window opened. It used to name the day a breach was filed
// under as well — that is how one evening was kept one evening, back when
// the day ended at midnight — and since #6 the day boundary answers that on
// its own. See the note at the breach key.
function windowStartedAt(rule, now = new Date()) {
  const from = parseClock(rule.from);
  const to = parseClock(rule.to);
  const overnight = to <= from;
  const dayOffset = overnight && minutesNow(now) < to ? -1 : 0;
  // The Date constructor normalises: minute 1380 becomes 23:00, and day 0
  // becomes the last of the month before.
  return new Date(now.getFullYear(), now.getMonth(), now.getDate() + dayOffset, 0, from);
}

// ---- issue #82: reading a kabbalah that carries per-place targets ----
//
// The rebuilt onboarding writes `placeGoals` — one entry per place, each
// with the minutes she said she spends there, the minutes she asked to have
// back, and the difference, which is that place's own daily limit. The
// kabbalah's `rule.limitMinutes` is the sum of those differences, so nothing
// that already read the total is reading anything new.
//
// The five functions below are the only places the difference is felt, and
// all five go through these three helpers so they cannot disagree with each
// other about what she promised.

// [[place, limitMinutes], …], or null when this kabbalah carries no usable
// per-place numbers: a record from before this build, a migrated one, or one
// whose goals do not cover every place it actually watches. All-or-nothing on
// purpose — judging half her places by their own targets and the other half
// by a shared total is a rule nobody could explain to her.
function placeLimits(k) {
  const goals = k?.placeGoals;
  if (!goals || typeof goals !== "object") return null;
  const pairs = [];
  for (const place of k.places || []) {
    const goal = goals[place];
    if (!goal || typeof goal.limitMinutes !== "number") return null;
    pairs.push([place, goal.limitMinutes]);
  }
  return pairs.length ? pairs : null;
}

function minutesOn(place, usage) {
  return (usage[place] || 0) / 60;
}

function minutesAcross(k, usage) {
  return (k.places || []).reduce((sum, p) => sum + (usage[p] || 0), 0) / 60;
}

// Was the day kept? `allowance` is the minutes forgiven on top of what she
// promised — the graces she actually bought, plus the rounding tolerance the
// day's judgement has always carried.
//
// One decision worth naming: under per-place judgement the allowance widens
// *every* place, not the one she happened to buy it on. The grace ledger has
// never known which place a five-minute extension was spent at (graceOn is
// keyed by kabbalah, #13), and inventing that knowledge here would mean
// guessing. Widening everything errs in her favour, which is the only
// direction this file is willing to be wrong in.
const DAY_TOLERANCE_MINUTES = 2;

function keptToday(k, usage, allowance) {
  const limits = placeLimits(k);
  if (!limits || FALL_ON === "total") {
    return minutesAcross(k, usage) <= k.rule.limitMinutes + allowance;
  }
  const over = limits.filter(([p, lim]) => minutesOn(p, usage) > lim + allowance);
  return FALL_ON === "every-place" ? over.length < limits.length : over.length === 0;
}

// Takes the kabbalah, not the rule — it needs the places to add up her day.
// `place` is the one she is standing on right now, when the caller knows it:
// under "any-place" the stop page belongs on the place that is actually over,
// and a sibling place having gone over is not a reason to shut a page she has
// kept her promise on. Callers that have no page in hand (nothing does today,
// but the default has to mean something) get "is she past any of them".
function pastHerRule(k, usage = {}, now = new Date(), place = null) {
  if (k.rule?.kind === "window") return ruleWindowActive(k.rule, now);
  const limits = placeLimits(k);
  if (limits && FALL_ON === "any-place") {
    if (!place) return limits.some(([p, lim]) => minutesOn(p, usage) >= lim);
    const own = limits.find(([p]) => p === place);
    // A page belonging to this kabbalah that its goals do not name cannot be
    // judged by them; the total is the honest fallback.
    if (own) return minutesOn(place, usage) >= own[1];
  }
  return minutesAcross(k, usage) >= k.rule.limitMinutes;
}

// What is left, and out of what — the two numbers the floating timer shows
// and the ten-minute warning counts down. Per place under "any-place", so a
// woman on her mail is told about her mail and not about the video she
// watched this morning.
function remainingFor(k, usage, place) {
  const limits = placeLimits(k);
  if (limits && FALL_ON === "any-place" && place) {
    const own = limits.find(([p]) => p === place);
    if (own) return { remainingMin: own[1] - minutesOn(place, usage), quotaMin: own[1] };
  }
  return {
    remainingMin: k.rule.limitMinutes - minutesAcross(k, usage),
    quotaMin: k.rule.limitMinutes,
  };
}

async function blockStateFor(url) {
  const domain = domainOf(url);
  // Every page load and every minute's tick runs through here, so the
  // released check below rides this same get() rather than opening a
  // second sequential round trip through dayReleased() for a key this call
  // was already going to fetch.
  //
  // FINDING 10 (whole-branch review) — this is today's key, exactly, and a
  // release inside the 03:00 carryover grace can be filed under yesterday's
  // instead (see the broadcast listener's own note below for the full
  // explanation). A tab open in the few minutes after such a release would
  // not see it lifted here — the new product day's own quota is fresh
  // regardless, so the practical difference is small, but it is the one
  // place this file and popup.js key the same press on different days.
  const releasedTodayKey = releasedKey(dateStr());
  const data = await chrome.storage.local.get([
    "kabbalot",
    "quietWindows",
    "graceUntil",
    todayKey(),
    weekKey(),
    releasedTodayKey,
  ]);
  const kabbalot = data.kabbalot || [];
  const k = kabbalahFor(url, kabbalot);

  // issue #87 — a day she released is a day the product stops stopping her:
  // every kabbalah, commitment included, and the browser's quiet hours too.
  // The alternative the valve replaces is removing the extension, which
  // releases all of them at once and for good; a valve that left one door
  // shut would send her straight there. `released` travels with the answer
  // so checkLimit below knows not to follow up with the ten-minute warning.
  if (data[releasedTodayKey]) return { blocked: false, released: true };

  // מצב מחויבות: what she set is final until tomorrow, so there is nothing to
  // offer — and the engine must not offer what it will then refuse. The check
  // rides along with the quiet hours too: a page belonging to a commitment
  // kabbalah gets no button there either, because the grace it would ask for
  // is refused by owner, whichever screen asked.
  const committed = k?.mode === "commitment";

  // An active grace covers everything — she made a conscious choice and the
  // product does not argue with it twice. Everything except a kabbalah she
  // put in commitment: graceUntil is one timestamp for the whole browser, so
  // without this the five minutes she bought anywhere at all — on another
  // kabbalah, or on a stranger's site to pass the quiet hours — would open
  // the door she said was closed until tomorrow. Refusing her the button and
  // then letting her in through someone else's is not a promise kept.
  if (!committed && data.graceUntil && Date.now() < data.graceUntil) {
    return { blocked: false, graceUntil: data.graceUntil };
  }

  // Her own hour comes before any counter: inside a window she has not
  // exceeded anything, she is keeping exactly what she set.
  //
  // The order here is deliberate — an active grace, then the browser's quiet
  // hours, then the kabbalah's own rule. When a quiet window and a kabbalah's
  // window rule both cover the same page, quiet hours answer first: that is
  // the broader promise, the one she made about her whole browser, and the
  // narrower one cannot say anything it does not already say.
  if (domain) {
    const win = activeWindow(data.quietWindows);
    if (win) {
      const graceUsed = data[weekKey()] || 0;
      return {
        blocked: true,
        reason: "window",
        mode: k?.mode || "companion",
        windowLabel: windowLabel(win),
        graceLeft: committed ? 0 : Math.max(GRACE_POOL_PER_WEEK - graceUsed, 0),
      };
    }
  }

  if (!k) return { blocked: false };

  const usage = data[todayKey()] || {};
  // The place this very page belongs to, so that a kabbalah with several of
  // them stops her on the one she has actually spent (issue #82) — not on a
  // sibling she has kept her promise on all day.
  if (!pastHerRule(k, usage, new Date(), placeFor(url, k.places))) {
    return { blocked: false };
  }

  const graceUsed = data[weekKey()] || 0;
  return {
    blocked: true,
    reason: k.rule?.kind === "window" ? "rule-window" : "quota",
    // Fix (Founder Ruling 1, 2026-08-26): this used to be `kabbalahName:
    // k.name` — the kabbalah's own name, painted onto the "kicker" badge
    // on the host page's block overlay (content.js's showOverlay). That
    // overlay sits on top of a site she may be showing someone else, the
    // same reason the desktop notification (notifyTenMinuteWarning, above)
    // no longer carries a name either. `kabbalahId` is only ever used to
    // tell "there is an owning kabbalah" apart from "this is a browser-wide
    // quiet-hours block with no single owner" — content.js's own kicker
    // reads that presence, never the id's own value, and paints a fixed,
    // neutral phrase.
    kabbalahId: k.id,
    mode: k.mode || "companion",
    windowLabel: k.rule?.kind === "window" ? windowLabel(k.rule) : undefined,
    // In commitment there is nothing to offer: what she set is final until
    // tomorrow. That is the whole difference between the two modes, and the
    // engine is where the promise is kept — not the page.
    graceLeft: committed ? 0 : Math.max(GRACE_POOL_PER_WEEK - graceUsed, 0),
    timeGotBack:
      k.rule?.kind === "window" || !k.baselineMinutes
        ? null
        : k.baselineMinutes - k.rule.limitMinutes,
  };
}

// ---- the floating timer (issue #21, docs/messages.md §7ג, T-09) ----
// "נשארו לך {{נותר}} מתוך {{מכסה}}" is written for a quota — there
// is no "out of" for an hour range, and no approved line for one — so this
// is scoped to dailyLimit kabbalot only. A window kabbalah keeps the stop
// screen exactly as it already had it; it simply never grows a floating
// timer, on purpose, rather than inventing a shape for it messages.md
// does not carry.
async function timerFor(url) {
  const data = await chrome.storage.local.get(["kabbalot", todayKey()]);
  const k = kabbalahFor(url, data.kabbalot || []);
  if (!k || k.rule?.kind !== "dailyLimit") return null;

  // issue #87 — same promise as Shabbat below: a released day is not being
  // counted, so nothing on her screen may look as though it is.
  if (await dayReleased()) return null;

  // The same promise Shabbat makes everywhere else in this file: nothing is
  // measured, so nothing is shown that would look like measuring is still
  // happening. A frozen countdown sitting in the corner of her screen through
  // Shabbat would say "we are still counting" in a way silence does not —
  // and unlike the ten-minute warning, there is no later catch-up to build
  // here: the timer is not an event that was missed, it is a display that
  // simply has nothing true to show while Shabbat runs, and reappears on its
  // own the moment a normal poll lands after havdalah.
  if (inShabbat(new Date(), await shabbatEdges())) return null;

  const usage = data[todayKey()] || {};
  const own = remainingFor(k, usage, placeFor(url, k.places));
  const remainingMin = Math.max(0, Math.round(own.remainingMin));
  // At or past the quota the stop screen is already the truth on this page;
  // a timer reading "0 נשארו" beside it would be saying the same thing
  // twice, once honestly and once as a countdown that has nowhere left to go.
  if (remainingMin <= 0) return null;

  // Fix (Founder Ruling 1, 2026-08-26): `kabbalahId`, not `kabbalahName` —
  // the floating timer pill (content.js) never paints a name on screen, but
  // it used to carry one anyway, purely as an identity key (telling "the
  // same kabbalah, a fresher answer" apart from "a different kabbalah,
  // rebuild the pill" across its 30-second polls, and remembering which
  // kabbalah's pill she dismissed). Carrying the name at all for that job
  // was needless exposure once the name can be a site — the id already
  // identifies a kabbalah uniquely and is never displayed anywhere.
  return { remainingMin, quotaMin: own.quotaMin, kabbalahId: k.id };
}

// ---- the daily check-in reminder (issue #21, docs/messages.md §7ב) ----
// One check-in a day, for everything — not one per kabbalah
// (design/README.md decision: "צ׳ק-אין אחד ביום על הכל, לא אחד לכל קבלה").
// reminderHour is the hour she chose during onboarding (#15); nothing in the
// engine read it until now.
//
// This is deliberately the one component of #21 with the most power to do
// harm: an unprompted notification, arriving on its own, possibly on a lock
// screen someone else can see, in a house with other people in it. Discretion
// is not a nicety here, it is the whole feature, and three decisions follow
// from that:
//   1. It respects Shabbat and her own quiet hours, the same as everything
//      else that would otherwise announce itself (see below).
//   2. It fires once a day, gated the same way warnedOnBy gates the
//      ten-minute warning — a stored day marker, checked before anything is
//      sent and set only on the line that actually sends it.
//   3. It does not invent a time. reminderHour already exists (#15) and is
//      the one value this mechanism reads; nothing here makes up a default
//      schedule of its own beyond the 20:00 fallback #15 itself already
//      documents for a device that predates that question.
//
// What it does not do: know whether she has already answered today's
// check-in. No screen in this codebase writes that yet — the check-in card
// itself does not exist (see the PR report's boundary note on #16/#19) — so
// "stops the moment she marks it" cannot be built from inside this file
// without guessing at a key name that belongs to whoever builds that screen.
// A future check-in screen should write a same-day marker of its own and
// this function should read it, right where CHECKIN_BODIES is chosen below.

// Mirrors popup.js's greetingByHour() — duplicated, not imported, because
// this project has no module system and background.js and popup.js are
// separate script contexts (the same reason DAY_RESET_HOUR is mirrored in
// shared.js and export.js rather than shared).
function greetingByHour(now = new Date()) {
  const h = now.getHours();
  if (h < 12) return "בוקר טוב";
  if (h < 17) return "צהריים טובים";
  return "ערב טוב";
}

// docs/messages.md §7ב, T-05/T-06/T-07 — one opening line (the greeting,
// above) and three bodies. T-08 ("לא הספקנו אתמול", two days running
// unmarked) is not used: it needs to know whether yesterday's check-in was
// answered, which is exactly the state this file cannot see (above).
// Reaching for it here would be guessing at a fact, not reading one.
const CHECKIN_BODIES = [
  "איך עבר היום עם הקבלה? לחיצה קטנה — וסיימנו.", // T-05
  "שאלה אחת ואת חופשייה: איך היה היום?", // T-06
  "רגע לפני שאת סוגרת את היום, איך הלך?", // T-07
];

const CHECKIN_NOTIFICATION_ID = "kabbalot-checkin-reminder";
const DEFAULT_REMINDER_HOUR = 20; // #15's own fallback for a device that predates the question.

// C2-follow-up (2026-08-23, Sara): "אני רוצה שיהיה אפשר גם לבחור חלקי שעות
// כמו רבע שעה חצי שעה וכזה, לא רק שעות עגולות". reminderHour used to be
// guarded with Number.isInteger everywhere, so 20.25 would have been thrown
// away silently and she would have got 20:00 back without being told. It is
// a number of hours still — 20.25 is a quarter past eight in the evening,
// not a count of quarter-hour ticks — read here in minutes so the comparison
// against the wall clock has the same granularity the picker offers.
//
// The bounds are the picker's (REMINDER_FLOOR/REMINDER_CEIL in dashboard.js
// and onboarding.js); this only has to survive whatever reaches storage, so
// anything that is not a finite number inside a plausible day falls back.
function reminderMinuteOf(stored) {
  const h = Number(stored);
  if (!Number.isFinite(h) || h < 0 || h >= 24) return DEFAULT_REMINDER_HOUR * 60;
  return Math.round(h * 60);
}

async function maybeSendCheckinReminder() {
  const data = await chrome.storage.local.get([
    "kabbalot", "reminderHour", "checkinRemindedOn", "quietWindows",
    "shabbatEdges",
  ]);
  const kabbalot = data.kabbalot || [];
  if (!kabbalot.length) return; // nothing to check in about yet

  const now = new Date();
  // Minutes, not whole hours: a reminder she set for 20:30 must not go out
  // at 20:00. minutesNow is the same reading activeWindow judges her quiet
  // hours by, so the two cannot drift apart about what "now" is.
  //
  // ---- and the tail of the product day counts as "her hour has passed" ----
  //
  // Her day does not end at midnight (DAY_RESET_HOUR), and until this was
  // written the reminder's clock check pretended it did: at 00:30 the minute
  // count had reset to 30, her 22:30 had "not come yet", and the day's
  // reminder was gone.
  //
  // That was survivable while the quiet-hours ceiling was 23:00, because
  // there was always a minute of the evening left after any window closed.
  // Raising the ceiling to 24:00 removed the guarantee: quiet 22:00–24:00
  // with a reminder at 22:30 was suppressed until midnight and then silently
  // lost — and because checkinRemindedOn is only written on the line that
  // actually sends, it was lost again the next day, and every day, without a
  // single thing on any screen saying so. That contradicts the promise three
  // paragraphs below ("delays the reminder, it does not eat it") and the
  // shipped privacy policy in both languages.
  //
  // THE FIX, AND WHY NOT THE OTHER TWO. Firing at the window's last minute
  // would keep this promise by breaking the louder one — a notification
  // inside the hours she asked the browser to be quiet. Refusing the pair in
  // the picker would make her solve a clock puzzle to save a setting. The
  // honest answer is that the minutes between midnight and DAY_RESET_HOUR
  // are still today, they are outside a window that closed at 24:00, and her
  // hour passed hours ago — so the reminder lands there, and dateStr() files
  // it under the same product day it was always meant for.
  //
  // A woman whose quiet hours cover midnight through DAY_RESET_HOUR as well
  // has genuinely asked for silence across every hour that is left, and gets
  // it. That is her configuration now, not a hidden consequence of a ceiling.
  const target = reminderMinuteOf(data.reminderHour);
  const nowMinutes = minutesNow(now);
  const dayTail = DAY_RESET_HOUR * 60;
  //
  // issue 142: Sara removed the picker's 17:00 floor, and that made a whole
  // class of hour reachable for the first time — one that lives INSIDE the
  // tail, below DAY_RESET_HOUR. Those hours sit at the END of the product day
  // they belong to, not the start, and the old single comparison read them
  // backwards: `nowMinutes >= target` is true all day long for a target of
  // 01:00, so her reminder would have gone out at 03:01, the first tick after
  // the day turned, every day, and nothing on any screen would have said why.
  // It was unreachable before only because the picker refused to go there.
  const inTail = nowMinutes < dayTail;
  const herHourHasPassed = target >= dayTail
    ? inTail || nowMinutes >= target
    : inTail && nowMinutes >= target;
  if (!herHourHasPassed) return;

  const today = dateStr();
  if (data.checkinRemindedOn === today) return; // already sent today

  // Neither suppression below loses the day's reminder — it only delays it.
  // checkinRemindedOn is set on the one line that actually sends the
  // notification, so the very next time this runs after Shabbat ends, or
  // after her quiet hours close, asks the same question again and (assuming
  // her hour has already passed, which it has if it was suppressed) sends
  // it then. A reminder that fires the instant Shabbat or quiet hours end is
  // the deliberate choice here, over silently skipping the day: the promise
  // is "once a day", not "once a day, unless the timing was inconvenient".
  if (inShabbat(now, normaliseEdges(data.shabbatEdges))) return;
  // The browser's own quiet hours, same as every other place in this file
  // that checks them.
  if (activeWindow(data.quietWindows, now)) return;

  // ---- the ordering question, settled ----
  // The merge that brought the fall screen and this reminder into the same
  // boot chain left a comment saying the order was "deliberate but not yet
  // load-bearing". It is load-bearing now, and the answer is not really
  // about order — it is that these two must not both speak on the same day.
  //
  // Three reasons, in the order they convinced me:
  //
  // 1. THIS NOTIFICATION CANNOT DELIVER WHAT IT PROMISES while a fall is
  //    unanswered. It says "איך עבר היום עם הקבלה? לחיצה קטנה — וסיימנו",
  //    and its click handler opens the popup — where showHome() puts the
  //    morning-after screen in front of everything else until she answers
  //    it. So the small click does not finish anything; it lands her on the
  //    hardest screen in the product, which she was not asked about. That is
  //    not a matter of taste. The offer is false while this is true.
  // 2. It asks about today before she has been given the chance to answer
  //    for yesterday. The product should say one thing at a time on this
  //    particular morning.
  // 3. She is not left un-nudged in the meantime: the badge is already lit
  //    (syncFallBadge), which is the quieter signal and the one that is
  //    actually about the thing that is waiting.
  //
  // This delays the reminder, it does not eat it — the same promise the
  // Shabbat and quiet-hours suppressions above make, kept the same way.
  // checkinRemindedOn is still only written on the line that actually sends,
  // so the moment she answers the fall screen the next tick sends her that
  // day's reminder as usual, if her hour has passed. A woman who never
  // answers loses the reminder for as long as she does not, which is the
  // right trade: the product has something more important waiting for her,
  // and it is already saying so.
  if (kabbalot.some((k) => k.fellOn && !k.fallAcked)) return;

  // issue #87 — "איך עבר היום עם הקבלה?" has no honest answer on a day she
  // released, and the engine spec is explicit that the product never
  // reminds her of anything about that day. Not marked as sent: the day
  // simply has no reminder.
  if (await dayReleased(today)) return;

  await chrome.storage.local.set({ checkinRemindedOn: today });
  const body = CHECKIN_BODIES[Math.floor(Math.random() * CHECKIN_BODIES.length)];
  chrome.notifications?.create(CHECKIN_NOTIFICATION_ID, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: greetingByHour(now),
    message: body,
  });
}

// The 5-minute grace: counted transparently, capped per week, never a fall.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "kabbalot-status") {
    (async () => {
      await migrated;
      const url = msg.url || sender.tab?.url || "";
      const state = await blockStateFor(url);
      // A page under the stop screen already shows the truth; the timer
      // would only be repeating it in a smaller, more optimistic font.
      state.timer = state.blocked ? null : await timerFor(url);
      sendResponse(state);
    })();
    return true;
  }

  if (msg.type === "kabbalot-grace") {
    (async () => {
      await migrated;
      const kabbalot = await getKabbalot();
      const owner = kabbalahFor(sender.tab?.url || "", kabbalot);

      // מצב מחויבות — "בלי הארכות, סופי עד מחר". The button is not offered
      // on a commitment page, so this is the stale tab, the reload, the
      // second window left open since yesterday. She gets the same answer
      // she would have got had she never seen a button at all.
      // The reason travels with the refusal. Without it this reply is byte
      // for byte the pool-exhausted one, and the page answers that with
      // "חריגות השבוע נוצלו" — which would be a plain untruth here: her
      // graces were never used up, they were never on offer.
      if (owner?.mode === "commitment") {
        sendResponse({ ok: false, left: 0, reason: "commitment" });
        return;
      }

      const wk = weekKey();
      const data = await chrome.storage.local.get(wk);
      const used = data[wk] || 0;
      if (used >= GRACE_POOL_PER_WEEK) {
        sendResponse({ ok: false, left: 0 });
        return;
      }
      const graceDayKey = `graceOn:${dateStr()}`;
      const dayData = await chrome.storage.local.get(graceDayKey);
      const graceUntil = Date.now() + GRACE_MINUTES * 60 * 1000;
      const updates = { [wk]: used + 1, graceUntil };

      // The pool is shared and the forgiveness is not — two separable
      // decisions, and this is the deliberate combination. The week's budget
      // is one budget for all her kabbalot (that is decision 4), but at day's
      // end these five minutes widen only the kabbalah she asked them of,
      // because a fall in one never touches another (decision 3).
      //
      // Three scopes meet here and they are deliberately not the same size:
      //   · the pool it is bought from — the week, all her kabbalot together
      //   · the door it opens (graceUntil) — the browser, right now, because
      //     she asked to be let through and being let through one page at a
      //     time would be a nagging she did not agree to. A commitment
      //     kabbalah is the one exception, and blockStateFor keeps it.
      //   · the day it forgives (here) — the one kabbalah she asked
      // So a grace bought on a page in no kabbalah opens doors and forgives
      // nobody: it still costs her the week, and no kabbalah's day was
      // involved in the asking. That is the honest edge of the asymmetry,
      // not an oversight.
      if (owner) {
        const previous = dayData[graceDayKey];
        const graceOn = {};
        if (typeof previous === "number") {
          // A day that began on the old build carries one number: the count
          // everyone was forgiven. Spread it back over the kabbalot as they
          // stood, so upgrading mid-day takes nothing away from a day already
          // half-lived, and only what happens from here is charged to one.
          for (const other of kabbalot) graceOn[other.id] = previous;
        } else {
          Object.assign(graceOn, previous || {});
        }
        graceOn[owner.id] = (graceOn[owner.id] || 0) + 1;
        updates[graceDayKey] = graceOn;
      }
      await chrome.storage.local.set(updates);
      await recordEvent("grace", {}, owner?.id ?? null);

      // She asked for the five minutes and they were counted against her
      // week — so the screen has to go, and it must not depend on this reply
      // surviving the trip back. Tell the tab directly as well.
      sendToTab(sender.tab?.id, { type: "kabbalot-release", graceUntil });
      sendResponse({ ok: true, left: GRACE_POOL_PER_WEEK - used - 1 });
    })();
    return true; // async response
  }

  // issue #30 — read-only: is this the moment to raise the offer of a second
  // kabbalah, and about which one. A query rather than a value popup.js
  // recomputes on its own (unlike stationsReached/currentStage, which it
  // already does mirror): the decline cooldown is a plain timestamp
  // comparison against Date.now(), no different in kind from graceUntil, and
  // keeping the one comparison here — beside SECOND_OFFER_MIN_GOOD_WEEKS and
  // SECOND_OFFER_DECLINE_WEEKS, which live here too — means there is exactly
  // one place this decision is made, not a copy that can drift from it.
  if (msg.type === "kabbalot-second-offer") {
    (async () => {
      await migrated;
      sendResponse(await secondOfferStatus());
    })();
    return true;
  }

  // issue #30 — she said not now. The offer is not gone, only postponed: two
  // weeks, the same duration the issue itself states, kept as a plain
  // millisecond deadline rather than a week label, because "in two weeks" is
  // a length of time she was told, not a boundary tied to Sunday.
  if (msg.type === "kabbalot-second-offer-decline") {
    (async () => {
      await migrated;
      const until = Date.now() + SECOND_OFFER_DECLINE_WEEKS * 7 * 24 * 60 * 60 * 1000;
      await chrome.storage.local.set({ secondOfferDeclinedUntil: until });
      sendResponse({ ok: true, until });
    })();
    return true;
  }
});

// ---- wiring ----

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  await setActiveTab(tab);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url && tab.active) await setActiveTab(tab);
});

chrome.idle.setDetectionInterval(IDLE_THRESHOLD_SECONDS);
chrome.idle.onStateChanged.addListener(async (state) => {
  if (state === "active") {
    const [tab] = await chrome.tabs.query({
      active: true,
      lastFocusedWindow: true,
    });
    await setActiveTab(tab);
  } else {
    // She stepped away from the machine. Close the session so the minutes
    // she is not there are not counted against her.
    await flushActiveTime();
    await setSession(null);
  }
});

// Flush + check every minute so data survives service-worker restarts
// and the block lands within a minute of the quota ending.
chrome.alarms.create("tick", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  await migrated;
  if (alarm.name === VALVE_ALARM) {
    await markValveReady();
    return;
  }
  if (alarm.name === "tick") {
    await evaluatePastDays();
    await flushActiveTime();
    // If this instance woke with nothing to track but a tab is in front of
    // her right now, start counting again rather than waiting for her to
    // switch tabs.
    const session = await getSession();
    if (!session) await resumeSession();
    else await followActiveTab(session);
    await checkSprint();
    await checkLimit();
    await releaseExpiredGrace();
    // Runs every minute like everything else above, and is its own no-op
    // once the day already sent its one reminder (checkinRemindedOn) — the
    // same shape as pruneDaily() below it. This is also what makes "the
    // computer was off at the hour" work: the first tick after any wake
    // re-asks the question fresh, and either the hour has now passed and it
    // sends, or it has not and it waits for a tick that finds it has.
    await maybeSendCheckinReminder();
    await pruneDaily();
  }
});

// She clicked the check-in reminder. The popup itself does not yet have a
// screen to land her on the check-in question (that card does not exist —
// see the PR report's boundary note on #16/#19), so this can only open the
// popup, not focus a specific question inside it; whoever builds that
// screen should route this same click there. chrome.action.openPopup()
// needs no extra manifest permission (the "action" key already grants it)
// and can fail outside a few trusted contexts, so a tab is the fallback
// rather than leaving the click silently do nothing.
chrome.notifications?.onClicked?.addListener(async (notificationId) => {
  if (notificationId !== CHECKIN_NOTIFICATION_ID) return;
  chrome.notifications.clear(notificationId);
  let opened = false;
  if (chrome.action?.openPopup) {
    opened = await chrome.action
      .openPopup()
      .then(() => true)
      .catch(() => false);
  }
  if (!opened) {
    chrome.tabs?.create({ url: chrome.runtime.getURL("popup.html") });
  }
});

// A page can change under her without a tab switch and without a reload. On
// a site that rewrites its own address bar — YouTube going from a Short to a
// full video — nothing loads, so nothing here would hear about it, and her
// minutes would keep piling onto the corner she has already left. When the
// kabbalah is one corner of an address and not the whole of it, that is the
// whole difference. So once a minute we simply ask the tab in front of her
// what it is showing now, and if it has moved on, the time moves with it.
//
// "Moved on" has to mean moved between places, not just between raw URLs.
// setActiveTab (issue #13) stores only the origin for a page outside every
// kabbalah — the path and query are never written down — while it still
// stores the full URL for a page inside one, where the path is what tells
// two corners apart. So on any page outside every kabbalah, tab.url and
// session.url differ by design even when nothing moved, and comparing them
// raw would call every quiet tick a navigation. Comparing the normalized
// place instead asks the only question that actually matters: does this url
// still attribute to what the session already has open.
async function followActiveTab(session) {
  const [tab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true,
  });
  // No tab in front of her at all is not a page we can go on counting — it
  // is nowhere. resumeSession answers this same question by closing the
  // session, and two answers to one question is how a bug gets in later.
  if (!tab) {
    await flushActiveTime();
    await setSession(null);
    return;
  }
  const kabbalot = await getKabbalot();
  if (
    tab.id !== session.tabId ||
    placeFor(tab.url, allPlaces(kabbalot)) !== session.place
  ) {
    await setActiveTab(tab);
  }
}

// A session left behind by a previous instance says where she *was*, not
// where she is. Every wake-up re-reads the world instead of trusting it.
async function resumeSession() {
  await flushActiveTime();
  const state = await chrome.idle.queryState(IDLE_THRESHOLD_SECONDS);
  if (state !== "active") {
    await setSession(null);
    return;
  }
  const [tab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true,
  });
  if (tab) await setActiveTab(tab);
  else await setSession(null);
}

// A minimised browser, or one sitting behind another window, is not time
// she is spending there.
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await flushActiveTime();
    await setSession(null);
  } else {
    await resumeSession();
  }
});

// Chrome only runs a content script into pages loaded after the extension
// was installed. Every tab already open at that moment has nothing in it —
// so the one page she happened to be sitting on when she installed would
// never be accompanied, and after every update the same gap reopens.
async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs
    .query({ url: ["http://*/*", "https://*/*"] })
    .catch(() => []);
  for (const tab of tabs) {
    if (tab.id == null) continue;
    // The script itself refuses to run twice in the same page, so injecting
    // into a tab that already has it is harmless.
    chrome.scripting
      .executeScript({ target: { tabId: tab.id }, files: ["content.js"] })
      .catch(() => {
        // Chrome's own pages, the store, PDFs — nothing to accompany there.
      });
  }
}

chrome.runtime.onStartup.addListener(resumeSession);
chrome.runtime.onInstalled.addListener(async (details = {}) => {
  await migrated;
  // Devices that met the old server may still hold its keys — not anymore —
  // and its alarm, which outlives the code that made it and must be cleared.
  await chrome.storage.local.remove(["syncToken", "userEmail"]);
  await chrome.alarms.clear("sync");
  await injectIntoOpenTabs();
  await resumeSession();

  // The install with no door: a woman adds the extension, the toolbar icon
  // lights up, and nothing tells her what to do next. That silence, not any
  // reported bug, is what this block closes — by opening onboarding
  // ourselves the one time it is actually the first door she is looking
  // for.
  //
  // `details.reason` is the only signal Chrome gives for *why* onInstalled
  // fired, and the three values it can hold point at three different
  // moments:
  //   "install"       — she just added the extension. Nothing has run for
  //                      her yet. This is the one case this block acts on.
  //   "update"        — a new version of the extension replaced the old
  //                      one, on a device that was already running it.
  //   "chrome_update" — the browser itself updated and re-fired the event.
  // Both of the latter reach a woman who is already mid-pilot. Popping a
  // tab open under her on either would read as her setup being thrown
  // away, which is worse than today's silence — so anything that is not
  // "install" returns here, before touching storage or a tab at all.
  if (details.reason !== "install") return;

  // A fresh install is not automatically a new *user* — `chrome.storage.
  // local` survives a reinstall over existing data, and a device that
  // already has a kabbalah is not looking for onboarding, it is looking for
  // what it already had. "Is there anything here yet" already has one
  // answer in this codebase — the popup's own empty-state check
  // (popup.js:703, `if (!state.kabbalot.length)`) — so this reads the same
  // list through the same migration rather than inventing a second notion
  // of "new". `await migrated` above already ran before this line, so a
  // device converting from the old single-kabbalah shape is read here
  // *after* it has walked over, not mid-migration.
  const kabbalot = await getKabbalot();
  if (kabbalot.length) return;

  // chrome.tabs.create can be missing or throw on hosts that grant the
  // extension APIs unevenly (the same reason popup.js's openOnboarding()
  // guards it). A woman's install must never fail because a tab would not
  // open — she still has the icon either way.
  try {
    await chrome.tabs?.create({ url: chrome.runtime.getURL("onboarding.html") });
  } catch {
    // Nothing to do — the extension is installed and working; only the
    // courtesy of opening the door for her failed.
  }
});

// Service worker wake-up (browser start, new day) — let the old shape walk
// over first, then settle yesterday, then light the badge if an
// unacknowledged fall is waiting, then consider the check-in reminder.
// maybeSendCheckinReminder is last so a computer that was off at
// reminderHour catches up the moment Chrome is opened again, rather than
// waiting for the next minute's alarm (issue #21).
//
// ── the ordering, which is now load-bearing and was not ──────────────────
// The previous comment here said the order was "deliberate but not yet
// load-bearing" and left the question open. It is answered, in
// maybeSendCheckinReminder itself: a day with an unanswered fall suppresses
// the check-in notification entirely, because that notification's own
// promise ("לחיצה קטנה — וסיימנו") is undeliverable while the popup is
// showing the morning-after screen instead. See that function for the full
// argument.
//
// That makes the first edge here real: evaluatePastDays is what *creates*
// the fall, and maybeSendCheckinReminder now reads it. Run the reminder
// first and it would send on the very morning it is meant to stay quiet —
// once per fall, on the worst possible day, and only on a wake where the
// worker had been torn down. That is exactly the kind of bug that survives a
// green suite, so the-check-in-reminder-minds-her-hour.mjs now boots the
// whole chain and asserts the silence rather than trusting this ordering.
//
// syncFallBadge's own position is not load-bearing — it reads the same field
// and writes no storage the reminder consults — but it sits before the
// reminder so that on the one wake where both run, the quiet signal is
// already lit before the loud one decides to stay silent.
migrated
  .then(evaluatePastDays)
  .then(resumeSession)
  .then(syncFallBadge)
  .then(syncValveAlarm)
  .then(maybeSendCheckinReminder);

// Code-quality review of f187b20 (issue #86, I4), moved off the top level
// by Blocker 3 of the whole-branch review: the onboarding tab only ever
// holds the optional `history` permission for the handful of awaits
// between chrome.permissions.request and its own chrome.permissions.remove
// (onboarding.js's checkHistoryTogether — request, read, remove, in that
// order, before anything is drawn). If that tab dies before its own
// `finally` runs — closed, crashed, the browser itself killed mid-read —
// nothing is left to hand the permission back, and the extension never
// legitimately holds `history` at rest.
//
// I4's own first cut ran this at the top level, which sounded right —
// "every worker wake is a chance to notice" — but a service worker's top
// level runs on EVERY wake, not just a real browser startup: the 1-minute
// tick alarm and onboarding.js's own saveDraftSoon() autosave (a plain
// storage.local.set) both wake the worker too, and neither of those is
// remotely "the tab died". A wake landing mid-read pulled `history` out
// from under a perfectly live checkHistoryTogether() call, right after she
// pressed Allow — the sweep meant to clean up a dead tab was breaking a
// live one instead.
//
// chrome.runtime.onStartup (a fresh browser launch) and chrome.runtime.
// onInstalled (install/update) are the only two events a tab's in-flight
// JS cannot survive across — closing the browser or reloading the
// extension both end any read that was running — so binding the sweep to
// just those two still catches the dead-tab case it was written for,
// without the false positives top-level ever had. Genuine API failures
// mid-read are unaffected either way: checkHistoryTogether's own
// error/declined split (onboarding.js) already covers those, and always
// did.
async function sweepDanglingHistoryPermission() {
  try {
    // chrome.permissions is missing from the test doubles most of this
    // file's own tests build (the same reason chrome.storage.onChanged is
    // optional-chained a few thousand lines up) — the `?.` is what keeps
    // that missing API from throwing here.
    const held = await chrome.permissions?.contains?.({ permissions: ["history"] });
    if (held) await chrome.permissions.remove({ permissions: ["history"] });
  } catch {
    // Nothing to do — the tab that would have removed it is already gone,
    // and Chrome drops an optional permission on uninstall regardless.
  }
}
chrome.runtime.onStartup.addListener(sweepDanglingHistoryPermission);
chrome.runtime.onInstalled.addListener(sweepDanglingHistoryPermission);

// ── issue #108: the gap that trade still left open ──────────────────────
// The trade above was correct — it removed a far more likely failure — but
// it was still a trade: onStartup and onInstalled are the only two events
// GUARANTEED to catch a dead tab, but on a machine where Chrome runs for
// weeks they can also be the only two events that never fire at all. A tab
// that dies mid-read on such a machine leaves `history` granted until the
// next real browser launch or extension update — and toggling the
// extension off and on triggers neither.
//
// chrome.tabs.onRemoved closes that gap the precise way the issue asks
// for: the tab that owed the permission back is exactly the tab that just
// disappeared, so the sweep below only ever fires on the one event that
// says THIS specific read is never reaching its own `finally`. It
// deliberately does not fire on any tab closing — a woman closing an
// unrelated browsing tab while the onboarding tab is still genuinely
// mid-read must not pull `history` out from under that live read, which is
// exactly the Blocker-3 bug above reappearing in a new shape. So this only
// acts on a tab it was explicitly told, by that tab itself, is the one
// currently holding a read open — never on tab-close in general.
//
// onboarding.js's checkHistoryTogether (the only code that ever asks for
// `history`) sends "history-read-started" right after the grant and
// "history-read-finished" in the same `finally` that already gives the
// permission back. `sender.tab.id` is where the tab's own id comes from —
// Chrome attaches it to every runtime message sent from an extension page
// tab automatically, no manifest permission involved, the same as
// sender.tab.url/sender.tab.id already read a few hundred lines up for
// "kabbalot-status"/"kabbalot-grace".
//
// The set of "currently reading" tab ids lives in chrome.storage.session
// rather than only in memory. A service worker is free to nap and wake
// again mid-read — chrome.history's own batched getVisits calls on a busy
// profile can run well past the idle timeout that would otherwise empty an
// in-memory Set — and storage.session is the one storage area built to
// survive exactly that (a worker restart) while still clearing itself at
// the real browser shutdown chrome.runtime.onStartup already handles. Every
// access below is wrapped rather than chained with `?.` so a test double
// missing chrome.storage.session entirely (most of this file's own tests
// build one) degrades to "nothing remembered this wake" instead of
// throwing — the same reasoning as chrome.permissions's own `?.` above.
const HISTORY_READ_TABS_KEY = "historyReadTabIds";

async function historyReadTabIds() {
  try {
    const got = await chrome.storage.session?.get?.(HISTORY_READ_TABS_KEY);
    return new Set(got?.[HISTORY_READ_TABS_KEY] || []);
  } catch {
    return new Set();
  }
}

async function setHistoryReadTabIds(ids) {
  try {
    await chrome.storage.session?.set?.({ [HISTORY_READ_TABS_KEY]: [...ids] });
  } catch {
    // Best-effort persistence only — the in-memory picture this same call
    // was built from is still correct for whatever acts on it this wake.
  }
}

async function markHistoryReadStarted(tabId) {
  if (tabId == null) return;
  const ids = await historyReadTabIds();
  ids.add(tabId);
  await setHistoryReadTabIds(ids);
}

async function markHistoryReadFinished(tabId) {
  if (tabId == null) return;
  const ids = await historyReadTabIds();
  if (ids.delete(tabId)) await setHistoryReadTabIds(ids);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "history-read-started") {
    markHistoryReadStarted(sender.tab?.id).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg.type === "history-read-finished") {
    markHistoryReadFinished(sender.tab?.id).then(() => sendResponse({ ok: true }));
    return true;
  }
});

// Only sweeps when the tab that just closed was itself a registered reader,
// and even then only once nothing else is: two onboarding tabs mid-read at
// once is not a shape this product's flow produces on purpose, but if it
// ever happened, one of them dying must not pull `history` out from under
// the other still-open one either.
chrome.tabs?.onRemoved?.addListener(async (tabId) => {
  const ids = await historyReadTabIds();
  if (!ids.has(tabId)) return;
  ids.delete(tabId);
  await setHistoryReadTabIds(ids);
  if (ids.size === 0) await sweepDanglingHistoryPermission();
});
