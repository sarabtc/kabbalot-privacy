// בחרתי בי — export.js: "הסיפור שלך במספרים" (DESIGN.md §6.6, copy in §7.1/§7.2).
// A full extension page, not a popup script — the screen is 540px wide and
// the popup shell is 360px (§3.2), so it lives at its own chrome-extension://
// URL and is opened from the popup later (see the one-line hook noted below).
//
// Privacy (Issue #22, PRD §4.4): this screen reads chrome.storage.local and
// writes nothing anywhere but the clipboard, on her own click. No fetch, no
// XHR, no beacon — nothing-leaves-the-device.mjs checks this file for that.
//
// CULTURAL RED LINE (see popup.js, narrowed by Founder Ruling 1,
// 2026-08-26): never on a surface someone else can see without her having
// opened it herself — not "never a site name anywhere", which stopped
// being true the moment nameFrom()'s own fallback started defaulting to
// the site itself. She opens the export screen herself, so it is allowed
// to show `k.name` here, whatever it is (typed nickname or the site's own
// default). What the exported text still never prints is the raw place/
// domain string itself (`k.places`) — that was never what she named the
// kabbalah, only what it resolves to.
//
// ---- three judgment calls DESIGN.md §7 does not settle — flagged, not invented ----
// 1. §7.1's template is written for one kabbalah ("עם יוטיוב", singular story).
//    The data model (docs/data-model.md, decision 3) makes kabbalot a list,
//    and Issue #22 itself asks for streaks "לכל קבלה — רצף נוכחי ושיא" (per
//    kabbalah). With no approved multi-kabbalah export copy to fall back on,
//    this file repeats the exact §7.1 block once per kabbalah, verbatim,
//    joined by a blank line — reusing approved copy rather than writing new
//    copy for the multi-kabbalah case.
// 2. "התחלתי לפני שבועיים" — §7.2's table has no general "how long ago"
//    formatter. sinceStartPhrase() below extends fmt()'s own pattern (special
//    words for 1/2, a generic plural after that) to elapsed days. This one
//    phrase is the closest thing in this file to invented copy; flagged in
//    the build report.
// 3. "מתחת ליעד" only has an approved word for the good case (under goal).
//    todayLine() below uses the natural antonym "מעל" when she is at/over
//    goal, since no alternate copy was approved for that case either.
//
// The header's 3 stat-tiles are singular in §6.6 (one screen, not one per
// kabbalah). With more than one kabbalah they show: the best current streak
// (max), total days kept (sum), and total hours returned this week (sum) —
// also flagged, since §8.4's list of screens redesigned for multi-kabbalah
// does not include the export screen.

// ---- storage: chrome.storage.local inside the extension, an in-memory
// stand-in outside it ----
// This screen was found broken by opening export.html over plain http(s)
// (no extension runtime, so `chrome` is undefined) — the exact way the next
// visual bug will be found too. Mirrors popup.js's hasChrome/memStore split
// (popup.js lines ~41-63) so this screen can be opened the same way. Inside
// the extension hasChrome is true and storeGet() is a straight pass-through
// to chrome.storage.local — nothing below this comment block ever runs.
const hasChrome = typeof chrome !== "undefined" && chrome.storage;

// A distinct localStorage key from popup.js's own "kabbalot:preview" — the
// two previews are seeded independently (see seedPreviewData below), and
// sharing a key would let one screen's fake data silently leak into the
// other's preview session.
const PREVIEW_KEY = "kabbalot:preview-export";

function loadMemStore() {
  try {
    if (typeof localStorage === "undefined") return {};
    return JSON.parse(localStorage.getItem(PREVIEW_KEY) || "{}");
  } catch {
    return {};
  }
}

// Only ever built outside the extension — see hasChrome guard below. Reading
// `localStorage` while chrome.storage exists would be pointless, and in a
// sandboxed test harness there may be no such global to read.
const memStore = hasChrome ? null : loadMemStore();

function persistMemStore() {
  try {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem(PREVIEW_KEY, JSON.stringify(memStore));
  } catch {
    // Private mode or no localStorage — the preview still works in-session.
  }
}

async function storeGet(keys) {
  if (hasChrome) return chrome.storage.local.get(keys);
  if (keys === null || keys === undefined) return { ...memStore };
  const list = Array.isArray(keys) ? keys : [keys];
  const out = {};
  for (const k of list) if (k in memStore) out[k] = memStore[k];
  return out;
}

// ---- day/week math, mirrored from background.js on purpose ----
// This file must agree with the engine on what "today" and "this week" mean,
// or the export would show a different day than the one background.js just
// wrote usage: for. Same local-clock reasoning as background.js: toISOString
// rolls over at UTC midnight, which is the wrong day on her own clock.

// Issue #6's proposal for the hour her day turns over, still awaiting Sara's
// answer. Written out here for the same reason GRACE_POOL_PER_WEEK is: no
// module system. It has to match background.js and shared.js exactly, and a
// test checks that it does.
const DAY_RESET_HOUR = 3;

// Which day a moment belongs to — her day ends at DAY_RESET_HOUR, not at
// midnight, so an evening that runs past twelve is still that evening.
function dateStr(d = new Date()) {
  return calendarDate(dayDate(d));
}

// The calendar date a Date falls on, written out — for the callers that are
// already holding the day they mean and only need it spelled.
function calendarDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// The calendar date her day is filed under, at local midnight. Local
// calendar fields rather than millisecond subtraction, so a clock change
// does not move the day (see background.js).
function dayDate(d = new Date()) {
  const back = d.getHours() < DAY_RESET_HOUR ? 1 : 0;
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() - back);
}

function parseDay(str) {
  const [y, m, d] = String(str).split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

// Same Sunday-keyed week as background.js's weekKey() — the grace pool is
// shared across all kabbalot (docs/data-model.md), so this must land on the
// exact same storage key the engine reads and writes, including the three
// hours after midnight on a Sunday when her week has not turned over yet.
function weekKey() {
  const d = dayDate();
  const sunday = new Date(d.getFullYear(), d.getMonth(), d.getDate() - d.getDay());
  return `grace:${calendarDate(sunday)}`;
}

// ---- preview seeding (design-review only, never runs inside the extension) ----
// Real chrome.storage always has *some* answer, even "no kabbalot yet" — the
// screen's genuine empty state (EMPTY_STATE_TEXT, below) already covers that.
// Outside the extension, a first load has nothing in localStorage at all,
// which without seeding would render that same genuine empty state — making
// "nobody has looked at this yet" indistinguishable from "there is no data
// to preview". Seeded once, only when the preview store is empty, so the
// screen has a real multi-kabbalah summary to look at on first load.
function daysAgoStr(n) {
  // Counted back from the day she is in, then simply spelled — asking
  // dateStr() again would take a midnight and hand back the day before it.
  const d = dayDate();
  return calendarDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() - n));
}

function seedPreviewData() {
  const usage = {};
  for (let i = 0; i < 8; i++) {
    usage[`usage:${daysAgoStr(i)}`] = {
      "preview-place-one.example": (i === 0 ? 55 : 78 + i * 3) * 60,
      "preview-place-two.example": (i === 0 ? 20 : 33 + i * 2) * 60,
    };
  }
  Object.assign(memStore, {
    kabbalot: [
      {
        id: "preview_k1",
        name: "הפינה ההיא",
        rule: { kind: "dailyLimit", limitMinutes: 90 },
        places: ["preview-place-one.example"],
        baselineMinutes: 120,
        streak: 6,
        longestStreak: 9,
        daysKept: 18,
        createdAt: daysAgoStr(21),
      },
      {
        id: "preview_k2",
        name: "האתר השני",
        rule: { kind: "window", from: "20:00", to: "21:00" },
        places: ["preview-place-two.example"],
        baselineMinutes: 45,
        streak: 3,
        longestStreak: 5,
        daysKept: 9,
        createdAt: daysAgoStr(10),
      },
    ],
    events: [
      { type: "fall", occurredAt: "x", kabbalahId: "preview_k1" },
      { type: "fall", occurredAt: "x", kabbalahId: "preview_k1" },
    ],
    [weekKey()]: 1,
    ...usage,
  });
  persistMemStore();
}

if (!hasChrome && !("kabbalot" in memStore)) seedPreviewData();

// The pool size is law, not data (docs/data-model.md) — same constant as
// background.js's GRACE_POOL_PER_WEEK.
const GRACE_POOL_PER_WEEK = 3;

// §7.1's four lines all open with a plain "•" (U+2022) — structure, not
// decoration — they are what makes the block scannable once it is pasted
// into a form or a WhatsApp message. Kept in one place so a future change
// to the marker lands as an edit to this one object, not a hunt through
// the template strings below.
const SECTION_MARKER = {
  standing: "•",
  streak: "•",
  returned: "•",
  grace: "•",
};

// ---- §7.2 computed strings ----

// fmt(m) — duration phrasing. Under an hour: "{m} דקות". Exactly one/two
// hours get the words "שעה"/"שעתיים" instead of "1/2 שעות". A remainder adds
// " ו־{r} דק׳". Matches every example in §7.2's table.
function hoursWord(h) {
  if (h === 1) return "שעה";
  if (h === 2) return "שעתיים";
  return `${h} שעות`;
}
function fmt(m) {
  const minutes = Math.max(0, Math.round(m || 0));
  if (minutes < 60) return `${minutes} דקות`;
  const h = Math.floor(minutes / 60);
  const r = minutes % 60;
  return r === 0 ? hoursWord(h) : `${hoursWord(h)} ו־${r} דק׳`;
}

// clock(m) — "{h}:{mm}", minutes zero-padded. clock(90) === "1:30".
function clock(m) {
  const minutes = Math.max(0, Math.round(m || 0));
  const h = Math.floor(minutes / 60);
  const mm = String(minutes % 60).padStart(2, "0");
  return `${h}:${mm}`;
}

// Judgment call #2 (see file header) — not in §7.2's table.
function sinceStartPhrase(days) {
  if (days <= 0) return "היום";
  if (days === 1) return "אתמול";
  if (days === 2) return "לפני יומיים";
  if (days === 7) return "לפני שבוע";
  if (days === 14) return "לפני שבועיים";
  if (days % 7 === 0) return `לפני ${days / 7} שבועות`;
  return `לפני ${days} ימים`;
}

function daysBetween(fromStr, toStr) {
  if (!fromStr) return 0;
  const ms = parseDay(toStr) - parseDay(fromStr);
  return Math.max(0, Math.round(ms / 86400000));
}

// usage:<date> is keyed by place and stored in seconds (docs/data-model.md).
// A kabbalah sums, at read time, only the places that are its own.
function usageMinutesForDay(store, dateKey, places) {
  const usage = store[`usage:${dateKey}`] || {};
  let seconds = 0;
  for (const place of places || []) seconds += usage[place] || 0;
  return Math.round(seconds / 60);
}

// A window-rule kabbalah has no limitMinutes — its budget is the width of
// its own window. Treating that width as the "goal" is the closest analog
// to a daily-limit goal that the data model offers (judgment call, flagged).
function windowMinutes(rule) {
  const [fh, fm] = String(rule.from || "0:00").split(":").map(Number);
  const [th, tm] = String(rule.to || "0:00").split(":").map(Number);
  return Math.max(0, th * 60 + tm - (fh * 60 + fm));
}
function goalMinutesFor(k) {
  if (!k.rule) return 0;
  return k.rule.kind === "window" ? windowMinutes(k.rule) : k.rule.limitMinutes || 0;
}

// "ימים היו קשים" has no dedicated event type yet (docs/data-model.md lists
// day_success, fall, grace, sprint_success, sprint_broken, station_reached,
// help_click — no separate "checkin marked hard but still kept" type). Until
// the daily check-in card writes one of its own, `fall` (the day the rule
// itself was breached) is the closest existing signal and stands in for it.
function fallsCountFor(k, store) {
  return (store.events || []).filter((e) => e.type === "fall" && e.kabbalahId === k.id).length;
}

// issue #87 — the days she released herself. docs/messages.md group 8
// moment 8, carried inline like every other §7.1 line in this file. This is
// deliberate, not an oversight: export.html loads only export.js — unlike
// popup.html it never pulls in message-bank.generated.js or chat-bridge.js
// — so there is no `MESSAGE_BANK` for this file to read at runtime even if
// it wanted to. The literal below is what ships, and
// extension/tests/a-released-day-is-shown-as-its-own-thing.mjs compares it
// word for word against the live document (via parseValveBank, which *is*
// the bridge — it just runs at test time, not page-load time) so the two
// cannot drift. A draft, like all of group 8 — see that group's intro.
//
// Three forms, not one variable: 1 and 2 are the overwhelmingly common
// early values, and "{{n}} ימים" reads as "1 ימים" / "2 ימים" for both —
// ungrammatical Hebrew (quality review #87, BLOCKER 2, 24.8.2026). The
// sibling line just above this one in kabbalahBlock ("{{ימים}} ימים היו
// קשים") has the identical bug and ships today; it is already-approved
// copy, so it is left alone here and reported to Sara rather than changed
// unilaterally — see the quality-review report for the suggested forms.
const EXPORT_RELEASED_LINE_ONE = "יום אחד שחררתי.";
const EXPORT_RELEASED_LINE_TWO = "יומיים שחררתי.";
const EXPORT_RELEASED_LINE_MANY = "{{ימים_ששוחררו}} ימים שחררתי.";

function releasedLineFor(count) {
  if (count === 1) return EXPORT_RELEASED_LINE_ONE;
  if (count === 2) return EXPORT_RELEASED_LINE_TWO;
  return EXPORT_RELEASED_LINE_MANY.replace("{{ימים_ששוחררו}}", String(count));
}

// Distinct days, not raw events: releaseDay() (popup.js) used to be able to
// write two `released` events for the same product day on a double-click /
// key-repeat race. That race was closed at its source in fa200fe (the
// release button now disables itself synchronously on first press), so
// this Set is defence-in-depth rather than a workaround for a live bug —
// kept because the doc's own framing ("אם שחררה שישה ימים") is days, not
// event rows, and nothing upstream guarantees that will always hold.
function releasedCountFor(k, store) {
  const days = new Set();
  for (const e of store.events || []) {
    if (e.type === "released" && e.kabbalahId === k.id && e.meta?.day) days.add(e.meta.day);
  }
  return days.size;
}

// "זמן שהחזרתי לעצמי" — the days-model has no field that already means
// this, so it is derived the most literal way available: minutes she stayed
// under her own baseline, summed over the last 7 days (today included).
// A kabbalah with no recorded baseline contributes nothing — there is
// nothing to measure the return against.
function weeklyReturnedMinutes(k, store, todayStr) {
  if (k.baselineMinutes == null) return 0;
  // An unknown creation date is "do not credit", not "credit everything"
  // (review, blocker): the old `k.createdAt && day < k.createdAt` guard
  // was falsy — and so entirely skipped — for a kabbalah with no
  // createdAt at all, which gave the ONE case with no age information the
  // full, completely unguarded week. Mirrors dashboard-model.js's own fix.
  if (!k.createdAt) return 0;
  const todayDate = parseDay(todayStr);
  let total = 0;
  // i starts at 1, not 0: "החזרתי" is past tense, and a day that has not
  // ended cannot be counted as returned — a systemic fix, not an
  // install-day-only one (review, blocker). The window is the previous 7
  // COMPLETED days (yesterday back through a week ago), shifted back one
  // day rather than shrunk to six, so "this week" stays the same span
  // dashboard-model.js's own returnedThisWeekMinutes now uses.
  for (let i = 1; i <= 7; i++) {
    const d = new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate() - i);
    // The cursor already holds the day it means, so it is spelled rather
    // than re-derived — dateStr() on a midnight would step back a day.
    const day = calendarDate(d);
    // A day before this kabbalah existed has no usage:<day> key, which
    // reads as zero usage — and zero usage under a baseline earns FULL
    // credit, fabricating "hours returned" for days before she ever had
    // this kabbalah at all.
    if (day < k.createdAt) continue;
    const actual = usageMinutesForDay(store, day, k.places);
    total += Math.max(0, k.baselineMinutes - actual);
  }
  return total;
}

function formatHours(minutes) {
  const value = Math.round((minutes / 60) * 2) / 2;
  return String(value);
}

// Hebrew-aware phrase for the WEEKLY-HOURS SENTENCE only (kabbalahBlock,
// below) — mirrors dashboard-model.js's formatReturnedHours exactly (issue
// #102 review, blocker: "0.5 שעות" / "1 שעות" / "2 שעות" are ungrammatical,
// and those are the most common values in a real first week). formatHours
// above stays a bare number on purpose: computeTiles' tile-returned sits
// next to export.html's own static label "שעות שהחזרת" (a numeric slot, not
// a sentence), where a full phrase would double up against that label
// instead of reading as one. The sentence and the tile diverge here
// deliberately; nothing else about "hours returned" does.
function formatHoursPhrase(minutes) {
  const value = Math.round((minutes / 60) * 2) / 2;
  // Unlike dashboard.js's returnedLine (hidden outright when there is
  // nothing to report), this sentence is unconditional per kabbalah — a
  // baseline-less kabbalah, or a week spent entirely at or over baseline,
  // both reach here at 0. "0 שעות" is not reviewed copy either way; kept
  // as the least surprising continuation of what this line already said.
  if (value < 0.5) return "0 שעות";
  if (value === 0.5) return "חצי שעה";
  if (value === 1) return "שעה";
  if (value === 1.5) return "שעה וחצי";
  if (value === 2) return "שעתיים";
  if (value === 2.5) return "שעתיים וחצי";
  // Three and up: Hebrew has no special word past the dual, but a bare
  // decimal ("3.5 שעות") reads as a foreign register right next to
  // "שעתיים וחצי" the line above (review, minor) — carry the same
  // "וחצי" construction through instead: a whole number is a plain count,
  // a half-hour remainder becomes "{n} וחצי שעות" (n = the whole-hour part).
  if (Number.isInteger(value)) return `${value} שעות`;
  return `${Math.floor(value)} וחצי שעות`;
}

function lastThreeDaysLine(k, store, todayStr) {
  const todayDate = parseDay(todayStr);
  const parts = [3, 2, 1].map((offset) => {
    const d = new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate() - offset);
    return clock(usageMinutesForDay(store, calendarDate(d), k.places));
  });
  return parts.join(" · ");
}

// The exact §7.1 block, word for word, for one kabbalah.
function kabbalahBlock(k, store, todayStr, sharedGraceUsed) {
  const todayMinutes = usageMinutesForDay(store, todayStr, k.places);
  const goalMinutes = goalMinutesFor(k);
  const since = sinceStartPhrase(daysBetween(k.createdAt, todayStr));
  const sinceLine =
    k.baselineMinutes != null
      ? `התחלתי ${since}, עם ${k.name} — בערך ${fmt(k.baselineMinutes)} ביום.`
      : `התחלתי ${since}, עם ${k.name}.`;
  // Judgment call #3 (see file header): only "מתחת" is approved copy.
  const direction = todayMinutes <= goalMinutes ? "מתחת" : "מעל";
  const todayLine = `היום? ${fmt(todayMinutes)}. ${direction} ליעד שקבעתי לעצמי (${clock(goalMinutes)}).`;
  const fallsCount = fallsCountFor(k, store);
  const returnedMinutes = weeklyReturnedMinutes(k, store, todayStr);
  // Rendered only when there is at least one (the variable table's own
  // empty case: "ב-0 לא מרנדרים את השורה בכלל"), so a woman who never
  // released a day sees the approved §7.1 block exactly as approved.
  const releasedCount = releasedCountFor(k, store);
  const releasedLines =
    releasedCount > 0 ? [`${SECTION_MARKER.standing} ${releasedLineFor(releasedCount)}`] : [];

  return [
    "הסיפור של הקבלה שלי",
    "",
    sinceLine,
    todayLine,
    "",
    `${SECTION_MARKER.standing} ${k.daysKept || 0} ימים עמדתי בקבלה. ${fallsCount} ימים היו קשים — וסימנתי אותם, וגם זה משהו.`,
    ...releasedLines,
    `${SECTION_MARKER.streak} הרצף שלי עכשיו: ${k.streak || 0} ימים. השיא: ${k.longestStreak || 0}.`,
    `${SECTION_MARKER.returned} השבוע החזרתי לעצמי ${formatHoursPhrase(returnedMinutes)}. הן שלי.`,
    `${SECTION_MARKER.grace} הארכות: השתמשתי ב־${sharedGraceUsed} מתוך ${GRACE_POOL_PER_WEEK} — בחירה מודעת, לא נפילה.`,
    "",
    `שלושת הימים האחרונים: ${lastThreeDaysLine(k, store, todayStr)} (היעד: ${clock(goalMinutes)})`,
    "הגרף יורד. זו אני.",
  ].join("\n");
}

// Not from §7 (which never describes an empty state) — kept short and
// neutral on purpose, following §7's own rule against shaming language,
// so a woman who has not onboarded yet sees a sentence instead of a blank
// box or NaN. Flagged in the build report as the one line of new copy.
const EMPTY_STATE_TEXT = "עוד אין לך נתונים לייצוא. ברגע שתתחילי קבלה, הסיפור שלך יופיע כאן.";

function buildExportText(store, todayStr) {
  const kabbalot = store.kabbalot || [];
  if (kabbalot.length === 0) return EMPTY_STATE_TEXT;
  const sharedGraceUsed = store[weekKey()] || 0;
  return kabbalot.map((k) => kabbalahBlock(k, store, todayStr, sharedGraceUsed)).join("\n\n");
}

function computeTiles(store, todayStr) {
  const kabbalot = store.kabbalot || [];
  if (kabbalot.length === 0) return { streak: "0", kept: "0", returned: "0" };
  const streak = Math.max(...kabbalot.map((k) => k.streak || 0));
  const kept = kabbalot.reduce((sum, k) => sum + (k.daysKept || 0), 0);
  const returnedMinutes = kabbalot.reduce(
    (sum, k) => sum + weeklyReturnedMinutes(k, store, todayStr),
    0
  );
  return { streak: String(streak), kept: String(kept), returned: formatHours(returnedMinutes) };
}

function computeExportData(store) {
  const today = dateStr();
  return { tiles: computeTiles(store, today), text: buildExportText(store, today) };
}

function renderInto(doc, data) {
  doc.getElementById("tile-streak").textContent = data.tiles.streak;
  doc.getElementById("tile-kept").textContent = data.tiles.kept;
  doc.getElementById("tile-returned").textContent = data.tiles.returned;
  doc.getElementById("export-text").value = data.text;
}

// Not sourced from DESIGN.md §7 or docs/messages.md — neither describes a
// storage-read failure, only the genuine "no kabbalah yet" empty state
// above. Flagged in the build report for Sara to approve or replace. Kept
// to the same house rule §7.1 states outright ("מה אף פעם לא כותבים": no
// "שגיאה", "נכשל", "אזהרה", no shouting) and to the same calm, factual
// register as the rest of this screen: what happened, and that nothing is
// lost. Deliberately distinct from EMPTY_STATE_TEXT — that one is true
// information ("you have nothing yet"); this one is "we don't know what you
// have right now", which must never be allowed to look like the same thing.
const FAILURE_STATE_TEXT =
  "לא הצלחנו כרגע לקרוא את הנתונים שלך. הם לא נעלמו — הכל עדיין שמור אצלך. נסי שוב בעוד רגע.";

function renderFailureState(doc) {
  // "–" on the tiles, never "0" — a zero here reads as "she used the
  // product for zero minutes today", a false claim about her, not as "we
  // couldn't read the number". A blank textarea has the same problem: it
  // reads as the genuine empty state, not as a read failure.
  doc.getElementById("tile-streak").textContent = "–";
  doc.getElementById("tile-kept").textContent = "–";
  doc.getElementById("tile-returned").textContent = "–";
  doc.getElementById("export-text").value = FAILURE_STATE_TEXT;
  // Nothing real to copy while the read has failed.
  doc.getElementById("copy-btn").disabled = true;
}

async function init() {
  let store;
  try {
    store = await storeGet(null);
  } catch {
    renderFailureState(document);
    return;
  }
  const data = computeExportData(store);
  renderInto(document, data);

  const btn = document.getElementById("copy-btn");
  const restLabel = btn.textContent;
  btn.addEventListener("click", async () => {
    await navigator.clipboard.writeText(data.text);
    // §6.6: the label swaps to "הועתק" for 2000ms.
    btn.textContent = "הועתק";
    setTimeout(() => {
      btn.textContent = restLabel;
    }, 2000);
  });
}

// A rejection from anywhere else in init() (a DOM lookup, a render step) is
// a backstop, not the expected path — storeGet's own try/catch above is
// what normally turns a storage failure into the honest message instead of
// an uncaught rejection and a screen frozen at zeros.
init().catch(() => renderFailureState(document));
