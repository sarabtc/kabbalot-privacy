// בחרתי בי — everything the onboarding computes, with no DOM and no chrome
// in sight, so that all of it can be run and checked by a plain node script.
// The renderer (onboarding.js) is a thin layer over this file.
//
// Every user-facing string is DESIGN.md §7 / §7.2, or Sara's own words in
// issue #82, and every string that is neither is marked UNAPPROVED where it
// is defined. Loaded as a plain script by onboarding.html, so its top-level
// declarations are deliberately globals.
//
// ---------------------------------------------------------------------------
// Issue #82 — the reframe. Sara installed the extension, walked the three
// screens as a tester, and said the experience was bad enough to rebuild.
// The structural half is three screens instead of five cards; the half that
// actually matters is the question they ask.
//
// The old screen 2 asked "כמה מותר לך" — a quota, which sounds like a fence.
// This build asks two questions instead, and derives the fence from them:
//
//   screen 1 · כמה זמן את שם ביום        →  what she spends there now
//   screen 2 · כמה את רוצה להחזיר לעצמך  →  what she wants back
//   the engine                            →  limit = spend − give-back
//
// In her own words: "יוטיוב אני 5 שעות ומייל אני רק שעה… כמה זמן אני רוצה
// להחזיר לעצמי מכל אתר… יכול להיות ביחד הכל אני מחזירה לעצמי 4 שעות, שעה
// מפה וחצי שעה משם." The same arithmetic as before and the opposite feeling,
// and it is the product's own positive-accounting principle applied to the
// setup screen: not what she gave up, but what she got back.
//
// One kabbalah — one streak, one commitment — but each place inside it
// carries its own two numbers, and they sum to the kabbalah's total. See
// placeGoalsFrom() below and docs/data-model.md, which is the authority.
// ---------------------------------------------------------------------------

// Sara's ruling on issue #44's emoji half: the illustrated character carries
// the warmth, not a glyph beside her words — no emoji reaches any screen in
// this product. shared.js keeps MENTOR_EMOJI as an empty constant for that
// reason; nothing in this file interpolates it into a string.

// ---------- §7.2 · the computed strings ----------

// "45 דקות" · "שעה" · "שעתיים" · "שעה ו־30 דק׳" · "3 שעות ו־15 דק׳"
function fmt(m) {
  const h = Math.floor(m / 60);
  const r = m % 60;
  if (h === 0) return `${r} דקות`;
  const hours = h === 1 ? "שעה" : h === 2 ? "שעתיים" : `${h} שעות`;
  return r === 0 ? hours : `${hours} ו־${r} דק׳`;
}

// "1:30" · "0:35". Always rendered inside dir="ltr" (DESIGN.md §5).
function clock(m) {
  return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`;
}

// ---------- §3.5 · the time controls ----------
// Fifteen minutes to dialMax, in steps of five. The ring is a full circle,
// twelve o'clock is the floor, and the value grows clockwise.
//
// The dial is still the control for "how long am I there" when there is
// exactly one place — it is the screen's signature and it is what a woman
// who names one site sees. It is not what she sees when she names four:
// Sara's own constraint on this screen is "לרוב הם יבחרו אתר אחד, אני רק
// רוצה שתהיה את האופציה", so the screen has to look simple for one place and
// only unfold for someone who needs more. Five dials stacked down a 400px
// column is the opposite of that. From two places up, each place gets one
// compact horizontal bar instead, sharing this file's arithmetic exactly —
// same floor, same step, same ceiling, same words underneath. See
// minutesFromFrac/fracOf, which both controls read.

const DIAL_MIN = 15;
const DIAL_STEP = 5;
const DIAL_MAX_DEFAULT = 180;
const DIAL_CEILING = 1440;
const DIAL_EXTEND_BY = 180;

// The generic form both controls use: where a value sits inside its own
// range (0…1), and which whole step a fraction of that range lands on.
// `max === min` cannot actually arise on either control today (a spend bar's
// max is DIAL_MAX_DEFAULT or wider, a target bar's max is spendOfRow, which
// is never below DIAL_MIN) — kept as a guard anyway, since a shared helper
// with no DOM in sight is exactly the wrong place to assume a caller's own
// bounds can never collapse, and it must not divide by zero if one someday
// does.
function fracOf(minutes, min, max) {
  return max === min ? 0 : (minutes - min) / (max - min);
}

function minutesFromFrac(frac, min, max) {
  const clamped = Math.min(Math.max(frac, 0), 1);
  return min + Math.round((clamped * (max - min)) / DIAL_STEP) * DIAL_STEP;
}

function dialFrac(minutes, dialMax) {
  return fracOf(minutes, DIAL_MIN, dialMax);
}

function dialAngle(minutes, dialMax) {
  return Math.round(360 * dialFrac(minutes, dialMax));
}

// ---------- C1 (2026-08-21, Sara's report) · the ring's own paint ----------
// Her words: "שהגלגל לא יתגלגל. אין סוף — שזה יגיע ל-3 שעות זה יגמור סיבוב
// ולא יוכל להמשיך." She sent a screenshot at 2:50 of 3:00, the ring nearly
// sealed, the handle almost back at twelve o'clock.
//
// dialAngle above is not wrong and is not touched: dialFrac(180,180)===1
// and dialAngle(180,180)===360 are both pinned exactly by
// the-onboarding-does-its-arithmetic.mjs, and "100% of the range she is
// currently offered" is the correct answer to what dialAngle is actually
// asked. The bug is in *using* that number, unmodified, as the ring's own
// fill: a fully closed loop reads as "finished, nothing more to give" to
// someone looking at it, and canExtendDial's own affordance (one tap away,
// the whole range doubling) is invisible from a closed circle. Sara's own
// sentence names the read directly — "אין סוף", there is no end, when what
// is actually true is the opposite: there is more, always, up to a full
// day.
//
// ringAngle is what the ring's own conic-gradient is painted with instead
// of the raw dialAngle, everywhere the ring is drawn (dialMarkup's first
// paint and wireDial's live one, onboarding.js) — the handle position, the
// clock reading and the aria value all keep reading the real, untouched
// number; only the coloured arc itself is held a few degrees short of a
// true close while she is still approaching a ceiling she has not reached
// yet — a held-open door for the whole time she is anywhere near the top
// of it, not a hint that only flickers on right at the end, which a woman
// turning the dial quickly could easily miss.
//
// ---------- Fix (2026-08-25, Sara's second report) ----------
// "אפשר לסובב את הגלגל אין סוף אני רוצה שאחרי שהוא גומר סיבוב הוא ניתקע
// ושהוא כולו יהיה מלא בסוף הסיבוב, פה הוא בסוף הסיבוב אבל לא מלא."
// Screenshot this time is at exactly 3:00 of 3:00 — not 2:50 of 3:00 the
// way the first report's was — spend genuinely equal to dialMax, and the
// ring still short by RING_GAP_DEG. The C1 comment above still holds for
// every point *short of* a ceiling she has actually reached: a ring that
// looks finished while she is still approaching the top hides the extend
// affordance right when it matters most. But once she is actually there —
// rawAngle === 360, the whole of what is on offer right now spent — a gap
// stops being a held-open door and starts being exactly what she reported:
// a wheel that will not admit it ever finishes turning. Sealed shut was
// previously reserved for DIAL_CEILING alone (a full day, past which
// canExtendDial() refuses to offer more); it now also covers this
// point — the current ceiling, the instant she genuinely reaches it. The
// extend button (canExtendDial, `#extend`) is untouched and still does the
// actual job of surfacing "there is more" — it is explicit text
// ("יותר מ־3:00? להרחיב עד 6:00"), not a subtracted dozen degrees most
// people, evidently including the one testing this, never read as
// discoverable in the first place.
const RING_GAP_DEG = 12;
function ringAngle(rawAngle, dialMax) {
  return rawAngle < 360 && dialMax < DIAL_CEILING ? Math.min(rawAngle, 360 - RING_GAP_DEG) : rawAngle;
}

// The 30×30 handle, in the container's own pixels: centre (115,115),
// radius 100, minus half the handle. φ starts at twelve o'clock.
function dialHandle(minutes, dialMax) {
  const phi = ((-90 + 360 * dialFrac(minutes, dialMax)) * Math.PI) / 180;
  return {
    x: Math.round(115 + 100 * Math.cos(phi)) - 15,
    y: Math.round(115 + 100 * Math.sin(phi)) - 15,
  };
}

function dialFromFrac(frac, dialMax) {
  return minutesFromFrac(frac, DIAL_MIN, dialMax);
}

// A pointer dragged across twelve o'clock has not spun a lap; she has pulled
// past an end. Snap to the end she was heading for.
//
// ---------- Fix (2026-08-25, Sara's report) ----------
// "אפשר לסובב את הגלגל אין סוף" — she found this by hand, dragging: past
// either end the dial does not stop, it wraps around and keeps going,
// forever. Re-reading her first report (2026-08-21, the ring-gap fix
// above) with this in hand, it was very likely the same bug, misdiagnosed
// as a purely visual one at the time — "שזה יגיע ל-3 שעות זה יגמור סיבוב
// ולא יוכל להמשיך" ("that when it reaches 3 hours it finishes a rotation
// and cannot continue") reads, in light of this second report, as the same
// wish stated the same way: stop there, do not keep going.
//
// The bug is exactly backwards from what "the end she was heading for"
// (the line above, unchanged since it was always the right description)
// requires. Floor and ceiling sit at the same physical point — twelve
// o'clock — so continuing to drag clockwise past the ceiling, or
// counter-clockwise past the floor, makes the raw fraction jump across the
// 0/1 seam discontinuously even though the actual motion was a few degrees,
// not a lap. `prevFrac` is where the value already was; a big *drop*
// (prevFrac far above frac) with `prevFrac` itself already high means she
// was already at or near the ceiling and kept turning the same way — the
// end she was heading for is the ceiling (1), not the floor. Symmetrically,
// a big *rise* with `prevFrac` already low means she was already at or near
// the floor and kept turning the same way — the end she was heading for is
// the floor (0), not the ceiling. A previous pass at this function (see git
// history) had this reasoning right in its own prose and then wired the two
// branches to the opposite conclusion; this reverses that.
//
// Mutation-verified: swapping the two return values back to the previous
// (wrong) mapping is caught by the-onboarding-does-its-arithmetic.mjs's own
// dialSeam checks and by she-can-drag-it-without-clicking.mjs's DOM-level
// drag-past-the-end checks, both updated alongside this fix.
//
// ---------- Fix (2026-08-26, Sara's live-Chrome report) ----------
// "מסתובב לנצח ולא מתמלא בסוף" — the dial spins forever and never fills at
// the end, on the real, installed extension, tapping to set it directly.
// The comment above has always said the right thing — a clamp only belongs
// to a *seam crossing*, which requires `prevFrac` itself to already be near
// the end she was pushing past — but the code below it never actually
// tested that half, only the size of the jump (`|delta| > 0.5`). Any big
// jump clamped, regardless of where it started from, which is exactly wrong
// for the one gesture that is *all* jump and no drag: a tap. Landing on
// pointerdown with no real "previous" position at all (see fromPointer,
// onboarding.js) meant a tap far from the current value looked, to the old
// code, indistinguishable from a drag that had spun past an end — and
// worse, it was clamped to the FAR end, not the near one: from the default
// (frac 0.636 of dialMax=180), a tap at 10° (frac 0.028, well under the
// 0.25 gate below) read as a "big drop" and clamped to 1 (three hours) —
// the opposite of what a 10° tap should ever produce.
//
// The gate: a big drop only clamps to the ceiling when `prevFrac` was
// *itself* already high (near the ceiling she was pushing past); a big rise
// only clamps to the floor when `prevFrac` was itself already low. Anywhere
// else, a big jump is exactly that — an ordinary large move, real once
// fromPointer (onboarding.js) stops manufacturing false previous positions
// for a fresh press (see that fix, alongside this one) — and is left alone.
//
// Mutation-verified: removing either gate (leaving only the delta test) is
// caught by the two new "does NOT start near ..." checks in
// the-onboarding-does-its-arithmetic.mjs; the two pinned seam-crossing
// checks just above still catch the mapping itself being swapped.
function dialSeam(prevFrac, frac) {
  if (prevFrac > 0.75 && prevFrac - frac > 0.5) return 1;
  if (prevFrac < 0.25 && frac - prevFrac > 0.5) return 0;
  return frac;
}

function canExtendDial(minutes, dialMax) {
  return minutes >= dialMax - 10 && dialMax < DIAL_CEILING;
}

function nextDialMax(dialMax) {
  return Math.min(DIAL_CEILING, dialMax + DIAL_EXTEND_BY);
}

// "יותר מ־3:00? להרחיב עד 6:00"
function extendLabel(dialMax) {
  return `יותר מ־${clock(dialMax)}? להרחיב עד ${clock(nextDialMax(dialMax))}`;
}

// ---------- issue #86 · the history estimate, landing on the dial ----------
// "לא בטוחה? אפשר לבדוק את זה יחד." (Sara's words) reads the last month of
// her history once, in memory, and offers a number. history-estimate.js
// computes the raw minutes; these two helpers are what make an accepted
// number indistinguishable from one she dialled herself: on the 5-minute
// grid, inside the floor and the ceiling, and with the dial widened by the
// same steps her own "להרחיב עד" click takes.
function spendFromEstimate(minutes) {
  if (!Number.isFinite(minutes)) return null;
  const snapped = Math.round(minutes / DIAL_STEP) * DIAL_STEP;
  return Math.min(Math.max(snapped, DIAL_MIN), DIAL_CEILING);
}

function dialMaxFor(minutes, dialMax) {
  let max = dialMax;
  while (minutes > max && max < DIAL_CEILING) max = nextDialMax(max);
  return max;
}

// The offer's own words. One place gets the issue's sentence whole; several
// places get a lead, one row each (the renderer puts the place beside the
// row inside dir="ltr", DESIGN.md §5), and the same trailer. "הערכה, לא
// מדידה" is the promise the issue insists on: history records arrivals,
// not stays, and the screen must not dress a guess as a fact.
// Item 5 (whole-branch review of #86): HISTORY_OFFER_LEAD (the
// multi-place opener, punctuated as a colon) and historyOfferLine (the
// single-place sentence, punctuated as a comma) used to spell "לפי
// ההיסטוריה של החודש האחרון" out twice, independently — editing one and
// forgetting the other would desync the two without either being wrong on
// its own, and no test could catch that. HISTORY_OFFER_STEM is the one
// place that phrase is written; both compose from it.
const HISTORY_OFFER_STEM = "לפי ההיסטוריה של החודש האחרון";
const HISTORY_OFFER_LEAD = `${HISTORY_OFFER_STEM}:`;
const HISTORY_OFFER_TRAILER = "זו הערכה, לא מדידה.";

function historyOfferLine(minutes) {
  return `${HISTORY_OFFER_STEM}, בערך ${fmt(minutes)} ביום. ${HISTORY_OFFER_TRAILER}`;
}

function historyOfferRow(minutes) {
  return `בערך ${fmt(minutes)} ביום`;
}

// ---------- §6.1 screen 1 · the places, and what they resolve to ----------

// Two rules, not three. "סרטונים עד 5 דקות" was deferred by issue #31 and is
// not built here: a place is an address or a corner of one (see placeFor in
// background.js), and how long a video runs is nowhere in its address.
const YT_CHIPS = ["הכל", "רק Shorts"];

// יוטיוב keeps its scope choice; every other site is just a link (issue #82,
// screen 1). The four quick-pick chips of the old build are gone: they were
// the first of the four faults Sara found sitting in front of the real
// product — "צ׳יפים שלא דורשים קישור" — a click that looked like it had
// named a place while naming nothing at all. Now a row *is* a link, and the
// scope chips appear on a row only once the link she pasted turns out to be
// a youtube address. הכל keeps the whole of it; רק Shorts keeps the corner
// that never ends — the place issue #31 already taught the engine to measure
// on its own.
const YT_PLACES = { "הכל": "youtube.com", "רק Shorts": "youtube.com/shorts" };

function isYouTubePlace(place) {
  return place === "youtube.com" || place.startsWith("youtube.com/");
}

// Fix 2 (2026-08-21, Sara: "אני רוצה שיהיה אפשר לחסום את הצאט שבתוך המייל
// בניפרד מהמייל" — "I want it to be possible to block the chat inside the
// mail separately from the mail"). The engine already tells inbox and chat
// apart — placeFor() in background.js matches the longest place, so
// ["mail.google.com", "mail.google.com/chat"] already measures each on its
// own. What was missing was ever offering her the choice: naming the chat
// alone, with no way to also name the inbox, left the inbox completely
// unmeasured (the same longest-match rule that lets a corner stand apart
// also means naming only the corner drops everything else on the site).
// This is the same shape as the YouTube scope chip, one row up — a row's
// own corner choice, not a second card, and the same CULTURAL RED LINE
// reason it is allowed to name a site at all: this is setup, before a
// nickname exists to speak with instead (popup.js's header).
//
// UNAPPROVED: "רק הצ׳אט" is not in DESIGN.md §7 or docs/messages.md — there
// is no existing line for a Gmail-chat scope choice, only for YouTube's.
// "הכל" reuses the literal DESIGN.md §5 already approves for the YouTube
// chip's own "everything" option (the row for `--pink-ink`/`--pink-soft`:
// `כלל היוטיוב ("הכל" / "רק Shorts" / ...)`) — the same generic word, not a
// new phrase. Only "רק הצ׳אט" is new, and it is listed in the report.
const MAIL_CHIPS = ["הכל", "רק הצ׳אט"];

// הכל keeps today's behaviour exactly (a bare Gmail link already measured
// the whole host) — the chip is additive, not a change in default, so a
// draft already in progress with a Gmail link mid-typing sees nothing move
// under her. רק הצ׳אט is the corner issue #31's own logic already knows how
// to isolate; naming it is the whole of Fix 2.
const MAIL_PLACES = { "הכל": "mail.google.com", "רק הצ׳אט": "mail.google.com/chat" };

function isMailPlace(place) {
  return place === "mail.google.com" || place.startsWith("mail.google.com/");
}

// Sara: "עד חמישה אתרים — שניים עדיף, כי יותר מחמישה זו קבלה ענקית."
const PLACE_MAX = 5;

const SPEND_DEFAULT = 120;
const GIVE_BACK_DEFAULT = 15;

// One row of screen 1. `link` is the raw text she typed, never pre-parsed,
// so a half-typed address is not thrown away between keystrokes; `spend` is
// how long she says she is there today; `giveBack` is screen 2's answer for
// this same row. `ytRule` only ever matters if the link turns out to be a
// youtube one; `mailRule` (Fix 2) only ever matters if it turns out to be a
// Gmail one. Defaults to "הכל" — a bare Gmail link measured the whole host
// before this chip existed, and the chip is additive, not a change to what
// she already had.
function emptyPlaceRow() {
  return {
    link: "",
    ytRule: "רק Shorts",
    mailRule: "הכל",
    spend: SPEND_DEFAULT,
    giveBack: GIVE_BACK_DEFAULT,
  };
}

// The place one row resolves to, or null when the box holds nothing a
// browser could visit yet (empty, abandoned, garbage text). A youtube
// address collapses to the corner the row's own scope chip names, so her
// literal path is not what is kept — the corner she chose is.
//
// Issue #85: every other row used to keep the pasted path verbatim, on the
// theory that "only what she actually named is measured" (placeFor's own
// comment in background.js) meant her literal address was the name. But
// onboarding.js's own header explains why this screen is a tab and not a
// popup: "a tab does not die when she leaves to fetch her link" — she is
// meant to go stand on the very page eating her time and paste that address
// back. That page is essentially never the bare homepage; it is whatever
// article, feed state or watch page happened to be open. Keeping that exact
// path scoped the whole kabbalah to one URL she never chose to narrow —
// nothing on this screen offers her that choice, the way the youtube chips
// do — and every other page on the same site then matched no place at all:
// blocking worked once, on that one address, and the floating timer sat
// frozen everywhere else. Only the host survives here now; the site is what
// she named, whatever corner of it she happened to be standing on.
function placeOfRow(row) {
  const parsed = parseLink(row?.link);
  if (!parsed) return null;
  const candidate = `${parsed.host}${parsed.path}`;
  if (isYouTubePlace(candidate)) {
    return YT_PLACES[row.ytRule] || YT_PLACES["הכל"];
  }
  // Fix 2: same shape as YouTube, one line up. Whichever Gmail page she
  // happened to paste — inbox, chat, anything else under mail.google.com —
  // collapses to the corner her own chip names, not her literal path.
  if (isMailPlace(candidate)) {
    return MAIL_PLACES[row.mailRule] || MAIL_PLACES["הכל"];
  }
  return parsed.host;
}

// Every place she actually named, in the order she named them, each once.
// Two rows that resolve to the same place (a watch page and a shorts page
// under "הכל", say) are one place; the first of them wins, in both this list
// and placeGoalsFrom below, so the numbers she set on the row that counts
// are the numbers that are kept.
function placesFrom(a) {
  const out = [];
  for (const row of a.places || []) {
    const place = placeOfRow(row);
    if (place && !out.includes(place)) out.push(place);
  }
  return out;
}

// ---------- the reframe's arithmetic (issue #82) ----------
// The whole of it: she says what she spends, she says what she wants back,
// and the limit is the subtraction. Nothing here asks her for a quota.

// The bug (Sara, walking her own onboarding, 2026-08-21): "זה קורה רק אם
// נתת 15 דקות בקודם, והוא נותן להמשיך." A woman who says she spends fifteen
// minutes somewhere — the dial's own floor, DIAL_MIN — was told, on the one
// screen whose entire job is to show her what she gets back, that she gets
// back nothing, because giveBackMax used to be `spend - DIAL_MIN`: the same
// fifteen doing two unrelated jobs at once. DIAL_MIN is a sensible floor for
// "how long are you there today" (screen 1) — it is not a sensible floor for
// "how much can this shrink to" (screen 2), and there was never a reason the
// two questions should share one number.
//
// LIMIT_FLOOR_MINUTES is that second, separate floor: the smallest a place's
// *target* may land on without simply giving the place up. Five minutes, not
// fifteen — a woman at the fifteen-minute baseline can still give back ten
// of it and land somewhere real, instead of being told there is nothing to
// have.
const LIMIT_FLOOR_MINUTES = 5;

// B_ZERO (2026-08-21, Sara's decision): "not at all" is now a real answer.
// Giving up a place entirely — a target of zero — is exactly the kind of
// kabbalah this audience takes, and until this change the product could not
// represent it: the floor below applied to *every* target, zero included,
// so she could never actually reach it. Now there are exactly two kinds of
// valid target — zero, or anywhere from LIMIT_FLOOR_MINUTES up to what she
// spends — and the one stretch that stays off the table is the sliver in
// between (one to four minutes): not a first success (PRD §3.1) and not
// "not at all" either, just a trap with a different number on it. Nothing on
// this screen's own controls can land there (the target grid starts at zero
// and steps by DIAL_STEP, so it only ever touches zero or a multiple of
// five) — this is the backstop for anything that reaches the model some
// other way: an old draft, a hand-edited record.
function limitFromRawTarget(spend, rawTarget) {
  const clamped = Math.min(Math.max(rawTarget, 0), spend);
  return clamped === 0 || clamped >= LIMIT_FLOOR_MINUTES ? clamped : LIMIT_FLOOR_MINUTES;
}

// The target bar's own floor at the *control* layer — zero, not
// LIMIT_FLOOR_MINUTES — because zero is a value she has to be able to drag
// to, not a value the control refuses. limitFromRawTarget is what actually
// keeps the one-to-four sliver unreachable (both from a drag that lands
// there and from anything else that hands the model a raw number); the bar
// itself only needs its true endpoint.
const TARGET_MIN = 0;

// The most she can hand back from a place: all of it. "Not at all" (target
// zero) means giving back everything it costs her, so the ceiling on
// give-back is simply what she spends — the floor that used to sit here
// (DIAL_MIN) moved to limitFromRawTarget above, where it belongs, and it no
// longer applies to zero.
function giveBackMax(spend) {
  return Math.max(0, spend);
}

function spendOfRow(row) {
  return Math.min(Math.max(row?.spend ?? SPEND_DEFAULT, DIAL_MIN), DIAL_CEILING);
}

// limitOfRow is computed first now (via limitFromRawTarget's snap) and
// giveBackOfRow is the number left over — the reverse order from before this
// fix, when giveBackOfRow was primary and limitOfRow was simply what
// remained. Reversing it is what keeps a give-back set out of range (a
// draft's stale value, a corrupted record) from ever landing a target in the
// forbidden one-to-four sliver: the snap has to happen on the target side,
// because that is the number with a real floor.
function limitOfRow(row) {
  const spend = spendOfRow(row);
  const rawGiveBack = Math.min(Math.max(row?.giveBack ?? 0, 0), giveBackMax(spend));
  return limitFromRawTarget(spend, spend - rawGiveBack);
}

function giveBackOfRow(row) {
  return spendOfRow(row) - limitOfRow(row);
}

// ---------- B2 (2026-08-21, Sara's decision) · the screen asks a target ---
// Her words: "לגבי כמה זמן את רוצה להחזיר לעצמך זה מבלבל אנשים מאוד... אני
// רוצה שנעשה כמה ביום את הולכת להיות שם, כי כבר הבנו." The give-back
// question made her do the subtraction in her head — she already told the
// engine what she spends, on screen 1; screen 2's slider now asks for the
// number she can actually picture, how long she is choosing to be there,
// and the engine does the subtraction it was always doing anyway.
//
// The record's own shape is untouched: `placeGoals` still stores
// `giveBackMinutes` (docs/data-model.md), and everything that already reads
// it — background.js, the popup, the export — keeps reading exactly what it
// always did. Only the screen's own question inverted, so the two
// directions of the same subtraction live here, side by side, rather than
// being scattered across call sites: targetOfRow is what the slider shows
// and drags, and it is nothing new — it is limitOfRow, spoken in the
// screen's own words, because "how long are you going to be there" and
// "what you're left with" were always the same number. giveBackFromTarget
// is what a drag on that slider writes back through — the exact mirror of
// limitFromRawTarget's own snap, routed the other way, so a target dragged
// to zero really does hand back everything, and a target dragged into the
// one-to-four sliver is pulled up to the floor exactly as limitOfRow would
// pull it, not left sitting somewhere the two functions could disagree
// about.
function targetOfRow(row) {
  return limitOfRow(row);
}

function giveBackFromTarget(spend, target) {
  return spend - limitFromRawTarget(spend, target);
}

// { "youtube.com/shorts": { baselineMinutes, giveBackMinutes, limitMinutes } }
//
// One entry per place, and the three fields are the same three words the
// kabbalah record already uses at its own level — the record's top-level
// baselineMinutes and rule.limitMinutes are simply the sums of these. See
// docs/data-model.md.
function placeGoalsFrom(a) {
  const goals = {};
  for (const row of a.places || []) {
    const place = placeOfRow(row);
    if (!place || place in goals) continue;
    goals[place] = {
      baselineMinutes: spendOfRow(row),
      giveBackMinutes: giveBackOfRow(row),
      limitMinutes: limitOfRow(row),
    };
  }
  return goals;
}

function sumGoals(a, field) {
  return Object.values(placeGoalsFrom(a)).reduce((sum, g) => sum + g[field], 0);
}

function totalSpend(a) {
  return sumGoals(a, "baselineMinutes");
}
function totalGiveBack(a) {
  return sumGoals(a, "giveBackMinutes");
}
function totalLimit(a) {
  return sumGoals(a, "limitMinutes");
}

// B5 (2026-08-21, Sara's decision): "להתחיל קטן יותר" (§7, approved) and
// its own button (onboarding.js, screen 3) are removed — PLAN_STEP and
// easedPlaces() lived here to back that button, and it was their only
// caller. Sara first read the button as a duplicate of #finish; it
// technically was not (this function took one step off every place's
// give-back before finishing, so it asked strictly less of her) — but a
// woman can reach that exact same outcome herself by moving screen 2's own
// sliders down a little, and nothing on the screen ever explained that the
// two buttons differed. That is a duplicate in the sense that matters, so
// the button is gone rather than relabelled, and this function goes with
// it: kept dead code around for a caller that no longer exists is a worse
// trap than deleting it, since B2 (the same day) inverted what screen 2's
// slider even stores — this function's own arithmetic (`giveBack -
// PLAN_STEP`) would have needed inverting right along with it, and there is
// no reason to invert something nothing calls. If a "start smaller" idea
// returns, it belongs on a screen that actually explains what it does
// differently from the primary button beside it.

// §7.2: "אתר שהמשתמשת הדביקה מופיע ברשימה בשם הקישור שלך". The cultural red
// line (Sara's ruling, #15) is that nothing past setup ever shows a site or
// brand name again — so the recap sentence names *that she pasted links*,
// never which. One place or five, it is the one phrase; the count is not the
// point, and printing it would only invite the next question.
function siteList(a) {
  return placesFrom(a).length ? ["הקישור שלך"] : [];
}

// {{שם}} is trimmed to 24 characters (docs/messages.md, variables table).
const NAME_MAX = 24;

// A "place" string is `host` or `host/path` — placeOfRow's own shape,
// above, the exact same one placeFor/domainOf (background.js) parse when
// they match a tab's url against it. A bare host is already what a woman
// would recognise as-is ("youtube.com"); a host with a corner gets that
// corner named alongside it, in parentheses, so "youtube.com/shorts" reads
// as "youtube.com (shorts)" rather than as a path written nowhere else in
// this product. Kept this mechanical on purpose — reaching for the scope
// chip's own Hebrew label ("רק Shorts") here would read one way from
// onboarding (which has it) and a different way from background.js's own
// migration fallback and dashboard.js's own display fallback (which do
// not, and only ever see the resolved place string) — see nameFrom's own
// comment for where this same shape is duplicated, briefly, for that
// reason.
// ---------- Fix (Founder Ruling 2, 2026-08-26) ----------
// "https://עיתון.co.il" — a Hebrew domain — normalises, inside `new URL()`
// (parseLink, shared.js), to its punycode A-label: the host that actually
// reaches this function is "xn--9dbhtj5b.co.il", ASCII gibberish with no
// resemblance to what she typed. That string used to become the kabbalah's
// own name — this path returned "המקום שלי" before nameFrom's own fallback
// changed to prefer the place (2026-08-25), so the punycode leak is newly
// reachable, in a Hebrew-first product. It is treated the same as an
// unnameable place, below, and falls through to the placeholder — not
// decoded back to Hebrew: she chose the placeholder because it is always
// readable, punycode is lossy enough (case, IDNA variants) that a decoded
// guess could show her something she never typed, and she can always type
// a real name herself.
//
// ---------- Fix (Minor 10) ----------
// An empty host — `place` starting with "/", like "/shorts" — used to fall
// straight through to `${host} (${corner})`, producing " (shorts)": still
// truthy, so every caller's own `generated || "המקום שלי"` guard never
// caught it. Unreachable via placeOfRow today (issue #85 narrowed a place
// to its bare host), but this function runs on stored strings that are
// never re-validated after that — a migrated or hand-edited record could
// still carry one. An empty or punycode host now makes this function
// return "", so the SAME guard that already exists at every call site
// (nameFrom, legacyKabbalahName, kabbalahLabel) catches it correctly,
// rather than adding a second, easy-to-forget guard at each of them.
function placeDisplayName(place) {
  const slash = place.indexOf("/");
  const host = slash === -1 ? place : place.slice(0, slash);
  if (!host || /(^|\.)xn--/i.test(host)) return "";
  if (slash === -1) return host;
  const corner = place.slice(slash + 1);
  return corner ? `${host} (${corner})` : host;
}

// ---------- Fix (2026-08-25, Sara's report) ----------
// "מתי החלטתי או כתבתי שהשם של הקבלה שלי זה המקום שלי, אני רוצה ששם הקבלה
// יהיה לפי שם האתר." She never chose the generic placeholder — it was
// simply what was left once Fix 5 (2026-08-21, see git history) removed
// the nickname field from the plain onboarding path, and nobody replaced
// it with a real default at the same time.
//
// The record's name is still never built out of anything but what she
// typed, first — that part is unchanged. What changes is the fallback for
// "she typed nothing": instead of one generic placeholder every time, it
// is now the place she actually named, in the same recognisable form
// placeFor/domainOf already match it by (placeDisplayName, above). Two or
// more places (she named two sites): the FIRST one she named — the same
// "first of them wins" rule placesFrom (below) already keeps for its own
// list, so this reuses an ordering guarantee that already existed rather
// than inventing a new one. "המקום שלי" is kept as the last-resort
// fallback only, for the one case a place genuinely cannot be named from —
// every row left blank or unparseable, `placesFrom(a)` empty.
//
// This narrows, but does not remove, the naming-collision risk
// extension/tests/no-two-kabbalot-wear-the-same-name.mjs guards against:
// two kabbalot for two DIFFERENT places now get two different default
// names for free (they did not before — see the diff on
// a-second-kabbalah-needs-its-own-name.mjs, updated alongside this fix,
// for the same two example places that used to collide and no longer do).
// Two kabbalot that both center on the SAME place still collide on this
// default exactly as before, which is exactly why the nickname field's own
// gating (onboarding.js's STEPS[1], `?new=1` / `?edit=<id>`) is untouched
// here — auto-naming makes the common case better, it does not make the
// field unnecessary.
function nameFrom(a) {
  const typed = (a.customName || "").trim();
  if (typed) return typed.slice(0, NAME_MAX);
  const places = placesFrom(a);
  const generated = places.length ? placeDisplayName(places[0]) : "";
  return (generated || "המקום שלי").slice(0, NAME_MAX);
}

// ---------- Fix (Important 3, 2026-08-26) ----------
// The single place that names a STORED kabbalah with no typed name of its
// own — nameFrom's own logic, above, but starting from a record's resolved
// `places` (plain strings) rather than an onboarding row's `.link`, which
// is the shape dashboard.js's kabbalahLabel() and answersFromKabbalah()
// (below) both actually have on hand. Reused by both rather than each
// re-deriving it, so there is one naming rule at this layer, not two —
// answersFromKabbalah() used to call nameFrom({ customName: k.name }),
// never passing k.places, which meant an EMPTY k.name (a stored kabbalah
// with no name at all) prefilled the edit screen with "המקום שלי" even
// though dashboard.js, looking at the very same record, already showed her
// the real place. Saving without touching the field then persisted the
// wrong one.
function nameForStoredKabbalah(k) {
  const typed = ((k && k.name) || "").trim();
  if (typed) return typed.slice(0, NAME_MAX);
  const first = ((k && k.places) || []).find((p) => typeof p === "string" && p);
  const generated = first ? placeDisplayName(first) : "";
  return (generated || "המקום שלי").slice(0, NAME_MAX);
}

// ---------- Fix (Important 4, 2026-08-26) ----------
// "Load {name:'youtube.com'}, change the place to instagram.com, rebuild —
// still youtube.com." nameFrom() only ever sees one call's own inputs, so
// it has no way to tell a name she typed from one generated for her the
// last time this record was built — both just look like "the current
// k.name" from here. `nameIsGenerated` (buildKabbalah, below) is the flag
// that answers the question nameFrom cannot: true means "she typed nothing
// last time, this is the place's own name," and a name in that state is
// meant to track the place, not survive past it — a typed name is not.
//
// A record from before this flag existed has none at all (`undefined`, not
// `false`). Read conservatively: a woman's own words are never silently
// swapped out for a guess, so a non-empty pre-flag name is treated as
// typed. The one exception is a genuinely empty pre-flag name — there is
// nothing typed there to protect, so it is always generated, which is
// exactly Important 3's own bug case above and is fixed by the same read.
function isGeneratedKabbalahName(k) {
  if (typeof k.nameIsGenerated === "boolean") return k.nameIsGenerated;
  return !((k.name || "").trim());
}

// ---------- her own name (issue #82) ----------
// Sara: "אני גם רוצה שהוא ישאל לשם שלי." Her hand-drawn plan opens screen 1
// with a `שם:` field before anything else, so this is *her* name — the
// kabbalah still gets its own nickname, further down the same screen, where
// it has always been.
//
// It is stored (`userName`, see docs/data-model.md) and it is available to
// every screen the character speaks on. Nothing greets her by it yet: that
// would be new Hebrew, and no line in DESIGN.md §7 or docs/messages.md has a
// slot for it. The report lists, line by line, which copy would have to
// change for the character to actually say it.
function herNameFrom(a) {
  return (a.herName || "").trim().slice(0, NAME_MAX);
}

// "זה בערך 12 שעות בשבוע — בואי נחזיר לך חלק מהן"  (six days, no Shabbat)
// DESIGN.md §7.2's approved literal ends " 💜"; Sara's ruling (no emoji
// anywhere in user-facing copy — the character carries the warmth, not a
// glyph) means that trailing glyph is dropped here. See report.
//
// It now reads the *sum* of what she spends across every place she named,
// which is exactly what the sentence always meant — there was simply only
// ever one place for it to sum.
const DAYS_MEASURED_PER_WEEK = 6;

function weeklyLine(spendMinutes) {
  return `זה בערך ${Math.round((spendMinutes * DAYS_MEASURED_PER_WEEK) / 60)} שעות בשבוע — בואי נחזיר לך חלק מהן`;
}

// The weekly form of what she is handing back, to one decimal — the same
// shape docs/messages.md's own {{שעות}} variable is specified in ("ספרה אחת
// אחרי הנקודה, למשל 3.5"), so the number she sees here and the number the
// popup shows her in a week are written the same way.
function weeklyGiveBackHours(giveBackMinutes) {
  const hours = (giveBackMinutes * DAYS_MEASURED_PER_WEEK) / 60;
  return Math.round(hours * 10) / 10;
}

// "השורה התחתונה: בקצב הזה חוזרות אלייך 45 דקות ביום"
//
// §7's approved template, and in this build it is finally a plain statement
// rather than a projection: the number is what she herself just asked to
// have back, from day one. "בקצב הזה" is Sara's approved wording
// (2026-08-16) and stays — the daily figure is hers immediately, and the
// engine's own weekly descent (#30) can still lower the target further from
// there, which is exactly the pace the phrase is naming.
function totalSaveLine(a) {
  return `השורה התחתונה: בקצב הזה חוזרות אלייך ${fmt(totalGiveBack(a))} ביום`;
}

// §8 decision 2: the extension rules the browser, not the machine. There is
// exactly one scope, and this is its wording. #37 deleted the other
// concept — a kabbalah-scoped quiet window — entirely; nothing here ever
// built it.
const QUIET_SCOPE = "browser";
const QUIET_SCOPE_LABEL = "כל הדפדפן";

// The one sentence on the summary and the done screen. §7.2 gives both the
// template and the worked example; the scope in it is always "כל הדפדפן"
// (§8 decision 2). "מתחילות מ־{fmt} ביום" now names the derived limit — the
// sum of what every place is left with — which is the same number the old
// build put there by a different road.
function summaryLine(a) {
  const list = siteList(a);
  const head = list.length ? list.join(" · ") : "האתרים שבחרת";
  const partial = (a.places || []).some(
    (row) => isYouTubePlace(placeOfRow(row) || "") && row.ytRule && row.ytRule !== "הכל"
  );
  const rule = partial ? ` (רק Shorts)` : "";
  const start = fmt(totalLimit(a));
  // C2 (2026-08-21, Sara's report): this used to hardcode ":00" the same
  // way quietWindowFrom used to — a half-hour window she actually set would
  // have shown up here as the wrong whole hour, on the one sentence that
  // recaps the whole kabbalah back to her. quietHourLabel (below) is the
  // one place both this and quietWindowFrom read the number from now.
  const quiet = a.quietOn
    ? `, ושעות שקטות ${quietHourLabel(a.qFrom)}–${quietHourLabel(a.qTo)} (${QUIET_SCOPE_LABEL})`
    : "";
  // C2-follow-up (2026-08-23): the reminder hour reads through
  // quietHourLabel now too, for exactly the reason C2 gave for the quiet
  // window beside it — a quarter past eight, hardcoded to ":00", would have
  // recapped her whole kabbalah back to her with the wrong hour in it.
  return `${head}${rule} — מתחילות מ־${start} ביום, תזכורת ב־${quietHourLabel(a.hour)}${quiet}.`;
}

// ---------- the record she leaves with (docs/data-model.md) ----------

// §6.1 · מצב מלווה / מצב מחויבות. The engine has enforced the difference
// since #13. Anything else means she was never asked, and the gentler one is
// what an unasked woman gets — the same rule the migration follows.
const MODES = ["companion", "commitment"];

function buildKabbalah(a, { id, today }) {
  const goals = placeGoalsFrom(a);
  const places = Object.keys(goals);
  const limit = Object.values(goals).reduce((s, g) => s + g.limitMinutes, 0);
  const baseline = Object.values(goals).reduce((s, g) => s + g.baselineMinutes, 0);
  return {
    id,
    name: nameFrom(a),
    // Important 4: whether this name is hers, typed, or the place's own
    // default — see isGeneratedKabbalahName's own comment above for why
    // this cannot be recovered later from `name` alone.
    nameIsGenerated: !(a.customName || "").trim(),
    // The kabbalah's own total is the sum of its places' — never a second,
    // independently-stored number that could drift from them. Everything
    // that already reads rule.limitMinutes (the floating timer, the stop
    // page's "time you got back", the export) keeps reading exactly what it
    // always did.
    rule: { kind: "dailyLimit", limitMinutes: limit },
    places,
    // Issue #82's addition, and the reason this build exists: each place
    // carries its own two numbers and the limit derived from them. See
    // docs/data-model.md, and FALL_ON in background.js for what exceeding
    // one of them means.
    placeGoals: goals,
    baselineMinutes: baseline || null,
    mode: MODES.includes(a.mode) ? a.mode : "companion",
    streak: 0,
    longestStreak: 0,
    daysKept: 0,
    stationsReached: 0,
    pendingStation: null,
    fellOn: null,
    fallAcked: true,
    createdAt: today,
  };
}

// ---------- editing an existing kabbalah, by id (#20) ----------
// The reverse of buildKabbalah(): a stored record back into an `answers`
// shape the three screens already know how to draw. Used only by
// onboarding.js's `?edit=<id>` path — the dashboard's "עריכת אתרים" link —
// never by the default (kabbalot[0]) or `?new=1` paths, which both start
// from freshAnswers() as they always have.
//
// A place with a path (`site.example/corner`, issue #82's own example) can
// never come back through placeOfRow() as anything but its bare host — see
// issue #85's comment on placeOfRow above: "only the host survives here
// now". Reconstructing a link for such a place and letting her re-save it
// would silently narrow her kabbalah, dropping the corner she named down to
// the whole site, the moment she opens an edit screen she never asked to
// change anything on. canEditPlacesViaOnboarding() is the guard: a kabbalah
// with any such place is not editable through this screen at all, and
// dashboard.js checks it before it ever opens the tab.
function placeHasPath(place) {
  return !isYouTubePlace(place) && String(place).includes("/");
}
function canEditPlacesViaOnboarding(k) {
  return !(k.places || []).some(placeHasPath);
}

function ytRuleForPlace(place) {
  for (const [rule, mapped] of Object.entries(YT_PLACES)) {
    if (mapped === place) return rule;
  }
  return "רק Shorts";
}

// `opts.userName`/`opts.reminderHour` come from storage keys that sit beside
// the kabbalah, not inside it (`userName`, `reminderHour` — docs/data-model.md)
// — the record itself has no memory of either, so the caller hands them in.
function answersFromKabbalah(k, opts = {}) {
  const goals = k.placeGoals || {};
  const rows = Object.keys(goals).map((place) => ({
    link: `https://${place}`,
    ytRule: ytRuleForPlace(place),
    spend: goals[place].baselineMinutes,
    giveBack: goals[place].giveBackMinutes,
  }));
  const maxSpend = rows.reduce((m, r) => Math.max(m, r.spend), DIAL_MAX_DEFAULT);
  return {
    herName: (opts.userName || "").trim().slice(0, NAME_MAX),
    places: rows.length ? rows : [emptyPlaceRow()],
    note: "",
    // Important 3 / Important 4: a typed name is prefilled verbatim so
    // leaving the field alone keeps it exactly as it was, whatever else she
    // changes. A GENERATED name is prefilled blank — the same state a
    // brand-new kabbalah's field starts in — so leaving it alone runs
    // nameFrom()'s ordinary "she typed nothing" branch against whatever the
    // places are AT SAVE TIME (buildKabbalah, below), refreshing a stale
    // default instead of freezing it. See isGeneratedKabbalahName's own
    // comment for how a pre-flag record is read.
    customName: isGeneratedKabbalahName(k) ? "" : (k.name || "").trim().slice(0, NAME_MAX),
    dialMax: Math.min(maxSpend, DIAL_CEILING),
    quietOn: false,
    qFrom: 16,
    qTo: 17,
    // Screen 3 still shows her the current choice — it is simply never the
    // thing this path writes back. See saveKabbalah() in onboarding.js.
    mode: MODES.includes(k.mode) ? k.mode : "companion",
    hour: Number.isFinite(opts.reminderHour) ? opts.reminderHour : 20,
  };
}

// C2 (2026-08-21, Sara's report): "אני רוצה שיהיה אפשר גם לבחור שעות לא
// עגולות" — non-round hours. The engine never needed anything: activeWindow
// and parseClock (background.js) already read "HH:MM" and compare it in
// plain minutes, half-hours and the overnight branch alike — confirmed with
// new coverage in quiet-hours.mjs rather than assumed, per the report. The
// whole-hours limit was the picker's own, on both onboarding.js's controls
// (the steppers, the drag bar) and here, where quietWindowFrom used to
// format every reading as "H:00" regardless of what it was actually given.
//
// qFrom/qTo keep meaning "hours" — 16 is still four in the afternoon, not a
// count of half-hour ticks — with QUIET_STEP (onboarding.js) letting them
// land on the half as well: 16, 16.5, 17, ... A whole number formats exactly
// as it always did ("16:00"), so every existing default, draft and test
// that only ever set whole hours is untouched; quietHourLabel is the one
// place both this function and onboarding.js's own display text (the
// steppers, the drag handles' aria-valuetext) read it from, so the two can
// never format the same number two different ways.
function quietHourLabel(h) {
  const whole = Math.floor(h);
  const minutes = Math.round((h - whole) * 60);
  return `${String(whole).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

// Quiet hours are the browser's, every day, in the shape background.js's
// activeWindow() reads.
function quietWindowFrom(a) {
  if (!a.quietOn) return null;
  return {
    days: [0, 1, 2, 3, 4, 5, 6],
    from: quietHourLabel(a.qFrom),
    to: quietHourLabel(a.qTo),
    scope: QUIET_SCOPE,
  };
}

// ---------- the draft (kept from the v3 build, guards and all) ----------

// Nothing is pre-chosen for her except the one empty row there has to be
// somewhere to paste into. The youtube sub-rule on that row has a default
// because that card is single-choice and has no designed empty state, and
// "רק Shorts" is the gentler of the two — and it is invisible until the link
// she pastes is actually a youtube one.
const DEFAULT_ANSWERS = {
  herName: "",
  places: [emptyPlaceRow()],
  note: "",
  customName: "",
  dialMax: DIAL_MAX_DEFAULT,
  quietOn: false,
  qFrom: 16,
  qTo: 17,
  mode: "companion",
  hour: 20,
};

// A fresh copy every time. `{ ...DEFAULT_ANSWERS }` is a shallow copy: it
// hands out the *same* places array to every run, and one keystroke in one
// onboarding would then be sitting in the defaults of the next. Two files
// reach for the defaults (this one and onboarding.js), so the deep copy
// lives here, once, rather than being remembered twice.
function freshAnswers() {
  return { ...DEFAULT_ANSWERS, places: [emptyPlaceRow()] };
}

const DRAFT_TTL_MS = 86400000;
const LAST_STEP = 4;

// A draft this screen can actually read. The v3 build wrote `sites`,
// `dialMin` and a single `customPlace`; there is no honest way to turn one
// dial reading into per-place spend and give-back numbers she never gave, so
// a draft of that shape is sent back to the beginning rather than guessed
// at — the same thing v3 itself did with v2's drafts.
function isV4Draft(a) {
  return (
    Boolean(a) &&
    Array.isArray(a.places) &&
    a.places.every((row) => row && typeof row === "object" && "link" in row)
  );
}

// True for exactly the draft resumeTarget() below refuses for being from a
// different evening — not "no draft at all", not "an old build's shape".
// Split out from resumeTarget so the caller can tell *why* it got null: a
// stale draft is text she is never coming back for and should be deleted,
// where the other reasons for null are not (issue #39).
function draftIsStale(draft, now = Date.now()) {
  return Boolean(draft) && now - (draft.savedAt || 0) > DRAFT_TTL_MS;
}

// Where reopening should land her: null to start from nothing at all, or the
// step and answers to restore.
function resumeTarget(draft, now = Date.now()) {
  if (!draft || !draft.answers) return null;
  if (draftIsStale(draft, now)) return null;
  if (!isV4Draft(draft.answers)) {
    // A restart is a restart — the old build's residue is not carried over.
    return { step: 0, answers: freshAnswers() };
  }
  const step = Number.isInteger(draft.step)
    ? Math.min(Math.max(draft.step, 0), LAST_STEP)
    : 0;
  return { step, answers: draft.answers };
}

// ---------- §7 · every string on these screens, in one place ----------
// Approved copy. Changing a word here is a design change (§7) — with one
// standing exception: Sara's ruling on issue #44 is that no emoji reaches
// any screen in this product ("I only want my character, not a leaf
// emoji"). Several of §7's approved literals end in 💜 or ✨; those glyphs
// are dropped here, and every place that happened is called out where the
// string is defined below.
//
// Two of the strings below are Sara's own, written in her hand on the plan
// for issue #82 and used verbatim: the titles of screens 2 and 3.
//
// Everything this rebuild needed and could not source is in the UNAPPROVED
// block at the bottom, one comment per string, and every one of them is
// listed in the report.

const COPY = {
  // step 0
  h1: "בואי נגדיר יחד קבלה אחת — קטנה, שתחזיק.",
  lead: "שלוש שאלות, פחות משלוש דקות. הכל נשאר אצלך במחשב.",
  start: "מתחילות ←",

  // screen 1 · the honest picture
  step1Title: "איפה הזמן בורח לך?",
  spendTitle: "כמה זמן את שם ביום?",
  ytTitle: "מה בדיוק ביוטיוב?",
  noteTitle: "ספרי במילים שלך — זה נשאר רק אצלך",
  linkPlaceholder: "הדביקי קישור… https://",
  // Fix 5 (2026-08-21, Sara's decision) removed the nickname field this
  // placeholder belonged to — see onboarding.js, screen 1, for the comment
  // at that exact spot. Not deleted: it is DESIGN.md §7's approved literal
  // for naming a place, and whoever builds the second-kabbalah flow
  // (claude/issue-20-dashboard, where naming now belongs) may want it
  // verbatim rather than writing a new one.
  namePlaceholder: "איך נקרא לו בינינו? למשל: הפינה ההיא",
  removePlace: "− סגירת אתר אחר",
  next: "ממשיכות ←",

  // screen 2 · בואי נחשוב על פתרון
  quietToggle: "שעות שקטות קבועות ביום",
  quietNote: "למשל: בארבע אחר הצהריים, כשהילדים בבית — הדפדפן שקט.",

  // screen 3 · את מסוגלת
  modeQuestion: "ואם יום אחד יהיה קשה במיוחד?",
  modeCompanion: "מצב מלווה",
  modeCompanionNote: "עוד 5 דקות, עד 3 פעמים בשבוע",
  modeCommitment: "מצב מחויבות",
  modeCommitmentNote: "בלי הארכות — סופי עד מחר",
  modeNote:
    "ⓘ ההבדל: במלווה אפשר לבקש עוד 5 דקות (עד 3 בשבוע). במחויבות — מה שקבעת סופי עד מחר. אפשר לשנות בהגדרות, בתוקף ממחר.",
  reminder: "תזכורת יומית ב־",
  // DESIGN.md §7's approved literal is "מתאים לי, יוצאות לדרך ✨" — the
  // trailing ✨ dropped, Sara's ruling.
  finish: "מתאים לי, יוצאות לדרך",
  // B5 (2026-08-21, Sara's decision): the second button this literal
  // belonged to ("להתחיל קטן יותר") is removed — see the long comment where
  // easedPlaces() used to be, further up this file, for why. DESIGN.md §7's
  // own approved literal, so not deleted outright: kept here as a plain
  // comment in case a future screen wants it back, worded and placed so it
  // is unmistakably not live COPY any more.
  // easier: "להתחיל קטן יותר",

  // done
  // DESIGN.md §7's approved literal is "הקבלה שלך מוכנה ✨" — the trailing
  // ✨ dropped, Sara's ruling.
  doneTitle: "הקבלה שלך מוכנה",

  // ---- Sara's own words, issue #82, used verbatim ----------------------
  // The two screen titles are written in her hand on the plan for this
  // issue. They are not in DESIGN.md §7 because §7 predates the plan; they
  // are not unapproved either, because she is the approval.
  step2Title: "בואי נחשוב על פתרון",
  step3Title: "את מסוגלת",
  // Her plan opens screen 1 with this field, before anything else.
  herNameLabel: "שם:",

  // ---- UNAPPROVED · not in DESIGN.md §7, not in docs/messages.md, and
  // ---- not in Sara's plan. Every one of these is listed in the report and
  // ---- is waiting on her. None carries an emoji.
  //
  // Carried over from the v3 build, already marked there:
  quietFrom: "מ־",
  quietTo: "עד",
  // B6 (2026-08-21): "restart" — "wipe everything and start the onboarding
  // over" — was the done screen's only control, which is the wrong thing to
  // offer the moment she has just committed to something. Kept here as a
  // plain, clearly-dead comment rather than deleted (§7's approved literal,
  // in case a real "start over" affordance is designed properly later,
  // somewhere it cannot be mistaken for the primary action).
  // restart: "← חזרה לתחילת האונבורדינג",
  // Not a new phrase: "הלוח שלך" is Sara's own shipped label for the same
  // destination, from claude/issue-20-dashboard's popup link (commit
  // 2f40444) — reused rather than invented. The arrow matches this screen's
  // own convention (מתחילות ←, ממשיכות ←).
  toDashboard: "אל הלוח שלך ←",
  notePlaceholder: "למשל: אני נשאבת לשם בערבים, ואחר כך מרגישה שהזמן ברח לי",
  // Carried over from claude/places-by-link, already marked there: the
  // repeat control that adds another link row. §7 has nothing for it — the
  // whole idea of several places in one kabbalah is newer than §7.
  addPlace: "+ עוד מקום",
  //
  // New in this build:
  //
  // screen 2's question. B2 (2026-08-21) replaced the give-back framing
  // ("כמה זמן את רוצה להחזיר לעצמך?", issue #82's own turning of her
  // sentence) with this one, in her own words, relayed near-verbatim: "אני
  // רוצה שנעשה כמה ביום את הולכת להיות שם, כי כבר הבנו" — she already told
  // the engine what she spends, on the screen before this one, so this
  // screen now asks for the number she can actually picture (how long she
  // is choosing to be there) rather than a delta she'd have to subtract in
  // her head. Not marked UNAPPROVED the way the sentence it replaces was:
  // it is close enough to her own words, on the same footing as
  // step2Title/step3Title above.
  targetTitle: "כמה ביום את הולכת להיות שם?",
  // Screen 2's own running weekly total, shown while she was still setting
  // give-back amounts there. B4 (2026-08-21) moved that whole display to
  // screen 3 as a redesigned daily+weekly summary (onboarding.js, STEPS[3])
  // built from plain numbers rather than this sentence, so nothing calls
  // this any more. Kept, not deleted: it is still a valid give-back
  // sentence and the shape §7.2's own "מוצג גם כסכום שבועי" note asks for,
  // in case a future screen wants it. The issue asks for the per-place
  // give-back to be "מוצג גם כסכום שבועי"; there is no approved line for a
  // *future* weekly total (§7's "השבוע החזרת לעצמך 3.5 שעות. הן שלך" is the
  // popup's, and it is past tense — using it here would be telling her she
  // has already done it).
  giveBackWeekly: (hours) => `בשבוע: ${hours} שעות שחוזרות אלייך`,
  // screen 3's way back into what she just set. §7 has no generic edit
  // affordance for any screen.
  change: "לשנות",
  // screen 3's encouraging line, before the last button. Sara's plan calls
  // for "משפט עידוד" and does not write one.
  encourage: "הקבלה הזאת נבנתה ממה שאמרת על עצמך. את יכולה לעמוד בה.",
  // Fix 2 (2026-08-21): the mail scope chip's own row title, same job as
  // ytTitle two lines up but ytTitle itself is DESIGN.md §7's approved
  // literal ("מה בדיוק ביוטיוב?") — there is no equivalent line for mail
  // anywhere in §7 or docs/messages.md, so this is built from the same
  // template with the site named instead, not copied from an approved
  // source. Marked here and listed in the report.
  mailTitle: "מה בדיוק במייל?",

  // B_ZERO (2026-08-21, Sara's decision) · what happens when the plan gives
  // back nothing. Splitting the two floors (see limitFromRawTarget above)
  // does not by itself stop a woman from setting every place's target equal
  // to what she spends — a plan that gives back zero minutes on purpose, not
  // by the old bug's accident. The house rule is that an unavailable action
  // disappears rather than being disabled (popup.js's showResetConfirm), and
  // the primary button here is exactly that kind of action: finishing an
  // onboarding built entirely around "what you get back" onto a screen that
  // would have to show the bottom line as zero minutes is the same failure
  // this whole change exists to fix, just reached by her own sliders instead
  // of the old floor. So #finish does not render at all while
  // totalGiveBack(answers) === 0 (onboarding.js, STEPS[3]) — this text takes
  // its place, and "לשנות" (already on this screen, one card up) is the way
  // back into what she set, screen 2's sliders included (it opens screen 1;
  // "ממשיכות" carries her on from there, same as any other walk through the
  // three screens). No line in DESIGN.md §7 or docs/messages.md covers a
  // hidden primary button; marked UNAPPROVED and listed in the report.
  noGiveBackNote:
    "כרגע הקבלה הזאת לא מחזירה לך אף דקה. אפשר לחזור ולהזיז את המחוונים, כדי שיהיה לך זמן שחוזר אלייך.",

  // ---- issue #86 · "לא בטוחה? אפשר לבדוק את זה יחד." -------------------
  // The first line is Sara's, from the issue, verbatim — same footing as
  // step2Title/step3Title. The rest is new: no line in DESIGN.md §7 or
  // docs/messages.md covers a permission prompt she opens herself, so they
  // are UNAPPROVED and listed in docs/superpowers/plans/2026-08-23-history-
  // estimate-button.md for her. No em-dash in any of them.
  historyCheck: "לא בטוחה? אפשר לבדוק את זה יחד.",
  historyWorking: "בודקות…",
  // Shown for a real decline (Chrome's own prompt, answered no), and for a
  // transient read failure after the grant (onboarding.js's "error" kind —
  // background.js's boot-time sweep can revoke the permission mid-read;
  // that path keeps a retry link beside this same line, a real decline does
  // not — see historyBlock's own comment, onboarding.js). Either way
  // nothing was measured, and her own estimate is enough (DESIGN.md §7's
  // "הערכה שלך מספיקה").
  historyDeclined: "בסדר גמור. ההערכה שלך מספיקה.",
  // UNAPPROVED, whole-branch review of #86 (Blocker 2): the sentence this
  // replaces ("לא נמצאו ביקורים שם בחודש האחרון") was false in two of its
  // three uses — the passive "לא נמצאו" ("none were found") also broke the
  // first-person voice "בודקות" just established two lines up, and "שם"
  // ("there") is ambiguous the moment she has named more than one place.
  // Dropped "שם" outright rather than branching the sentence on place
  // count: the offer already sits directly under the places she named, so
  // the sentence does not need to repeat where. UNAPPROVED — Sara approves
  // every word of this and historyTooFewDays below, the same as every other
  // new line this feature introduced.
  historyNothing: "לא מצאנו ביקורים בחודש האחרון. ההערכה שלך מספיקה.",
  // UNAPPROVED, whole-branch review of #86 (Blocker 2, then a follow-up
  // review of THIS line): the other two of historyNothing's old three uses
  // — a place with visits on 1–4 distinct days, or an average that rounds
  // down to 0 minutes — are not "we found nothing", they are "we found
  // something too thin to call an estimate". Telling her "no visits" when
  // there were visits is the one thing this whole feature promises never
  // to do ("estimate, not a measurement" cuts both ways).
  // checkHistoryTogether (onboarding.js) picks this over historyNothing
  // only when at least one named place had a matching visit in the window
  // that still did not clear HISTORY_MIN_DAYS (history-estimate.js) or
  // round to a nonzero average.
  //
  // The first draft said "…לא מספיק ימים כדי להעריך" ("…not enough DAYS to
  // estimate"), which is false in the second of those two cases: six
  // distinct days of visits, each one ~10 seconds long, clears the 5-day
  // floor easily and still rounds to 0 minutes — the problem there was
  // never the day count, it was that the stays themselves were too short
  // to add up to a minute. Dropped "ימים" so the sentence is true for
  // both. Also brought in line with historyDeclined and historyNothing,
  // the other two notes in this same slot: both end with "ההערכה שלך
  // מספיקה." and this one, being the one case where she gets a
  // disappointing partial answer rather than a clean yes/no, should not be
  // the only one of the three that leaves her without that line.
  historyTooFewDays: "יש ביקורים, אבל לא מספיק כדי להעריך. ההערכה שלך מספיקה.",
  // UNAPPROVED, follow-up review of #86: the per-place fragment used
  // inside a multi-place offer card (historyBlock, onboarding.js) for a
  // named place that had real visits but — same reasoning as
  // historyTooFewDays just above — not enough of them to estimate. Reads
  // as "<place>: <this>", the same shape historyOfferRow's fragment
  // already uses for a place that DID qualify, so a place that did not is
  // named rather than silently missing from a card where she can see she
  // named more places than it shows numbers for. Deliberately just the
  // fragment — no place-name repetition, no "ההערכה שלך מספיקה." tacked on
  // per row; the reassurance a lone historyTooFewDays note gives belongs
  // to the offer as a whole; a card that already has at least one real
  // number in it does not need it repeated under every place that didn't.
  historyPlaceTooThin: "לא מספיק כדי להעריך",
  historyAccept: "כן, ניקח את המספר הזה",
  historyIgnore: "לא, אשאיר את שלי",
};

// ---------- §4 · one bubble per moment ----------
// DESIGN.md §4's approved literals for step 0 and the default (done) case
// end in 💜 and ✨ respectively; both dropped below, Sara's ruling.
//
// The three step-2 bubbles were keyed on the dial's one reading. They are
// keyed on the sum of what she says she spends now, which is the same number
// the same woman would have dialled — and they are on screen 1 now, because
// that is where the question moved. Screen 2's own bubble is the one written
// for step 1's empty state, which is the only approved line in §4 that reads
// as an invitation rather than a reaction; screen 2 is where she is being
// invited to choose.
function bubbleFor(step, a = {}) {
  switch (step) {
    case 0:
      return "שלום! אני איתך בזה";
    case 1: {
      const spend = totalSpend(a);
      if (!spend) return "סמני כל מה שמרגיש לך";
      return spend <= 60
        ? "וואו, זה כבר מצוין!"
        : spend <= 120
          ? "הערכה כנה — התחלה חכמה"
          : "אמיצה שאת כנה. נצליח יחד";
    }
    case 2:
      // ---------- Fix (2026-08-26, Sara's live-Chrome report) ----------
      // §4's approved line for a partial youtube rule used to sit here —
      // "not all of it, only what escapes" was, in principle, exactly the
      // choice screen 2 asks her to make about every place she named. Her
      // own reaction, testing the real extension: "נשמע מכני ולא אנושי" —
      // it reads like the system explaining its own filtering rule, not a
      // person reacting to what she just did. The em-dash is also the
      // house ban (docs/messages.md §7 usage rules).
      //
      // Rewritten as one warm sentence a friend would say when a woman has
      // just named one corner of a site rather than the whole thing — the
      // idiom "לשים את האצבע על משהו" (to put a finger right on something)
      // reacts to her own precision, not to the mechanics of scoping.
      // Two alternatives were reviewed alongside this pick (see the
      // report): "יפה שאת יודעת בדיוק איפה זה קורה" (leans evaluative,
      // closer to a teacher praising a right answer than a friend
      // reacting) and "ידעת בדיוק לאתר את זה" ("לאתר" reads as a formal,
      // technical verb, less warm-friend than the idiom above). Reviewed
      // with avshalom-hebrew-expert, hebrew-writing-skill and
      // make-human-lite; UNAPPROVED — not in DESIGN.md §7 or
      // docs/messages.md.
      return "וואו, שמת את האצבע בדיוק על זה";
    case 3:
      return a.mode === "commitment" ? "החלטה חזקה. אני כאן" : "נלך צעד־צעד, ביחד";
    default:
      return "יוצאות לדרך!";
  }
}

// ---------- §4 · one pose per moment (§11 item 2 settles 1 and 2) ----------
// present (בואי אראה לך) · think (בואי נחשוב יחד — screen 1, where the time
// escapes) · point (הצעד הבא שלך — screen 2 is the solution) · offer (אני
// כאן, זה בידיים שלך — screen 3 is the decision) · cheer (עשית את זה).
const POSE_BY_STEP = ["present", "think", "point", "offer", "cheer"];

// §7.2 · "{n} מתוך 3". The progress row is shown on steps 1–3 only (§6.1).
function stepLabel(step) {
  return `${Math.min(Math.max(step, 0), 3)} מתוך 3`;
}
function showsProgress(step) {
  return step >= 1 && step <= 3;
}
