// בחרתי בי — the history estimate (issue #86). Everything the "לא בטוחה?
// אפשר לבדוק את זה יחד." button computes, with no browser API and no DOM in
// sight, so that all of it runs under a plain node script.
//
// What this is, in Sara's own framing from the issue: an ESTIMATE, not a
// measurement. Browser history records when she arrived somewhere, never
// how long she stayed. So a stay on one of her places is taken to be the
// gap from that arrival to the next arrival anywhere (any site, hers or
// not), capped at HISTORY_GAP_CAP_MINUTES because a tab left open while she
// was away from the machine is not time spent there. The very last arrival
// in the whole list has nothing after it, so it is credited a fixed
// HISTORY_TAIL_MINUTES rather than being dropped or inflated. Per place,
// the stays are summed per calendar day and averaged over the days that had
// any arrival at all — a day she never went there is not a zero that drags
// the average down, it is a day the question does not apply to.
//
// The glue in onboarding.js is the only code that ever holds a real history
// item. It hands this file plain {url, visitTime} objects, reads back a
// number per place, and forgets the list. Nothing here is stored anywhere.
//
// Loaded as a plain script by onboarding.html, between onboarding-model.js
// and onboarding.js — shared.js loads before both, so its dateStr() global
// (the product's day, which turns at 03:00, not at midnight) is already
// defined by the time localDayKey() below runs. localDayKey() prefers that
// real dateStr() when it exists and falls back to a local copy of the same
// rule otherwise, so this module still gives a correct, self-consistent
// answer when loaded and tested entirely on its own (as its own test does).
//
// HISTORY_WINDOW_DAYS is the span this module is willing to reason about,
// but the constant alone enforces nothing — see estimateWindowStart() and
// estimateDailyMinutes()'s `since` option below for how a caller actually
// makes that span real.

const HISTORY_WINDOW_DAYS = 30;
const HISTORY_GAP_CAP_MINUTES = 30;
const HISTORY_TAIL_MINUTES = 5;
// The history API's own search default is 100 items, which is a morning,
// not a month. Bounded rather than unbounded so a very busy profile still
// answers in a moment.
const HISTORY_SEARCH_MAX = 5000;
// Below this many distinct days of visits, an average is too thin a sample
// to call an estimate. The glue (not this file — no copy lives here) is
// expected to show COPY.historyTooFewDays instead of the number whenever a
// place's daysWithVisits is under this — not COPY.historyNothing, which is
// reserved for a place with no matching visits at all (whole-branch review
// of #86, Blocker 2): telling her "no visits" when there were visits, just
// not enough distinct days of them, is the one thing this feature promises
// never to do.
const HISTORY_MIN_DAYS = 5;

// The same rule background.js's placeFor() applies to the tab in front of
// her, so "only what she actually named" means one thing in the product:
// the host after a leading "www." is stripped must equal the place's host,
// a corner place ("youtube.com/shorts") also needs its path as a prefix,
// and when several places match the longest (most specific) one wins.
function historyPlaceOf(url, places = []) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
  const path = parsed.pathname || "/";
  let best = null;
  for (const place of places) {
    if (typeof place !== "string") continue;
    const slash = place.indexOf("/");
    const placeHost = slash === -1 ? place : place.slice(0, slash);
    if (placeHost !== host) continue;
    const placePath = slash === -1 ? "" : place.slice(slash).replace(/\/$/, "");
    const matches = !placePath || path === placePath || path.startsWith(`${placePath}/`);
    if (matches && (!best || place.length > best.length)) best = place;
  }
  return best;
}

// The history API's search() returns one item per URL carrying only its
// lastVisitTime; its getVisits() returns every visit of one URL. The glue
// asks for both (the second only for her own places), so the same arrival
// can arrive twice. One list, one entry per (url, time), and either of the
// API's two field names accepted for the time.
function mergeVisits(lists) {
  const seen = new Set();
  const out = [];
  for (const list of lists || []) {
    for (const item of list || []) {
      if (!item || typeof item.url !== "string") continue;
      const visitTime = Number.isFinite(item.visitTime) ? item.visitTime : item.lastVisitTime;
      if (!Number.isFinite(visitTime)) continue;
      const key = `${item.url}@${visitTime}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ url: item.url, visitTime });
    }
  }
  return out;
}

// A fixed copy of shared.js's own DAY_RESET_HOUR, used only when this file
// is running with no dateStr() in scope (see localDayKey below). Named
// differently on purpose: concatenating this file after shared.js in a test
// or a future build step must never collide with shared.js's own
// DAY_RESET_HOUR constant.
const HISTORY_DAY_RESET_HOUR = 3;

// Her day, the same day the rest of the product uses: it turns at 03:00,
// not at midnight (shared.js's dateStr()), so a session that runs past
// midnight is still counted against the evening it started in, not split
// across two days. Prefers the real dateStr() when shared.js has already
// defined it as a global — true in the product, where onboarding.html loads
// shared.js first — and otherwise falls back to a local copy of the exact
// same rule, so this module (and its own test) still work with nothing but
// itself loaded.
function localDayKey(ms) {
  if (typeof dateStr === "function") return dateStr(new Date(ms));
  const d = new Date(ms);
  const back = d.getHours() < HISTORY_DAY_RESET_HOUR ? 1 : 0;
  const day = new Date(d.getFullYear(), d.getMonth(), d.getDate() - back);
  const y = day.getFullYear();
  const m = String(day.getMonth() + 1).padStart(2, "0");
  const dd = String(day.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

// HISTORY_WINDOW_DAYS is nominally how wide a span this looks at, but the
// search step (bounded by HISTORY_SEARCH_MAX — a count, not a date) may not
// actually reach that far back for a very active profile. When it doesn't,
// the merged visit list is asymmetric: getVisits() (unbounded, called only
// for her own places) still returns her old arrivals, but search() (bounded,
// called for everything else) has already stopped short — so the arrivals
// elsewhere that would have shortened those old gaps are silently missing,
// and a stale arrival of hers can be mistaken for a full
// HISTORY_GAP_CAP_MINUTES stay. Clamping the start point to whichever is
// more recent — 30 days back, or the oldest arrival search() actually
// returned — keeps it honest: before that point both lists are
// known-incomplete, so nothing before it is counted at all. Pass the result
// as estimateDailyMinutes's `since` option.
function estimateWindowStart(nowMs, searchItems) {
  const windowStart = nowMs - HISTORY_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  let oldest = Infinity;
  for (const item of searchItems || []) {
    if (!item) continue;
    const t = Number.isFinite(item.visitTime) ? item.visitTime : item.lastVisitTime;
    if (Number.isFinite(t) && t < oldest) oldest = t;
  }
  return Number.isFinite(oldest) ? Math.max(windowStart, oldest) : windowStart;
}

// visits: [{url, visitTime}] in any order · places: the kabbalah's places.
// opts.since (ms): any visit strictly before it is dropped before anything
// else runs — this is what actually enforces HISTORY_WINDOW_DAYS (the
// constant alone only documents its width); pass
// estimateWindowStart(Date.now(), searchResults) so the 30-day span and the
// bounded-search correction above are enforced by the same value.
// Returns { [place]: { minutesPerDay, daysWithVisits } } for every place
// that had at least one arrival and a minutesPerDay that rounds to nonzero;
// a place with no arrivals, or whose rounded average is 0, is absent, not
// zero (a stray few seconds should not read as "we checked and it's 0").
function estimateDailyMinutes(visits, places, opts = {}) {
  const gapCap = (opts.gapCapMinutes ?? HISTORY_GAP_CAP_MINUTES) * 60000;
  const tail = (opts.tailMinutes ?? HISTORY_TAIL_MINUTES) * 60000;
  const dayKeyOf = opts.dayKeyOf || localDayKey;
  const since = Number.isFinite(opts.since) ? opts.since : -Infinity;

  const sorted = (visits || [])
    .filter(
      (v) => v && typeof v.url === "string" && Number.isFinite(v.visitTime) && v.visitTime >= since
    )
    .map((v) => ({ visitTime: v.visitTime, place: historyPlaceOf(v.url, places) }))
    .sort((a, b) => a.visitTime - b.visitTime);

  const perPlace = {};
  for (let i = 0; i < sorted.length; i++) {
    const v = sorted[i];
    if (!v.place) continue;
    const next = sorted[i + 1];
    const stay = next ? Math.min(next.visitTime - v.visitTime, gapCap) : tail;
    const days = (perPlace[v.place] ||= {});
    const day = dayKeyOf(v.visitTime);
    days[day] = (days[day] || 0) + stay;
  }

  const out = {};
  for (const [place, days] of Object.entries(perPlace)) {
    const keys = Object.keys(days);
    const total = keys.reduce((sum, k) => sum + days[k], 0);
    const minutesPerDay = Math.round(total / keys.length / 60000);
    if (minutesPerDay === 0) continue;
    out[place] = { minutesPerDay, daysWithVisits: keys.length };
  }
  return out;
}
