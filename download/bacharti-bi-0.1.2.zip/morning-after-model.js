// בחרתי בי — everything the morning after a fall decides, with no DOM and no
// chrome in sight, so all of it can be run and checked by a plain node
// script. The renderer (popup.js's recovery screen) is a thin layer over
// this file — the same split onboarding-model.js / onboarding.js already
// uses, and loaded the same way: a plain script before popup.js, so its
// top-level declarations are deliberately globals.
//
// ── why this file exists at all ─────────────────────────────────────────
// This logic was written twice. Issue #19 built it inside morning-after.js,
// a full-tab page a service worker opened by itself; issue #16 built a
// smaller copy of it inside popup.js. Both landed on main within the hour,
// each correct alone, and together they gave a woman two different screens
// for the same morning — the exact thing docs/messages.md group 3 forbids
// ("אף פעם לא שתי הודעות קימה באותו יום"). The tab is gone (see
// background.js's syncFallBadge for that argument in full); the richer half
// of what it knew is here, where the one remaining screen can reach it and
// where a test can hold it without a DOM.
//
// Every message below is docs/messages.md group 3, quoted verbatim. The
// three judgment calls issue #19 had to make are preserved word for word
// from the file this was lifted out of, because none of them were settled
// by DESIGN.md or docs/messages.md and none of them are settled now:
//
// 1. THE "QUESTION" LINE IS M-01's OWN THIRD SENTENCE, NOT FIXED CHROME.
//    DESIGN.md §6.7's skeleton draws a headline block and a smaller muted
//    "question" block under it, filling both from M-01 — but M-01 is one
//    continuous three-sentence message and the "question" is literally its
//    third sentence. M-02 through M-05 have no question sentence of their
//    own. Rather than invent one, or borrow M-01's, the question block is
//    rendered only when M-01 is the message actually chosen.
//
// 2. NO BOLD SPLIT FOR M-02 THROUGH M-05. §6.7 gives literal HTML for M-01
//    alone (`<b style="color: var(--primary)">` around its second sentence)
//    and docs/messages.md marks that same sentence in **bold**. No other
//    group 3 message carries a bold marker, so inventing a split for them
//    would be inventing emphasis nobody approved.
//
// 3. MIXED-PORTFOLIO COPY (M-02) OUTRANKS THE CONSECUTIVE-FALL COPY
//    (M-03/M-04) WHEN BOTH APPLY. docs/messages.md's usage rule selects "by
//    the number of consecutive hard days on that same kabbalah, and by the
//    length of the streak that stopped" — it does not rule on what happens
//    when other kabbalot are also still standing. M-02 is the one approved
//    template that names the standing ones, and none of M-03/M-04/M-05 leave
//    room to. So whenever at least one kabbalah still stands, M-02 shows,
//    even on a second or third consecutive fall. M-03/M-04 get their own
//    wording only when she has one kabbalah, or every kabbalah fell
//    together. STILL FLAGGED FOR SARA: a combined message for the mixed case
//    is not in the bank, and cannot be written here.

// ---- day math ----------------------------------------------------------
// Deliberately NOT shared.js's dateStr(). That one applies DAY_RESET_HOUR,
// which is right for "what day is it now" and wrong for every use below:
// the cursors here start at a stored `fellOn` (a plain calendar date) and
// walk backwards a midnight at a time, and midnight is before the reset
// hour — so dateStr() would step each cursor an extra day back and the
// consecutive-fall count would silently read the wrong days. This is the
// same calendarDate/dateStr split background.js already draws, and the same
// trap fixed-clock.mjs warns about for frozenCalendarDate/frozenDateStr.
function calendarDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function parseDay(str) {
  const [y, m, d] = String(str).split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

function dayBefore(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1);
}

// ---- reading her state, never inventing a field it does not have -------
// docs/data-model.md's kabbalah shape carries fellOn/fallAcked per kabbalah
// (decision 3) — a fall she has not yet answered is exactly
// `fellOn && !fallAcked`. Nothing else is read to decide that.
function fallenKabbalot(kabbalot) {
  return (kabbalot || []).filter((k) => k.fellOn && !k.fallAcked);
}

// How many days in a row, ending on k.fellOn, this one kabbalah has a `fall`
// event against it. Not a stored field — docs/data-model.md has no
// "consecutive fall count" — so it is derived from the one thing that is
// stored: the events journal background.js writes a `fall` entry to on every
// broken day. Bounded by how far back the shared 500-entry journal still
// reaches; flagged for Sara rather than assumed exact for a long history.
function consecutiveFallDays(k, events) {
  if (!k.fellOn) return 0;
  const fallDays = new Set(
    (events || [])
      .filter((e) => e.type === "fall" && e.kabbalahId === k.id)
      .map((e) => e.meta && e.meta.day)
  );
  let count = 0;
  let cursor = parseDay(k.fellOn);
  while (fallDays.has(calendarDate(cursor))) {
    count++;
    cursor = dayBefore(cursor);
  }
  return count;
}

// How many days in a row she kept this kabbalah immediately before the fall
// that broke it. k.streak is already 0 by the time this runs (evaluatePastDays
// resets it the moment it records the fall), so the length of the streak that
// just ended is read back from the journal's `day_success` entries — the only
// place it still exists.
function precedingStreakLength(k, events) {
  if (!k.fellOn) return 0;
  const successDays = new Set(
    (events || [])
      .filter((e) => e.type === "day_success" && e.kabbalahId === k.id)
      .map((e) => e.meta && e.meta.day)
  );
  let count = 0;
  let cursor = dayBefore(parseDay(k.fellOn));
  while (successDays.has(calendarDate(cursor))) {
    count++;
    cursor = dayBefore(cursor);
  }
  return count;
}

// docs/messages.md's M-01 annotation says "אחרי הצלחה ארוכה" by example, with
// no number drawn. background.js's first journey station is a week
// (JOURNEY_STAGES: `{ until: 7, ... }`) — reused here as this codebase's one
// existing definition of "long enough to be its own milestone", rather than
// inventing a second number.
const LONG_STREAK_DAYS = 7;

// DESIGN.md §7.2's own definition of {{קבלות_עומדות}}: "שמות הקבלות שלא
// נשברו אתמול" — every kabbalah not sitting on a fall she has not answered.
// One that fell and was acknowledged on an earlier day counts as standing
// again, same as one that never fell.
function standingNames(kabbalot, fallen) {
  const fellIds = new Set(fallen.map((k) => k.id));
  return (kabbalot || []).filter((k) => !fellIds.has(k.id)).map((k) => k.name);
}

// issue #87 — the days she released herself, read off the `released` journal
// entries popup.js writes the moment she presses the one button (one entry
// per kabbalah, meta.day = the product day). A released day sets fellOn
// exactly like a fall (background.js's evaluatePastDays), so `fellOn &&
// !fallAcked` still finds the morning; this is what tells that morning
// apart from one she broke.
function releasedDays(events, kabbalahId) {
  return new Set(
    (events || [])
      .filter((e) => e.type === "released" && e.kabbalahId === kabbalahId)
      .map((e) => e.meta && e.meta.day)
  );
}

// {{קבלות_עומדות}}'s own formatting rule (docs/messages.md's variable table):
// each name in ״gershayim״, joined with ", " and " ו" before the last; beyond
// three, the first three and then "ועוד {{k}}".
function standingListPhrase(names) {
  const quoted = names.map((n) => `״${n}״`);
  if (quoted.length === 0) return "";
  if (quoted.length === 1) return quoted[0];
  if (quoted.length <= 3) {
    return `${quoted.slice(0, -1).join(", ")} ו${quoted[quoted.length - 1]}`;
  }
  return `${quoted.slice(0, 3).join(", ")} ועוד ${quoted.length - 3}`;
}

// docs/messages.md's variable table, same row as standingListPhrase's own
// rule: "הטיית הפועל אחרי הרשימה | לפי אורך הרשימה | פריט אחד ״ממשיכה״,
// שניים ומעלה ״ממשיכות״". M-02's line (docs/messages.md group 3) was quoted
// verbatim for the two-or-more case only — that is the only case the message
// bank's own printed example shows. One name left standing needs the whole
// clause in agreement, not just the printed verb: "ממשיכות...הן...זזו" all
// carry the plural, so the singular swaps all three (Sara's approval,
// closing the mismatch the previous pass had flagged and left alone).
function standingClosingLine(count) {
  return count === 1
    ? "ממשיכה בדיוק כמו שהייתה. היא לא זזה."
    : "ממשיכות בדיוק כמו שהיו. הן לא זזו.";
}

// The one choice this file makes about *which* approved message answers this
// morning. Returns null when there is nothing unacknowledged to show.
//
// `acks` is every kabbalah this one message speaks for, and it is the whole
// list, not just the one it names. docs/messages.md group 3's usage rule is
// "אף פעם לא שתי הודעות קימה באותו יום" — one rising message a day, full
// stop. So the message chosen here has to settle the entire morning: M-02
// already names the fallen one *and* the standing ones, and M-01 is
// explicitly "וגם המקרה שכל הקבלות נשברו". Acknowledging any of them
// therefore acknowledges all of them. Both earlier implementations got this
// wrong in opposite directions and neither was caught: popup.js showed the
// screen once per fallen kabbalah (two rising messages in a day, which the
// rule forbids), and morning-after.js acknowledged only the one it named
// (leaving the rest pending, so the screen came back the next morning for a
// day she had already faced).
function chooseMorningAfter(kabbalot, events) {
  const fallen = fallenKabbalot(kabbalot);
  if (fallen.length === 0) return null;

  const acks = fallen.map((k) => k.id);

  // A day she released is not a day she broke (issue #87), so the fallen
  // list is split before any lead is chosen: released kabbalot (fellOn is
  // a day that has a `released` entry for that same kabbalah) never
  // compete for the lead and are never named. A mixed morning (one
  // released, another that genuinely fell) must not let the released one
  // win a tie on consecutive-fall stats just because it sits first in the
  // list — the lead comes from the genuinely-fallen subset only. `acks`
  // still covers every fallen id, released or not, so both settle from
  // the one message shown.
  const genuinelyFallen = fallen.filter((k) => !releasedDays(events, k.id).has(k.fellOn));

  // When every fallen kabbalah was released, group 8's own morning line
  // replaces M-01..M-05 for the whole morning — not M-02's "היה קשה" even
  // when other kabbalot stand (releasing the day releases all of them, so
  // none do), not M-03/M-04's consecutive-day wording, not M-05's long
  // streak. One message a day still speaks for the whole morning.
  if (genuinelyFallen.length === 0) {
    const lead = fallen[0];
    return { kabbalahId: lead.id, kabbalahName: lead.name, acks, id: "released" };
  }

  const withStats = genuinelyFallen.map((k) => ({
    k,
    consecutive: consecutiveFallDays(k, events),
    preceding: precedingStreakLength(k, events),
  }));
  // The hardest case leads: the kabbalah on the longest run of consecutive
  // falls, ties broken by list order — among the ones that genuinely fell
  // only; a released kabbalah is never eligible, tie or not.
  withStats.sort((a, b) => b.consecutive - a.consecutive);
  const lead = withStats[0];

  const standing = standingNames(kabbalot, fallen);
  const base = { kabbalahId: lead.k.id, kabbalahName: lead.k.name, acks };

  if (standing.length > 0) {
    return { ...base, id: "M-02", standingNames: standing };
  }
  if (lead.consecutive >= 3) return { ...base, id: "M-04" };
  if (lead.consecutive === 2) return { ...base, id: "M-03" };
  if (lead.preceding >= LONG_STREAK_DAYS) {
    return { ...base, id: "M-05", days: lead.preceding };
  }
  return { ...base, id: "M-01" };
}

// The chosen message's lines, verbatim from docs/messages.md group 3 (M-01
// through M-05). `esc` is the caller's own HTML escaper — her kabbalah's name
// is hers, typed at onboarding, and is the one string here that reaches the
// DOM without being approved microcopy. `emph` marks M-01's own bolded second
// sentence (judgment call 2); `question` carries M-01's own third sentence
// (judgment call 1) and is null for every other id.
// The "released" id (issue #87) renders group 8's morning line from the
// valve bank instead.
//
// `valve` is MESSAGE_BANK.valve (docs/messages.md group 8, via chat-bridge.js
// — popup.js passes window.MESSAGE_BANK.valve). Only the "released" id reads
// it; every other id is group 3, quoted below as before. Without a bank the
// released morning renders no line at all rather than borrowing group 3's.
function buildMorningAfterMessage(choice, esc = (s) => String(s), valve = null) {
  const name = esc(choice.kabbalahName);
  switch (choice.id) {
    case "released": {
      // STILL FLAGGED FOR SARA: popup.js's recovery screen also renders an
      // "ease the kabbalah" button (canEaseFor / renderRecoveryScreen)
      // alongside the restart one on every morning-after screen, and its
      // copy is M-01..M-05's, never written with a released morning in
      // mind — "להקל על הקבלה" reads as answering a fall, not a day she
      // released on purpose. Not decided or changed here.
      const text = valve && valve.moments && valve.moments.morning ? valve.moments.morning.text : "";
      return { lines: text.split("\n").filter(Boolean), emph: null, question: null };
    }
    case "M-02":
      return {
        lines: [
          `אתמול ב״${name}״ היה קשה, והספירה שם מתחילה מהיום.`,
          `${standingListPhrase(choice.standingNames.map(esc))} ${standingClosingLine(choice.standingNames.length)}`,
        ],
        emph: null,
        question: null,
      };
    case "M-03":
      return {
        lines: [
          `גם אתמול ב״${name}״ היה קשה. אני כאן, ואני רוצה להסתכל איתך רגע על הקבלה עצמה.`,
          "אולי היעד שקבענו גבוה מדי לעכשיו.",
        ],
        emph: null,
        question: null,
      };
    case "M-04":
      return {
        lines: [
          `שלושה ימים שב״${name}״ לא הולך, וזה בדרך כלל סימן שהיעד גבוה מדי לעכשיו.`,
          "בואי נקטין אותו למשהו שאת בטוחה שתעמדי בו.",
        ],
        emph: null,
        question: null,
      };
    case "M-05":
      return {
        lines: [
          `היו לך ${choice.days} ימים ברצף ב״${name}״, ואתמול לא הלך. הימים האלה עדיין שלך.`,
          "נתחיל היום מחדש",
        ],
        emph: null,
        question: null,
      };
    case "M-01":
    default:
      return {
        lines: ["אתמול היה יום קשה. זה קורה לכולן — באמת."],
        emph: "הרצף התאפס, אבל את לא.",
        question: "נתחיל מחדש היום? או שנתאים את הקבלה למשהו שקצת יותר קל לך עכשיו?",
      };
  }
}

// M-07 and M-08 — the two after-states DESIGN.md §6.7 draws. Both carried the
// v3 wording verbatim until Sara read the whole bank aloud (issue #5) and
// replaced it: "היום מתחילות" / "מתחילות לתכנן" are participles with nobody
// doing the verb, so the ear hears half a sentence. The approved fix is first
// person plural future — the verb carries its own subject. docs/messages.md
// group 3 is the source of truth for both strings.
const MORNING_AFTER_RESTARTED = "נתחיל היום. יום אחד בכל פעם.";
const MORNING_AFTER_EASE = "נתכנן את הקבלה מחדש, מההתחלה, יחד";
