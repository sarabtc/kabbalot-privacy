// בחרתי בי — content script: the soft-block overlay + the 10-minute warning.
// The single most important screen in the product (DESIGN.md §6.3, §6.4).
// Rendered inside a closed shadow root so host-page styles cannot leak in,
// and so ours cannot leak out (:host { all: initial; } below — load-bearing,
// kept unchanged from the pre-v3 file).
//
// v3: lavender-on-white, the illustrated companion character, Secular One +
// Assistant. No emoji anywhere (DESIGN.md §4 — the character carries the
// warmth, never a glyph). Every colour below is a var(--token) copied from
// DESIGN.md §2.8 into the block marked PASTED below; extension/tests/
// the-stop-page-speaks-in-tokens.mjs fails if the two drift apart, or if a
// hex literal turns up anywhere else in this file's CSS.

(() => {
  if (window.__kabbalotInjected) return;
  window.__kabbalotInjected = true;

  const inExtension =
    typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id;

  const assetUrl = (path) => (inExtension ? chrome.runtime.getURL(path) : path);
  const fontUrl = (file) => assetUrl(`fonts/${file}`);
  // v3's own five onboarding poses live in character/v3/ (issue #15); heart.png
  // joins them here — the one v3 pose onboarding never needed, since only the
  // stop page, the morning-after and the chat window use it (DESIGN.md §4).
  const charUrl = (file) => assetUrl(`character/v3/${file}`);

  // windowLabel (an hour range she set herself) is her data, not product
  // copy, and reaches the DOM without having been approved as microcopy.
  // Escaped before it ever touches innerHTML.
  //
  // Fix (Founder Ruling 1, 2026-08-26): a kabbalah's own NAME used to be
  // the other string this escaped — the "kicker" badge, below — but
  // background.js no longer sends one to this screen at all (see
  // showOverlay's own `hasKabbalah`/KICKER_TEXT). The overlay sits on top
  // of a site she may be showing someone else in the room; the kicker is
  // a fixed, neutral phrase now, not her data.
  const escapeHtml = (s) =>
    String(s).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[c]);

  const CSS = `
    @font-face {
      font-family: "Secular One";
      src: url("${fontUrl("secular-one-hebrew-400-normal.woff2")}") format("woff2");
      font-weight: 400; font-style: normal; font-display: swap;
    }
    @font-face {
      font-family: "Secular One";
      src: url("${fontUrl("secular-one-latin-400-normal.woff2")}") format("woff2");
      font-weight: 400; font-style: normal; font-display: swap;
    }
    @font-face {
      font-family: "Assistant";
      src: url("${fontUrl("assistant-hebrew-400-normal.woff2")}") format("woff2");
      font-weight: 400; font-style: normal; font-display: swap;
    }
    @font-face {
      font-family: "Assistant";
      src: url("${fontUrl("assistant-hebrew-600-normal.woff2")}") format("woff2");
      font-weight: 600; font-style: normal; font-display: swap;
    }
    @font-face {
      font-family: "Assistant";
      src: url("${fontUrl("assistant-hebrew-700-normal.woff2")}") format("woff2");
      font-weight: 700; font-style: normal; font-display: swap;
    }
    @font-face {
      font-family: "Assistant";
      src: url("${fontUrl("assistant-latin-400-normal.woff2")}") format("woff2");
      font-weight: 400; font-style: normal; font-display: swap;
    }
    @font-face {
      font-family: "Assistant";
      src: url("${fontUrl("assistant-latin-600-normal.woff2")}") format("woff2");
      font-weight: 600; font-style: normal; font-display: swap;
    }
    @font-face {
      font-family: "Assistant";
      src: url("${fontUrl("assistant-latin-700-normal.woff2")}") format("woff2");
      font-weight: 700; font-style: normal; font-display: swap;
    }

    :host { all: initial; }

    /* ↓↓↓ PASTED FROM DESIGN.md §2.8, UNCHANGED except the selector itself
       (:root → :host, so the tokens are scoped to this shadow tree instead
       of the host page's real :root, which this file does not own and must
       not touch). extension/tests/the-stop-page-speaks-in-tokens.mjs diffs
       every declaration below against DESIGN.md §2.8 — do not retype a
       value from the tables, do not add a token that is not there. ↓↓↓ */
    :host {
      /* ===== צבע: סגול ===== */
      --primary:            #7C5CE0;
      --primary-hover:      #6A4BD1;
      --primary-grad-to:    #9878EC;
      --primary-soft:       #EFEAFC;
      --primary-tint-hover: #F1ECFC;
      --on-primary:         #FFFFFF;
      --on-primary-soft:    #F3EEFF;
      --on-primary-muted:   #E5DCFF;
    
      /* ===== צבע: משטחים ודיו ===== */
      --surface:      #FFFFFF;
      --bg-screen:    #F6F2FF;
      --bg-app:       #E9E4F6;
      --bg-block-to:  #EDE6FB;
      --ink:          #2C3153;
      --ink-muted:    #6B6787;
      --ink-faint:    #A7A2BF;
      --line:         #E2DBF5;
      --line-strong:  #D9CFF5;
      --track:        #E9E2F8;
    
      /* ===== צבע: ירוק ===== */
      --success-ink:  #1F8C74;
      --success-soft: #DFF5EE;
      --success-data: #33C6A6;
    
      /* ===== צבע: ורוד ===== */
      --pink:            #FF8FB1;
      --pink-ink:        #C2437A;
      --pink-soft:       #FFE4ED;
      --pink-soft-hover: #FBD5E3;
      --pink-line:       #F8C6D8;
      --pink-tint-hover: #FFF0F5;
    
      /* ===== צבע: מקומי לתצוגת התוכנית באונבורדינג ===== */
      --week2-num: #E8618C;
      --week3-num: #2AA98E;
    
      /* ===== גרדיאנטים ===== */
      --grad-brand:    linear-gradient(135deg, var(--primary), var(--primary-grad-to));
      --grad-block:    linear-gradient(160deg, var(--bg-screen), var(--bg-block-to));
      --grad-progress: linear-gradient(90deg, var(--primary), var(--pink));
      --grad-toast:    linear-gradient(var(--primary), var(--pink));
    
      /* ===== טיפוגרפיה ===== */
      --font-display: 'Secular One', 'Arial Hebrew', system-ui, sans-serif;
      --font-text:    Assistant, 'Arial Hebrew', system-ui, sans-serif;
    
      /* Secular One */
      --fs-display-xl: 42px;  --fs-display-l: 38px;
      --fs-h1:         34px;  --fs-h1-done:   32px;
      --fs-num-l:      30px;  --fs-h2:        28px;
      --fs-h3:         26px;  --fs-num-m:     24px;
      --fs-h4:         22px;  --fs-num-s:     20px;
      --fs-num-xs:     19px;  --fs-num-xxs:   17px;
    
      /* Assistant */
      --fs-cta-lg: 17px;  --fs-lead:  16px;
      --fs-body:   15px;  --fs-body-s: 14px;
      --fs-label:  13px;  --fs-fine:  12px;
      --fs-micro:  11px;  --fs-nano:  10px;
    
      --lh-num:      1.1;   /* 1.15 במספרים קטנים, 1.15 בשעונים */
      --lh-heading:  1.3;   /* 1.25 ב-h1 */
      --lh-tight:    1.5;
      --lh-body:     1.6;
      --lh-relaxed:  1.7;
    
      /* ===== מרווחים ===== */
      --space-0:  2px;   --space-1:  3px;   --space-2:  4px;
      --space-3:  5px;   --space-4:  6px;   --space-5:  8px;
      --space-6: 10px;   --space-7: 12px;   --space-8: 14px;
      --space-9: 16px;   --space-10: 18px;  --space-11: 20px;
      --space-12: 28px;
    
      /* ===== רדיוסים ===== */
      --r-pill:   999px;
      --r-shell:   24px;
      --r-panel:   20px;
      --r-bubble:  18px;
      --r-card:    16px;
      --r-inner:   14px;
      --r-badge:   12px;
      --r-icon:    10px;
      --r-tail:     4px;
      --r-bar:     6px 6px 2px 2px;
    
      /* ===== צללים ===== */
      --shadow-card:    0 3px 12px rgba(60,45,120,0.08);
      --shadow-chat:    0 1px  4px rgba(60,45,120,0.08);
      --shadow-shell:   0 6px 24px rgba(60,45,120,0.10);
      --shadow-float:   0 4px 16px rgba(60,45,120,0.12);
      --shadow-bubble:  0 4px 14px rgba(60,45,120,0.12);
      --shadow-panel:   0 8px 26px rgba(60,45,120,0.14);
      --shadow-dial:    0 6px 18px rgba(60,45,120,0.14);
      --shadow-handle:  0 3px 10px rgba(60,45,120,0.25);
      --shadow-primary: 0 6px 16px rgba(124,92,224,0.35);
      --shadow-pill:    0 6px 20px rgba(60,45,120,0.35);
    
      --char-shadow-lg:       drop-shadow(0 10px 18px rgba(60,45,120,0.18));
      --char-shadow-md:       drop-shadow(0  5px 10px rgba(60,45,120,0.20));
      --char-shadow-on-brand: drop-shadow(0  6px 12px rgba(40,25,90,0.30));
    
      /* ===== שכבות ===== */
      --z-decor:   0;
      --z-content: 1;
      --z-overlay: 2147483647;   /* דף עצירה, טיימר צף, טוסט — בתוך עמוד זר */
    
      /* ===== תנועה ===== */
      --motion-enter:      200ms;
      --motion-enter-fast: 180ms;
      --motion-state:      120ms;
      --ease:              ease-out;
    }
    /* ↑↑↑ END OF THE PASTED BLOCK ↑↑↑ */

    .backdrop {
      position: fixed;
      inset: 0;
      z-index: var(--z-overlay);
      background: var(--grad-block);
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      direction: rtl;
      font-family: var(--font-text);
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      color: var(--ink);
      animation: kb-fade var(--motion-enter) var(--ease);
    }
    @keyframes kb-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes kb-pop {
      from { opacity: 0; transform: scale(0.94); }
      to   { opacity: 1; transform: scale(1); }
    }

    /* The composition frame from DESIGN.md §6.3/§6.4. It carries no
       background/shadow/radius of its own — the backdrop already paints
       --grad-block across the whole viewport, and §6.3/§6.4's own closing
       line puts overflow:hidden on the BACKDROP, not the shell, precisely so
       the companion halo (below) can bleed past the shell's edge into a
       backdrop of the exact same gradient with no seam. */
    .shell {
      position: relative;
      width: 640px;
      height: 600px;
      max-width: calc(100% - 48px);
      max-height: calc(100% - 48px);
      display: flex;
      align-items: center;
    }

    /* §2.1 "הילות ורקעים דקורטיביים" — companion mode only (§6.4: "בלי
       ההילה הוורודה"). rgba, not a token: §2.1 itself defines the halo this
       way and the no-hex test explicitly carves out rgba() as not being a
       colour literal in the sense it forbids. */
    .halo-pink {
      position: absolute;
      z-index: var(--z-decor);
      top: -140px;
      inset-inline-start: -100px;
      width: 420px;
      height: 420px;
      border-radius: var(--r-pill);
      background: radial-gradient(circle, rgba(255, 143, 177, 0.14), transparent 65%);
      pointer-events: none;
    }

    .char-block {
      position: absolute;
      z-index: var(--z-content);
      filter: var(--char-shadow-lg);
    }
    .char-block img {
      display: block;
      height: 100%;
      width: auto;
    }

    .bubble {
      position: absolute;
      z-index: var(--z-content);
      background: var(--surface);
      border-radius: var(--r-bubble);
      border-end-end-radius: var(--r-tail);
      padding: 11px 16px;
      font-size: var(--fs-body);
      font-weight: 600;
      color: var(--ink);
      box-shadow: var(--shadow-bubble);
      max-width: 220px;
      line-height: var(--lh-tight);
      animation: kb-pop var(--motion-enter) var(--ease);
    }

    .panel {
      position: relative;
      z-index: var(--z-content);
      width: 340px;
      margin-inline-start: 44px;
      background: var(--surface);
      border-radius: var(--r-panel);
      box-shadow: var(--shadow-panel);
      padding: var(--space-12);
      display: flex;
      flex-direction: column;
      gap: var(--space-9);
    }
    /* issue 136: the panel is the element that takes focus when the screen
       goes up (tabindex="-1"), so that no button is armed to fire on a
       reflex press of Space. It is a container, not a control — a focus ring
       drawn around the whole card would read as a mistake, and there is no
       action here for the ring to be pointing at. The buttons keep their own
       :focus-visible ring further down, which is the one that matters: it is
       the one she sees once she has actually tabbed to a choice. */
    .panel:focus {
      outline: none;
    }
    /* §6.3 "מצב סיימנו" / §6.4 done card: the panel itself re-centres. */
    .panel.is-done {
      padding: 32px var(--space-12);
      gap: var(--space-8);
      text-align: center;
      animation: kb-pop var(--motion-enter) var(--ease);
    }
    /* §6.3: "דיאלוג ההארכה מחליף את תוכן הפאנל" — the WHOLE panel, not just
       the button row, with its own gap. */
    .panel.is-pause {
      gap: 18px;
      animation: kb-pop var(--motion-enter) var(--ease);
    }

    .kicker {
      font-size: var(--fs-label);
      font-weight: 600;
      color: var(--ink-muted);
    }

    .headline {
      font-family: var(--font-display);
      font-weight: 400;
      font-size: var(--fs-h3);
      line-height: var(--lh-heading);
      color: var(--ink);
      text-wrap: pretty;
    }

    .explain {
      font-size: var(--fs-body);
      line-height: var(--lh-relaxed);
      color: var(--ink-muted);
    }

    .strip-success {
      background: var(--success-soft);
      border-radius: var(--r-inner);
      padding: 12px 14px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      color: var(--ink);
    }
    .strip-num {
      font-family: var(--font-display);
      color: var(--success-ink);
      font-size: var(--fs-h3);
    }

    .buttons { display: flex; flex-direction: column; gap: 10px; }

    button {
      font-family: var(--font-text);
      cursor: pointer;
      border: none;
    }
    button:focus-visible {
      outline: 2px solid var(--primary);
      outline-offset: 2px;
    }

    .btn-primary {
      background: var(--primary);
      color: var(--on-primary);
      border-radius: var(--r-pill);
      font-weight: 700;
      box-shadow: var(--shadow-primary);
    }
    .btn-primary:hover { background: var(--primary-hover); }
    .btn-primary.block {
      padding: 14px 24px;
      font-size: var(--fs-lead);
      min-height: 46px;
    }

    .btn-pink-outline {
      background: var(--surface);
      color: var(--pink-ink);
      border: 1.5px solid var(--pink-line);
      border-radius: var(--r-pill);
      padding: 12px 24px;
      font-size: var(--fs-body);
      font-weight: 600;
      min-height: 44px;
    }
    .btn-pink-outline:hover { background: var(--pink-tint-hover); }

    /* The honest note when the week's pool is spent, and the "something on
       our end didn't answer" fallback: both warm, both pink-ink, same role
       as "בחירה מודעת היא לא נפילה" (§6.3) — a boundary, not a scolding. */
    .grace-note {
      font-size: var(--fs-body-s);
      line-height: var(--lh-body);
      font-weight: 600;
      color: var(--pink-ink);
    }

    .btn-neutral {
      background: var(--primary-soft);
      color: var(--ink);
      border-radius: var(--r-pill);
      padding: 12px;
      font-size: var(--fs-body);
      font-weight: 600;
      min-height: 44px;
    }

    .pause-line {
      font-size: var(--fs-lead);
      line-height: var(--lh-relaxed);
      font-weight: 600;
      color: var(--ink);
    }

    .done-card {
      background: var(--primary-soft);
      border-radius: var(--r-card);
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      text-align: center;
      animation: kb-pop var(--motion-enter) var(--ease);
    }
    .done-h2 {
      font-family: var(--font-display);
      font-weight: 400;
      font-size: var(--fs-h2);
      color: var(--primary);
      line-height: var(--lh-heading);
    }
    .done-h4 {
      font-family: var(--font-display);
      font-weight: 400;
      font-size: var(--fs-h4);
      color: var(--primary);
      line-height: var(--lh-heading);
    }
    .done-copy {
      font-size: var(--fs-lead);
      line-height: var(--lh-relaxed);
      color: var(--ink);
    }
    .done-copy.small {
      font-size: var(--fs-body);
      line-height: var(--lh-body);
    }

    /* 10-minute warning toast — §3.6. Bottom corner, opposite the floating
       timer's bottom-start position (below) so the two never collide. */
    .toast-wrap {
      position: fixed;
      z-index: var(--z-overlay);
      inset-block-end: 24px;
      inset-inline-end: 24px;
      direction: rtl;
      font-family: var(--font-text);
    }
    .toast {
      display: flex;
      overflow: hidden;
      max-width: 360px;
      background: var(--surface);
      border-radius: var(--r-inner);
      box-shadow: var(--shadow-float);
      animation: kb-fade var(--motion-enter) var(--ease);
    }
    .toast-accent { width: 4px; flex: none; background: var(--grad-toast); }
    .toast-text {
      padding: 12px 16px;
      font-size: var(--fs-body-s);
      line-height: var(--lh-body);
      font-weight: 600;
      color: var(--ink);
    }

    /* Floating timer — §3.6, T-09, issue #21. Bottom-start corner, opposite
       the toast above so the two never collide. Only ever mounted for a
       dailyLimit kabbalah: background.js's timerFor() returns null for a
       window kabbalah (no quota for this pill's copy to describe), during
       Shabbat (nothing is measured, so nothing honest to show), and once
       she is blocked (the stop screen is already the truth on that page). */
    .floating-timer {
      position: fixed;
      z-index: var(--z-overlay);
      inset-block-end: 12px;
      inset-inline-start: 12px;
      direction: rtl;
      font-family: var(--font-text);
      display: flex;
      align-items: center;
      gap: 10px;
      background: var(--grad-brand);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-pill);
      padding-block: 6px;
      padding-inline-start: 7px;
      padding-inline-end: 12px;
      border: none;
      animation: kb-fade var(--motion-enter) var(--ease);
    }
    .ft-arc {
      position: relative;
      flex: none;
      width: 44px;
      height: 44px;
      border-radius: var(--r-pill);
    }
    .ft-ring {
      position: absolute;
      inset: 0;
      border-radius: var(--r-pill);
      /* background is a conic-gradient set inline per render — how much of
         the ring is --success-data green is today's remaining share of the
         quota, computed in renderTimer(). Not expressible as a static rule. */
    }
    .ft-char {
      position: absolute;
      inset: 4px;
      border-radius: var(--r-pill);
      background: var(--surface);
      overflow: hidden;
    }
    /* char-heart, DESIGN.md §4's own floating-timer row: "74px tall inside
       the 44px ring". heart.png is a full-body illustration (216×700) —
       74px of *height alone* is the whole figure shrunk to fit, not a face
       cropped to fit, and this ring only ever shows a ~36×36 window (44px
       minus the 4px inset on each side). Issue #85: the ring used to render
       the image at that 74px height, bottom-aligned (align-items: flex-end,
       matching the ratio the number implies) — which put the crop window
       over her waist and skirt, because that is what sits at the bottom of
       a 700px-tall figure. Her face, in the top fifth of the source image,
       never entered the frame.
       object-fit: cover + object-position: top fills the ring with the
       source's own top edge — hairline down through the shoulders, which is
       exactly what design/Kabbalot Pilot v3.dc.html's own crop looks like
       once you actually render it (its default, unset align-items resolves
       to flex-start for a fixed-height image, i.e. top-aligned — the
       opposite of what this file had). No drop-shadow, unlike the stop
       page's character (mountCharacter(), --char-shadow-lg): the pill is
       small and sits over page content that is not ours, and a drop-shadow
       at this size reads as a smudge, not depth. */
    .ft-char img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: top center;
      display: block;
    }
    .ft-info { display: flex; flex-direction: column; gap: 1px; }
    .ft-clock {
      font-family: var(--font-display);
      font-size: 19px;
      line-height: var(--lh-num);
      color: var(--on-primary);
    }
    .ft-caption {
      font-size: var(--fs-micro);
      font-weight: 600;
      color: var(--on-primary-muted);
    }
    /* The one affordance DESIGN.md's mockup does not depict, because the
       mockup is a single frame and cannot show a decision about dismissal.
       Small and quiet on purpose: this is not a second button competing
       with the pill's own information, just a way out of it. */
    .ft-close {
      flex: none;
      align-self: flex-start;
      width: 18px;
      height: 18px;
      margin-inline-start: 2px;
      border-radius: var(--r-pill);
      background: rgba(255, 255, 255, 0.18);
      color: var(--on-primary);
      font-family: var(--font-text);
      font-size: var(--fs-micro);
      line-height: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
    }
    .ft-close:hover { background: rgba(255, 255, 255, 0.32); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
      }
    }
  `;

  let host = null;

  // ── issue 136: the stop page has to actually stop the sound ──────────────
  // Sara, in real use on YouTube Shorts: "it isn't really a block. It doesn't
  // remove the page, it's only a filter over it, so I keep hearing the video
  // playing until I stop it myself." Until now this file had no pause() and
  // no <video>/<audio> handling anywhere — the screen painted on top and the
  // reel kept running underneath. For Shorts that is the whole feature gone:
  // the content is continuous audio-video, so a woman who is "stopped" is
  // still listening.
  //
  // What this holds to, deliberately:
  //
  //   * It only ever runs while our own overlay is up. holdMedia() is called
  //     from showOverlay() after the host is in the document, and
  //     releaseMedia() from removeOverlay(). A page this extension has not
  //     decided to block never has a single element touched.
  //   * One pause at mount is not enough. YouTube restarts playback on its
  //     own, and swaps the <video> element out from under us on its SPA
  //     navigations (one Short to the next). So every element we find also
  //     gets a "play" listener that pauses it again, and a MutationObserver
  //     watches for elements that appear later.
  //   * Nothing is resumed when the overlay comes down. If she earned five
  //     more minutes she can press play herself; a video that springs back
  //     to life on its own was never asked for and is startling.
  //   * Nothing here may throw. A page we cannot fully silence must still
  //     get the screen — a half-paused page with an overlay is far better
  //     than a playing page with no overlay at all. Every DOM call below is
  //     either optional-chained or inside a try.
  //
  // What it honestly does not reach: media inside a cross-origin <iframe>
  // (an embedded player on someone else's site) is out of a content script's
  // hands entirely, and media inside the host page's own shadow roots is not
  // walked either. youtube.com's player is in the main document, which is
  // the case in the report.
  let mediaHold = null;

  function pauseOne(el) {
    try {
      el.pause?.();
    } catch {
      // A media element mid-teardown can throw on pause(). Not our problem
      // to solve, and never a reason to abandon the rest of the walk.
    }
  }

  function findMedia() {
    const root = document.documentElement;
    const out = [];
    for (const tag of ["video", "audio"]) {
      try {
        out.push(...root.querySelectorAll(tag));
      } catch {
        // Nothing sane throws here; a walk that fails still returns what it
        // has, so the overlay still goes up.
      }
    }
    return out;
  }

  function holdMedia() {
    if (mediaHold) return; // one hold per overlay, never two sets of listeners
    const seen = new Set();
    // The listener re-pauses whatever just started, so this is the same
    // answer to "YouTube pressed play again" and to "she pressed play".
    const onPlay = (e) => {
      const el = e && e.target;
      if (el) pauseOne(el);
    };
    const hold = (el) => {
      if (seen.has(el)) return;
      seen.add(el);
      try {
        el.addEventListener?.("play", onPlay);
      } catch {
        // Still pause it below even if we could not arm the listener.
      }
      pauseOne(el);
    };

    const sweep = () => {
      for (const el of findMedia()) hold(el);
    };

    // Deliberately reads the records rather than re-sweeping the whole
    // document on every batch: YouTube mutates its DOM constantly, and a
    // querySelectorAll over the page per batch is a cost we would be paying
    // on her machine for as long as the screen is up. Only nodes that were
    // actually added get looked at — which is the case this exists for (the
    // <video> swapped in on the next Short).
    const onMutations = (records) => {
      if (!records || !records.length) {
        sweep();
        return;
      }
      for (const rec of records) {
        for (const node of rec.addedNodes || []) {
          if (!node) continue;
          const tag = String(node.tagName || "").toLowerCase();
          if (tag === "video" || tag === "audio") {
            hold(node);
            continue;
          }
          if (!node.querySelectorAll) continue;
          for (const inner of ["video", "audio"]) {
            try {
              for (const el of node.querySelectorAll(inner)) hold(el);
            } catch {
              // A node type that cannot be walked. Skip it, keep going.
            }
          }
        }
      }
    };

    // `window.MutationObserver`, not the bare global: content.js is executed
    // through a Function(...) wrapper in extension/tests/, where the bare
    // name would be a ReferenceError. The page's own window carries it in a
    // real content script, and the tests' DOM stub carries it too, so this
    // is the path that actually gets covered rather than a dead branch.
    let observer = null;
    const MO = window.MutationObserver;
    if (typeof MO === "function") {
      try {
        observer = new MO(onMutations);
        observer.observe(document.documentElement, { childList: true, subtree: true });
      } catch {
        observer = null;
      }
    }

    mediaHold = {
      release() {
        try {
          observer?.disconnect();
        } catch {
          // Nothing to do; the overlay is coming down either way.
        }
        for (const el of seen) {
          try {
            el.removeEventListener?.("play", onPlay);
          } catch {
            // Same.
          }
        }
        // Deliberately no play() anywhere in here. See the header above.
      },
    };
    sweep();
  }

  function releaseMedia() {
    if (!mediaHold) return;
    const hold = mediaHold;
    mediaHold = null;
    hold.release();
  }

  function removeOverlay() {
    releaseMedia();
    if (host) {
      host.remove();
      host = null;
    }
  }

  // See renderTimer()'s own header comment for the shape and reasoning.
  // `timerTickHandle` is the one interval this file starts on its own
  // initiative rather than in reaction to a message (issue #86) — everything
  // that touches it lives together here, on purpose: a per-second interval
  // is exactly the kind of thing that survives a removal by accident if
  // starting and stopping it are not each other's only two doors.
  let timerTickHandle = null;
  function stopTimerTicking() {
    if (timerTickHandle !== null) {
      clearInterval(timerTickHandle);
      timerTickHandle = null;
    }
  }
  function startTimerTicking() {
    stopTimerTicking(); // never two running at once for one pill
    timerTickHandle = setInterval(tick, 1000);
  }

  // Builds the <img> with real DOM APIs (createElement + property
  // assignment), never an inline onerror="..." HTML attribute: a host page
  // with its own script-src CSP can silently drop inline handler attributes
  // parsed through innerHTML, and a broken image with no fallback is exactly
  // what "never a hole" (§9) forbids.
  function mountCharacter(container, file) {
    const img = document.createElement("img");
    img.alt = "";
    img.onerror = () => {
      img.style.display = "none";
    };
    img.src = charUrl(file);
    container.appendChild(img);
  }

  // §6.3/§6.4's "מצב סיימנו" and the done card: reached both from the
  // primary button and from declining the pause dialog ("בעצם, סיימתי" —
  // "actually, I'm done" — is the same outcome as "סיימנו להיום", and the
  // copy library (§7) has exactly one closing message per mode, not two).
  function renderDone(panel, mode, reason) {
    const committed = mode === "commitment";
    const inWindow = reason === "window" || reason === "rule-window";
    const headline = "כל הכבוד! עשית את זה";
    // The approved sentences (§7) both end in "נתראה מחר" — true for the
    // daily quota, but an hour-window can reopen later the same day. Rather
    // than ship a false promise, the window/rule-window case keeps this
    // file's own pre-v3 sentence, which makes no claim about when. Not in
    // the v3 copy library; flagged in the PR report.
    const body = inWindow
      ? "הרצף שלך ממשיך לצמוח. החיים האמיתיים מחכים לך בחוץ."
      : committed
        ? "את מסוגלת. תמשיכי ככה — נתראה מחר."
        : "את מסוגלת — והיום הוכחת את זה שוב. תמשיכי ככה, נתראה מחר.";

    if (committed) {
      panel.className = "panel is-done";
      panel.innerHTML = `
        <div class="done-card">
          <div class="done-h4">${headline}</div>
          <div class="done-copy small">${body}</div>
        </div>`;
    } else {
      panel.className = "panel is-done";
      panel.innerHTML = `
        <div class="done-h2">${headline}</div>
        <div class="done-copy">${body}</div>`;
    }
  }

  let current = null;

  // Fix (Founder Ruling 1, 2026-08-26): the kicker badge used to print
  // whichever kabbalah owned the block ({{שם}}, background.js's
  // `kabbalahName`). This screen paints on top of the page she was
  // actually looking at, which may be a site she is showing someone else
  // in the room — the same reason the desktop notification stopped
  // carrying a name. Replaced with one fixed, neutral phrase, shown
  // whenever a specific kabbalah owns the block (as the old badge was) and
  // never otherwise — see `hasKabbalah`, showOverlay, below.
  //
  // UNAPPROVED: not in DESIGN.md §7 or docs/messages.md — the kicker never
  // had approved copy of its own before this fix either, since it only
  // ever interpolated her own data. Reviewed with avshalom-hebrew-expert,
  // hebrew-writing-skill and make-human-lite; listed in the report.
  const KICKER_TEXT = "הקבלה שלך";

  function showOverlay(opts = {}) {
    current = opts;
    removeOverlay();

    const reason = opts.reason;
    const mode = opts.mode || "companion";
    const committed = mode === "commitment";
    const graceLeft = opts.graceLeft || 0;
    // Fix (Founder Ruling 1, 2026-08-26): `kabbalahId`, not `kabbalahName` —
    // background.js (blockStateFor) no longer sends a name at all. Only
    // whether an owning kabbalah exists reaches this screen (`quota` /
    // `rule-window` carry an id, the browser-wide `window` reason does
    // not) — the kicker itself is a fixed, neutral phrase, never the id's
    // own value. See KICKER_TEXT, below.
    const hasKabbalah = Boolean(opts.kabbalahId);
    const windowLabel = opts.windowLabel;
    const timeGotBack = opts.timeGotBack;

    // A quiet window is not an overrun. She has not exceeded anything — she
    // is keeping exactly what she set, so the words must say that. One
    // kabbalah's own hour ("rule-window") is the same promise at a smaller
    // scale as the browser-wide quiet hours ("window"), so both read the
    // same way here — two reasons, one set of words (kept from the pre-v3
    // file; DESIGN.md's own mockup only depicts the daily-quota screen).
    const inWindow = reason === "window" || reason === "rule-window";
    const headline = inWindow ? "עכשיו זה זמן אחר" : "סיימת את הזמן שקבעת לעצמך להיום.";

    // §6.4's explanation is mode-driven, not reason-driven — it is about
    // what commitment mode does, not about why she is here right now, so it
    // covers quota, rule-window and window alike. Companion mode gets no
    // middle paragraph for the quota screen at all (§6.3's skeleton goes
    // straight from headline to the strip); the window/rule-window sentence
    // is pre-v3 connective tissue this file already had, kept because the
    // approved mockup never depicted that screen to say otherwise.
    const explain = committed
      ? "בחרת במצב מחויבות — וזה בדיוק מה שהוא עושה עכשיו. ההחלטה שקיבלת ברגע חזק שומרת עלייך ברגע פחות חזק. נתראה מחר"
      : inWindow
        ? "קבעת לעצמך שבשעות האלה את לא כאן, ואת בדיוק בתוך מה שהחלטת."
        : null;

    // §6.3's strip: a sentence with the minutes emphasised, for the daily
    // quota. For a window/rule-window block there is nothing to add up —
    // she kept exactly the hours she set — so the strip is just that range,
    // dir="ltr" per §5.
    let stripHtml = null;
    if (inWindow && windowLabel) {
      stripHtml = `<span class="strip-num" dir="ltr">${escapeHtml(windowLabel)}</span>`;
    } else if (!inWindow && timeGotBack) {
      stripHtml = `היום החזרת לעצמך <span class="strip-num">${timeGotBack} דקות</span>. זה שלך`;
    }

    const charFile = committed ? "offer.png" : "heart.png";
    const charPos = committed ? { end: "36px", top: "98px" } : { end: "26px", top: "90px" };
    const bubblePos = committed ? { end: "110px", top: "36px" } : { end: "120px", top: "28px" };

    // §11 item 6: grace is only ever offered on a companion page; on a
    // commitment page there is nothing to offer and nothing that "ran out"
    // — this branch is the fix for the mutation that survived issue #13's
    // testing (see the-page-says-what-is-true.mjs's own header comment).
    const graceAffordance =
      graceLeft > 0
        ? `<button class="btn-pink-outline" id="kb-grace">עוד 5 דקות (נשארו ${graceLeft} השבוע)</button>`
        : committed
          ? ""
          : `<div class="grace-note">חריגות השבוע נוצלו — ואת עדיין בסדר גמור</div>`;

    host = document.createElement("div");
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = CSS;
    root.appendChild(style);

    const backdrop = document.createElement("div");
    backdrop.className = "backdrop";
    backdrop.innerHTML = `
      <div class="shell">
        ${committed ? "" : '<div class="halo-pink"></div>'}
        <div class="char-block" id="kb-char" style="inset-inline-end:${charPos.end}; top:${charPos.top}; height:440px;"></div>
        <div class="bubble" style="inset-inline-end:${bubblePos.end}; top:${bubblePos.top};">כל הכבוד. עשית את זה</div>
        <div class="panel" id="kb-panel" tabindex="-1">
          ${hasKabbalah ? `<div class="kicker">${KICKER_TEXT}</div>` : ""}
          <div class="headline">${headline}</div>
          ${explain ? `<div class="explain">${explain}</div>` : ""}
          ${stripHtml ? `<div class="strip-success">${stripHtml}</div>` : ""}
          <div class="buttons" id="kb-buttons">
            <button class="btn-primary block" id="kb-done">סיימנו להיום</button>
            ${graceAffordance}
          </div>
        </div>
      </div>`;
    root.appendChild(backdrop);
    document.documentElement.appendChild(host);
    // Only now, with the screen actually in the document — a page this
    // extension has not decided to block never reaches this line, and so
    // never has a video of its own touched (issue 136).
    holdMedia();
    mountCharacter(backdrop.querySelector("#kb-char"), charFile);

    const panel = backdrop.querySelector("#kb-panel");
    // issue 136, second half: this used to be
    // `panel.querySelector("#kb-done").focus?.()`. A focused <button> fires
    // on Space or Enter — and on YouTube, Space is the player's own
    // play/pause key. The most instinctive thing a woman does when a screen
    // appears over a running video is press Space to stop it, and that was
    // exactly the press that dismissed her own block. In companion mode the
    // grace button sits beside it, whose handler calls removeOverlay()
    // outright, so one reflex could take the block off the page entirely.
    //
    // The trap itself was never the problem and stays (§9 "מקלדת ומיקוד" —
    // focus stays inside the panel while it is up). What changes is *what*
    // holds focus: the panel container (tabindex="-1", above), which has no
    // activation behaviour at all. Nothing is armed on arrival.
    //
    // FLAGGED FOR SARA — this contradicts one written line of DESIGN.md §9,
    // which says in so many words that the first item to receive focus on
    // the stop page is "סיימנו להיום". Issue 136 is her own report and it
    // asks for exactly this move, so the code follows the issue; the spec
    // line is now out of date and only she can reword it. Not touched here:
    // DESIGN.md is her Hebrew, not ours to edit as a side effect of a
    // behaviour fix. Raised in the PR.
    panel.focus?.();

    // §9 "מקלדת ומיקוד": focus stays inside the panel while it is up.
    backdrop.addEventListener("keydown", (e) => {
      // Space, swallowed for as long as the screen is up (issue 136).
      // stopPropagation as well as preventDefault, because the key would
      // otherwise still bubble out of our shadow root to the host page's own
      // document-level hotkey handler — which on YouTube is the one that
      // toggles the player. Two things are bought here: no button can be
      // activated by the reflex press, and the page underneath cannot act on
      // it either.
      //
      // The cost, stated plainly: a keyboard user can no longer activate a
      // panel button with Space. Enter still activates one she has
      // deliberately tabbed to (below), so the keyboard path to both buttons
      // is intact — it is one of the two standard keys, not both, and that
      // is the trade this screen is worth.
      if (e.key === " " || e.key === "Spacebar") {
        e.preventDefault?.();
        e.stopPropagation?.();
        return;
      }
      const focusables = Array.from(panel.querySelectorAll("button")).filter(
        (el) => !el.disabled
      );
      // Enter, swallowed only while nothing she chose holds focus — i.e. on
      // arrival, when the panel container itself has it. Once she has tabbed
      // onto a button, Enter does what Enter does; that is a decision, not a
      // reflex, and taking it away would leave the screen unusable by
      // keyboard.
      if (e.key === "Enter") {
        if (!focusables.includes(document.activeElement)) {
          e.preventDefault?.();
          e.stopPropagation?.();
        }
        return;
      }
      if (e.key !== "Tab") return;
      if (!focusables.length) return;
      const firstEl = focusables[0];
      const lastEl = focusables[focusables.length - 1];
      // Added with issue 136's focus move: with the panel container holding
      // focus rather than a button, the browser's own default would carry
      // Shift+Tab backwards straight out of the panel and into the page
      // behind it — the exact thing §9 forbids. Neither edge case existed
      // while a button always held focus on arrival.
      if (!focusables.includes(document.activeElement)) {
        e.preventDefault();
        (e.shiftKey ? lastEl : firstEl).focus();
        return;
      }
      if (e.shiftKey && document.activeElement === firstEl) {
        e.preventDefault();
        lastEl.focus();
      } else if (!e.shiftKey && document.activeElement === lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    });

    panel.querySelector("#kb-done").addEventListener("click", () => {
      renderDone(panel, mode, reason);
    });

    const graceBtn = panel.querySelector("#kb-grace");
    if (graceBtn) {
      graceBtn.addEventListener("click", () => {
        // §6.3: the pause dialog replaces the panel's whole content, not
        // just the button row — one quiet second of thought, zero judgment.
        // B-C-05 was "בטוחה?" until Sara read the bank aloud (issue #5): a
        // confirmation prompt doubts her judgement, and it is the most
        // machine-standard phrasing there is. It is an open question now.
        // The two buttons below are approved copy and stay as they are —
        // docs/messages.md flag 12 records that "כן" no longer answers it.
        panel.className = "panel is-pause";
        panel.innerHTML = `
          <div class="pause-line">מה יעזור לך יותר עכשיו?</div>
          <div class="buttons" id="kb-pause-actions">
            <button class="btn-neutral" id="kb-grace-yes">כן, עוד 5 דקות</button>
            <button class="btn-neutral" id="kb-grace-no">בעצם, סיימתי</button>
          </div>`;

        panel.querySelector("#kb-grace-yes").addEventListener("click", async () => {
          if (!inExtension) {
            removeOverlay();
            return;
          }
          const res = await chrome.runtime
            .sendMessage({ type: "kabbalot-grace" })
            .catch(() => null);
          const actions = panel.querySelector("#kb-pause-actions");
          if (res && res.ok) {
            removeOverlay();
          } else if (res && res.reason === "commitment") {
            // מצב מחויבות. Nothing ran out — nothing was ever offered, so
            // the used-up note would be untrue. Reachable when the mode
            // changed while this overlay was already up. Say nothing.
            actions.innerHTML = "";
          } else if (res && res.left === 0) {
            actions.innerHTML = `<div class="grace-note">חריגות השבוע נוצלו — ואת עדיין בסדר גמור</div>`;
          } else {
            // Something went wrong on our side. Never leave her looking at
            // a button that does nothing.
            actions.innerHTML = `
              <div class="grace-note">משהו אצלנו לא הגיב כרגע. נסי שוב עוד רגע</div>
              <button class="btn-neutral" id="kb-retry">נסי שוב</button>`;
            actions
              .querySelector("#kb-retry")
              .addEventListener("click", () => showOverlay(current));
          }
        });

        panel.querySelector("#kb-grace-no").addEventListener("click", () => {
          renderDone(panel, mode, reason);
        });
      });
    }
  }

  // "{{נותר}}" / "{{מכסה}}" (docs/messages.md's variable table): both are
  // always the clock format h:mm, never bare minutes — 90 minutes is "1:30",
  // not "90". Kept as one small function so the caption and the quota figure
  // can never disagree about how a number is written. Still used for the
  // caption (T-09 is approved copy in this format) and for the quota; the
  // big ticking digit uses formatCountdown() below instead — see its comment
  // for why the two are not the same function.
  function formatClock(mins) {
    const m = Math.max(0, Math.round(mins));
    return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`;
  }

  // NOT approved copy — flagged for Sara. §5 of DESIGN.md fixes exactly one
  // duration format, h:mm ("1:30"), because until issue #86 nothing in the
  // product ticked faster than a minute. T-09's caption keeps that format
  // untouched (formatClock, above). This is a second, new format for the big
  // digit alone, invented here because Sara asked the pill to carry seconds
  // and there is no approved shape for that in docs/messages.md §7 to build
  // against. It follows h:mm's own rule — the leading unit bare, every unit
  // after it zero-padded — just carried one field further: m:ss under an
  // hour, h:mm:ss at or past one. Please bless this shape or hand back one
  // you prefer.
  function formatCountdown(totalSeconds) {
    const s = Math.max(0, Math.round(totalSeconds));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
      ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
      : `${m}:${String(sec).padStart(2, "0")}`;
  }

  let timerHost = null;
  // A kabbalah she has closed the pill for, this page view only. Cleared the
  // moment the data says something else (a different kabbalah, or none at
  // all) — a reload starts this whole closure over anyway, and moving to a
  // different kabbalah's page is not the page she dismissed it on. A
  // permanent "never show me this" is a settings decision (#20) with a
  // storage key of its own; this file does not have one to reach for, and
  // inventing one for a single boolean would be scope this issue does not
  // own.
  let timerDismissedFor = null;

  // The pill's live state — issue #86. `syncedAt` is a `Date.now()`
  // timestamp, not a tick count, precisely so a throttled background tab
  // cannot desync it (see tick()'s own comment). `null` whenever no pill is
  // mounted; renderTimer() and removeTimer() are the only two writers.
  let timerSync = null;
  // The three live nodes tick() writes to, captured once when the pill is
  // built so a per-second update is a plain text/style write, never a
  // rebuild — rebuilding would reload the character image and restart the
  // pill's own entrance animation every single second.
  let timerEls = null;

  function removeTimer() {
    stopTimerTicking();
    timerSync = null;
    timerEls = null;
    if (timerHost) {
      timerHost.remove();
      timerHost = null;
    }
  }

  // Runs once a second while the pill is up (startTimerTicking), and once
  // more immediately whenever timerSync changes (a fresh build, a resync, or
  // the tab coming back from hidden) so she never waits up to a second for a
  // number that is already known to be stale. Silently does nothing with no
  // pill mounted — the interval that calls this is always stopped the same
  // moment the pill is (removeTimer), but a stray visibilitychange firing in
  // the gap between "the worker said gone" and "the DOM actually came down"
  // is exactly the kind of stray call this guard is for.
  function tick() {
    if (!timerEls || !timerSync) return;

    // Derived from a timestamp, never from "how many times has this fired":
    // a hidden tab throttles setInterval hard, sometimes to slower than once
    // a minute, so a countdown that trusted its own tick count would be
    // wrong the moment she looked back at the tab. Date.now() minus the
    // moment this number was last known true is correct on the very first
    // tick after any gap, however long that gap was.
    const elapsedSec = Math.max(0, Math.floor((Date.now() - timerSync.syncedAt) / 1000));
    const remainingSec = Math.max(0, timerSync.baseRemainingSec - elapsedSec);

    timerEls.clock.textContent = formatCountdown(remainingSec);
    // T-09 verbatim, format unchanged (h:mm) — only how often its number is
    // recomputed has changed, from once per 30-second poll to once per
    // second, so its own minute figure crosses a boundary the instant the
    // ticking digit above it does rather than lagging behind it by up to
    // half a minute.
    timerEls.caption.textContent =
      `נשארו לך ${formatClock(remainingSec / 60)} מתוך ${timerSync.quotaClock}`;

    // The ring moves per second too, on the same reasoning as the digits: it
    // is the same number wearing a different shape, and a ring that held
    // still while the figures beside it visibly counted down would itself
    // now read as broken — exactly the complaint this issue exists to fix,
    // just moved one element over. It costs nothing extra: this is a style
    // write on a node that already exists, not a rebuild.
    const pct = timerSync.quotaSec > 0
      ? Math.max(0, Math.min(1, remainingSec / timerSync.quotaSec))
      : 0;
    const angle = Math.round(pct * 360);
    timerEls.ring.style.background =
      `conic-gradient(var(--success-data) 0deg ${angle}deg, rgba(255,255,255,0.25) ${angle}deg 360deg)`;
  }

  // §3.6 / T-09, issue #21, and the seconds Sara asked for after watching the
  // pill sit still and reporting it dead — twice (issue #86). `data` is
  // background.js's timerFor() result — null whenever there is nothing
  // honest to show (no dailyLimit kabbalah on this page, Shabbat, or she is
  // already blocked, in which case the stop screen is already the truth).
  //
  // Architecture: background.js stays the one source of truth for how much
  // is actually left, and this file does not poll it any faster than the 30
  // seconds it always has — waking a service worker once a second on every
  // open tab is a real cost on her laptop, and this product's whole promise
  // is giving her time back, not spending it. What changes is what happens
  // *between* those 30-second answers: instead of sitting frozen on the
  // worker's last word, the pill counts itself down locally (tick(), every
  // second) and only asks the worker again on its existing cadence.
  //
  // When a fresh answer does land, for the *same* kabbalah already on
  // screen, it replaces the local guess outright — the worker wins any
  // disagreement, because it is the only place usage is actually recorded —
  // but it does that by resetting timerSync in place, never by tearing the
  // pill down and rebuilding it. Rebuilding would reload the character image
  // and restart the pill's own fade-in every 30 seconds, which is a glitch
  // this file can avoid for free; a corrected number appearing at its usual
  // spot a second early or late is not.
  function renderTimer(data) {
    if (!data || data.kabbalahId !== timerDismissedFor) timerDismissedFor = null;
    if (!data || data.kabbalahId === timerDismissedFor) {
      removeTimer();
      return;
    }

    const quotaSec = data.quotaMin * 60;
    const quotaClock = formatClock(data.quotaMin);
    // The worker's own reading is whole minutes (timerFor() rounds); a
    // 0-remaining pill is never sent (timerFor() returns null instead), so
    // this is always at least a minute's worth of seconds to start from.
    const baseRemainingSec = Math.max(0, Math.round(data.remainingMin) * 60);

    if (timerHost && timerSync && timerSync.kabbalahId === data.kabbalahId) {
      // Same pill, same kabbalah, a fresher answer — resync without
      // rebuilding (see this function's own header comment).
      timerSync.baseRemainingSec = baseRemainingSec;
      timerSync.quotaSec = quotaSec;
      timerSync.quotaClock = quotaClock;
      timerSync.syncedAt = Date.now();
      tick();
      return;
    }

    // A different kabbalah, or no pill up yet — nothing to resync, build it
    // fresh. (removeTimer() is a no-op if there was nothing mounted.)
    removeTimer();

    timerHost = document.createElement("div");
    const root = timerHost.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = CSS;
    root.appendChild(style);

    // Numbers are left blank here and filled by the tick() call just below —
    // one code path writes them, whether this is the pill's first paint or
    // its five-hundredth tick, so the two can never drift out of the format
    // each uses.
    const pill = document.createElement("div");
    pill.className = "floating-timer";
    pill.innerHTML = `
      <div class="ft-arc">
        <div class="ft-ring"></div>
        <div class="ft-char" id="ft-char"></div>
      </div>
      <div class="ft-info">
        <div class="ft-clock" dir="ltr"></div>
        <div class="ft-caption"></div>
      </div>
      <button class="ft-close" type="button" aria-label="סגירה">×</button>`;
    root.appendChild(pill);
    document.documentElement.appendChild(timerHost);
    mountCharacter(pill.querySelector("#ft-char"), "heart.png");

    pill.querySelector(".ft-close").addEventListener("click", () => {
      timerDismissedFor = data.kabbalahId;
      removeTimer();
    });

    timerSync = {
      // Fix (Founder Ruling 1, 2026-08-26): kabbalahId, not
      // kabbalahName — an identity key only, never painted on screen (see
      // KICKER_TEXT's own comment for why this file stopped reading names
      // at all). timerDismissedFor and the resync check above both switched
      // to it too.
      kabbalahId: data.kabbalahId,
      quotaSec,
      quotaClock,
      baseRemainingSec,
      syncedAt: Date.now(),
    };
    timerEls = {
      clock: pill.querySelector(".ft-clock"),
      caption: pill.querySelector(".ft-caption"),
      ring: pill.querySelector(".ft-ring"),
    };
    tick(); // paint real numbers before the first paint, not blanks
    startTimerTicking();
  }

  // A hidden tab throttles its interval hard — sometimes to slower than once
  // a minute — so the moment she actually looks back at the tab is exactly
  // the moment a stale number would be most visible to her. tick() derives
  // its answer from Date.now() rather than a tick count (its own comment
  // above), so catching this costs nothing extra: it is the same call, just
  // invited to run a little sooner than its own interval would have fired
  // it. A harmless no-op whenever no pill is mounted.
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) tick();
  });

  function showWarning(remaining) {
    const toastHost = document.createElement("div");
    const root = toastHost.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = CSS;
    root.appendChild(style);
    const wrap = document.createElement("div");
    wrap.className = "toast-wrap";
    wrap.innerHTML = `
      <div class="toast">
        <div class="toast-accent"></div>
        <div class="toast-text">נשארו לך ${remaining} דקות מהקבלה של היום</div>
      </div>`;
    root.appendChild(wrap);
    document.documentElement.appendChild(toastHost);
    setTimeout(() => toastHost.remove(), 8000);
  }

  if (inExtension) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === "kabbalot-block") {
        showOverlay(msg);
        // The stop screen is already the truth about this page; a timer
        // pill counting down beside it would be saying the same thing
        // twice. Hidden immediately rather than waiting up to 30 seconds
        // for the next poll to agree.
        removeTimer();
      }
      if (msg.type === "kabbalot-warning") showWarning(msg.remaining);
      if (msg.type === "kabbalot-release") removeOverlay();
    });

    // The overlay lives in the page, so a reload wipes it. Ask on load
    // whether this page should be showing it — otherwise refreshing is a way
    // out, and a tab that was already open when she installed is a blind
    // spot. Asking is also what re-blocks her when the five minutes end.
    // The same reply carries the floating timer's data (issue #21) — one
    // question, one round trip, both answers.
    const askStatus = () => {
      chrome.runtime
        .sendMessage({ type: "kabbalot-status", url: location.href })
        .then((res) => {
          if (res && res.blocked) showOverlay(res);
          else removeOverlay();
          renderTimer(res && res.timer);
        })
        .catch(() => {
          // Extension reloading or updating — the next check will catch it.
        });
    };
    askStatus();
    // Kept at 30 seconds on purpose (issue #86) — not tightened, even though
    // that would also have made the pill look alive. The floating timer now
    // gets its own visible movement from tick()'s local per-second countdown
    // (renderTimer()'s own header comment), so there is nothing left for a
    // faster poll to buy here, only a service worker woken up on every open
    // tab thirty times more often than it needs to be.
    setInterval(askStatus, 30000);

    // ── SPA navigation (issue #126) ───────────────────────────────────────
    // Sara, in real use on YouTube Shorts: "the timer keeps running for me
    // when I'm not in Shorts. I want it to only work when I'm in a Short."
    // Her kabbalah names one corner of a site (youtube.com/shorts), not the
    // whole site, and background.js's own placeFor/setActiveTab already
    // recompute the right place on every navigation Chrome tells them about
    // — the counting itself was verified sound (issue #126's own writeup).
    // What is NOT sound is what this file paints: askStatus only runs once
    // every 30 seconds, above, while the floating timer counts itself down
    // locally every single second (tick()). On an ordinary site a URL
    // change means a fresh document, and this whole file reruns from the
    // top the moment it happens. YouTube is a single-page app — leaving a
    // Short for the home page (or any other in-app navigation) rewrites the
    // address bar through the History API and nothing else, no reload, no
    // re-run of this script — so without this block nothing here would
    // notice for up to 30 seconds, and the pill built for the Short she
    // left would keep ticking down over a page that is not being measured
    // at all. Even if the underlying minutes were never actually charged to
    // that page (they are not — placeFor has no match outside the corner
    // she named), a pill ticking on an unmeasured page is a lie on screen,
    // and that lie is the whole bug this closes.
    //
    // Two hooks catch every ordinary way a pushState-based SPA (YouTube
    // included) changes the address bar without a reload: wrapping
    // history.pushState/replaceState catches a forward navigation — what
    // YouTube's own router uses for "next Short" and "back to the feed"
    // alike — and `popstate` catches the browser's own back/forward
    // buttons, which move location.href on their own without ever calling
    // either history method. Between the two, every path a same-document
    // navigation can take is covered without polling anything.
    //
    // Reached through `window.history`/`window.addEventListener`, never the
    // bare globals — the same reasoning as `window.MutationObserver` in
    // holdMedia() above: this file is also executed through a
    // `new Function(...)` wrapper in extension/tests/, where a bare
    // `history` or `addEventListener` would be a ReferenceError before a
    // single test could run. A real content script's own `window` carries
    // both; the tests' DOM stub carries them too, for the same reason, so
    // this is the path that actually gets covered rather than a dead
    // branch guarded by a `typeof` check nothing ever exercises.
    let lastKnownHref = location.href;
    const onPossibleUrlChange = () => {
      if (location.href === lastKnownHref) return; // nothing actually moved
      lastKnownHref = location.href;
      // Comes down NOW, synchronously, before askStatus's own round trip to
      // the worker has even been sent — that synchronousness is the entire
      // point of this fix. askStatus() below will rebuild the pill a moment
      // later if the new page also carries a quota (renderTimer() handles
      // that on its own, same as any other fresh answer), but there is no
      // honest number to show in the gap between "she left" and "the worker
      // answered", so nothing is shown in that gap.
      removeTimer();
      askStatus();
    };
    const wrapHistoryMethod = (name) => {
      if (!window || !window.history || typeof window.history[name] !== "function") return;
      const original = window.history[name];
      window.history[name] = function (...args) {
        const result = original.apply(this, args);
        onPossibleUrlChange();
        return result;
      };
    };
    wrapHistoryMethod("pushState");
    wrapHistoryMethod("replaceState");
    if (window && typeof window.addEventListener === "function") {
      window.addEventListener("popstate", onPossibleUrlChange);
    }
  } else {
    // Preview harness (outside the extension runtime)
    window.__kabbalotOverlay = { showOverlay, showWarning, renderTimer };
  }
})();
