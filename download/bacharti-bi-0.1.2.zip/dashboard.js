// בחרתי בי — dashboard.js: the 2a board (issue #102). The visual layer is
// design/Kabbalot Dashboard.dc.html's artboard 2a — "השילוב: עשיר למעלה,
// רגוע למטה" — and ONLY 2a (1a/1b/1c are rejected rounds). This file
// renders and wires; every number and every gating decision comes from
// dashboard-model.js (no DOM, covered by node tests) and, for the
// edit-places path, onboarding-model.js's canEditPlacesViaOnboarding().
//
// What survived issue #20's version, on purpose:
//   · the gentle-pause door (ids create-kabbalah / pause-back /
//     pause-continue, class pause-card) — she-earns-a-gentle-pause-not-a-
//     wall.mjs holds this file to it by name;
//   · renderQuietSettings / renderReminderSettings / renderShabbatSettings
//     / wireSettings — the settings simply moved behind the
//     "הגדרות הקבלה" reveal instead of always being on screen. modeToggleHtml
//     moved with them but did NOT survive verbatim (review, B4): its inline
//     "בתוקף ממחר" string had an em-dash and lived outside DASH_COPY, both
//     fixed below (see DASH_COPY.pendingCommitment);
//   · seedPreviewIfEmpty, extended with usage days so the preview's bars
//     and returned-hours line show real arithmetic.
//
// ---- what #112 brought here, ported into 2a's own markup (this branch) ----
// The settings block also carries the two hours of the Shabbat arc (יום שישי
// and מוצאי שבת — Sara's ruling of 2026-08-23), the quarter-hour check-in
// reminder, and a quiet window that may close at midnight. The manual
// holiday off-switch that 2a inherited from issue #20 is GONE, at her word
// (same ruling) — a-retired-holiday-key-changes-nothing.mjs holds the
// removal. 2a rewrote this whole file, so none of that could arrive as a
// plain merge: the behaviour is #112's, the markup is 2a's.
//
// Not one number on this screen is typed from the design: clocks come from
// remainingToday(), the bar widths from usedPercent, the returned line from
// returnedThisWeekMinutes(), the calendar from monthCalendar(), the
// overview from overviewStats(). Design literals live only in
// dashboard.css / tokens.css as colours and sizes.
//
// ---- copy note ----
// Every string below is either reused verbatim from an approved source
// (docs/messages.md S-04/S-05, §7's own labels, the popup's own footer and
// chat strings, onboarding's mode copy) or is new and marked UNAPPROVED for
// Sara in the DASH_COPY block. New strings carry no emoji (the character
// carries the warmth) and no em-dash, and speak feminine singular second
// person. The full list is in the issue #102 report.

const el = (id) => document.getElementById(id);

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[c]);
}

// Fix (2026-08-25, Sara's report): "אני רוצה ששם הקבלה יהיה לפי שם האתר" —
// in the normal case `k.name` is already set at creation time by
// nameFrom() (onboarding-model.js, loaded before this file — see the
// header note above), which now does exactly this. This fallback is only
// for the abnormal case of a stored kabbalah with no name at all.
//
// Fix (Important 3, 2026-08-26): reuses nameForStoredKabbalah()
// (onboarding-model.js, same reuse as placeDisplayName above) rather than
// its own hand-rolled copy of the same fallback — the two used to
// disagree with answersFromKabbalah()'s own prefill on exactly this "no
// name at all" case (Important 3's report). One naming rule at this layer,
// not two.
function kabbalahLabel(k) {
  return nameForStoredKabbalah(k || {});
}

// ---------- copy ----------
const DASH_COPY = {
  // §7 (popup), verbatim.
  streakTile: "ימים ברצף",
  keptTile: "ימים שעמדת",
  editKabbalah: "הגדרות הקבלה",
  exportLink: "ייצוא נתונים", // popup.js's own footer label, verbatim
  hardNow: "קשה לי עכשיו", // popup.js's own help button, verbatim

  // onboarding-model.js's COPY (§7 / issue #82 verbatim).
  modeCompanion: "מצב מלווה",
  modeCommitment: "מצב מחויבות",
  modeNote:
    "ⓘ ההבדל: במלווה אפשר לבקש עוד 5 דקות (עד 3 בשבוע). במחויבות — מה שקבעת סופי עד מחר. אפשר לשנות בהגדרות, בתוקף ממחר.",
  // Was inlined straight into modeToggleHtml's template literal instead of
  // living here (review B4, blocker: an em-dash, AND invisible to the copy
  // doc's own stated method of diffing DASH_COPY against pre-branch — a
  // string moved out of this object is a string that review can't see).
  // Restored to DASH_COPY, dash fixed to the house "·" separator.
  pendingCommitment: "עוברת למצב מחויבות · בתוקף ממחר",

  // docs/messages.md group 5, verbatim (S-04 / S-05) — the gentle pause.
  pauseTitle: (name, days) =>
    `בואי ניתן ל״${escapeHtml(name)}״ עוד כמה ימים. היא איתך רק ${days} ${
      days === 1 ? "יום" : "ימים"
    }, וקבלה שנייה מוקדם מדי בדרך כלל מחלישה את שתיהן.`,
  pauseConfirm: "אם את בטוחה, מוסיפות עכשיו. את מכירה את עצמך יותר טוב ממני.",
  pauseGoBack: "אולי בקרוב", // UNAPPROVED (carried from issue #20's build)
  pauseContinue: "בכל זאת, יוצאות לדרך", // UNAPPROVED (carried from issue #20's build)

  // popup.js's chat screen, verbatim (issue #17's approved surface).
  chatTitle: "אני כאן איתך",
  chatPrivacy: "מה שנכתב כאן נשאר בינינו ולא נשמר בשום מקום",
  chatPlaceholder: "ספרי לי מה קורה עכשיו…",

  // ---- UNAPPROVED · design-2a strings, waiting on Sara. The design's
  // em-dashes became "·" and its 🌿/💜 were dropped (messages.md rules 10
  // and the house no-em-dash rule); everything else is 2a's own wording. ----
  title: "הלוח שלך", // 2a header (matches dashboard.html's <title>)
  subtitle: "מה נשאר להיום · מה הצעד הבא · יומן ההצלחות שלך",
  todayTitle: "מצב היום",
  todaySub: "כמה זמן נשאר לך מכל קבלה עכשיו",
  remainingOf: "נשארו מתוך",
  // h is already a complete Hebrew phrase from formatReturnedHours
  // ("חצי שעה" / "שעה" / "שעתיים" / "3 שעות" / ...) — never append "שעות"
  // here, or a phrase that already ends in it doubles up (review, blocker).
  // "רואה", not "רואים" — impersonal plural addressed to one woman
  // (review, native-speaker pass).
  returnedLine: (h) => `השבוע החזרת לעצמך <b>${h}</b>. רואה את הירידה? זו את.`,
  generalTitle: "המצב הכללי",
  standingWord: "עמידה",
  overviewCount: (n) => (n === 1 ? "קבלה אחת" : `${n} קבלות`),
  calTitle: (month) => `יומן ההצלחות · ${month}`,
  // "בו" is the resumptive pronoun the relative clause needs (עמד governs
  // ב־) — "כל יום שעמדת מסומן" reads as a dangling clause without it
  // (native-speaker pass). Percent-first ("{p}% עמידה") to read the same
  // direction as the general card's own "87% עמידה" on the same screen —
  // the old "עמידה {p}%" order reversed it right next to itself.
  calSub: "כל יום שעמדת בו מסומן בירוק",
  calPercent: (p) => `${p}% עמידה`,
  legendKept: "עמדת",
  legendFell: "יום קשה",
  legendToday: "היום",
  legendReleased: "יום משוחרר", // issue #87's third state; shown only when one exists
  // "שבוע שלם עמדת" — the dashboard's OWN fresh offer (suggestionFor's
  // "fresh" kind — targetSuggestion, not yet applied). Dropped the
  // redundant "האחרון" (review B3: "שבוע שלם" already says "the last
  // week").
  suggestTitle: "הצעה · שבוע שלם עמדת",
  suggestBody: (name, from, to) =>
    `ב״${escapeHtml(name)}״ היעד יכול לרדת מ־${from} ל־${to} דק׳ ביום.`,
  weekAdvance: "להתקדם", // fresh offer's own pair
  weekStay: "להישאר",
  // The ENGINE's own pendingWeekChoice ("week" kind, issue #30): settleWeek
  // has already WRITTEN the drop — rule.limitMinutes already reads `to` —
  // so this card states a fact, not an offer, and "stay" is the ONE button
  // that mutates data (it undoes the drop, restoring `from`). The old
  // shared copy read as an offer either way and let the passive-sounding
  // button be the destructive one (review B3, blocker) — split, with each
  // button naming the number it actually leads to instead of reusing
  // "להתקדם"/"להישאר". All UNAPPROVED, Sara's own wording from the review.
  suggestTitleWeek: "שבוע שלם עמדת · היעד כבר ירד",
  suggestBodyWeek: (name, from, to) =>
    `ב״${escapeHtml(name)}״ היעד ירד מ־${from} ל־${to} דק׳ ביום, כבר מהיום.\n אם זה מוקדם מדי, אפשר להחזיר אותו ל־${from}.`,
  weekAdvanceLabel: (to) => `נשארות על ${to}`,
  weekStayLabel: (from) => `עוד שבוע על ${from}`,
  chatSub: "הרגע הזה יעבור. נעבור אותו יחד.",
  chatChips: ["יש לי דחף חזק עכשיו", "עצוב לי / משעמם לי", "רק רוצה מילה טובה"],
  createBtn: "יצירת קבלה חדשה",
  editPlaces: "עריכת אתרים",
  editUnavailable: "עריכת האתרים של הקבלה הזו לא זמינה עדיין מכאן",
  settingsTitle: "הגדרות",
  quietTitle: "שעות שקטות",
  quietIntro: "יש שעות שבהן את פשוט לא שם. כאן את קובעת אותן מראש.",
  // UNAPPROVED · Sara's live Chrome test, 2026-08-26: she looked at the old
  // wording ("הוספת השעות האלה") and asked "מה זה אומר הלחצן הזה" — the
  // button did not say what pressing it would do. It appends the days +
  // times currently in the form as one more window onto her list; it does
  // not touch any window already saved. "לרשימה" names that destination so
  // pressing it reads as adding one more entry, not as replacing what is
  // already there. Audited (avshalom-hebrew-expert, hebrew-writing-skill,
  // make-human-lite) against two runner-ups that both leaned on "חלון"
  // (window), a term this screen never otherwise uses with her — see the
  // report. Same string, verbatim, in popup.js's own copy of this screen.
  quietAdd: "הוספת השעות האלה לרשימה",
  quietRemove: "הסרה",
  // UNAPPROVED · issue #130, Sara's ruling of 2026-08-30: "אני רוצה שלא
  // תהיה אפשרות לעזוב את זה בזמן שזה חסום." The hours that are stopping
  // her right now cannot be removed until they end, and a greyed-out button
  // with nothing beside it reads as a broken screen rather than as a rule,
  // so this line is the reason. It is NEW HEBREW AND IT IS HERS TO RULE ON:
  // the issue says so in as many words ("הנוסח הוא הכרעת קופי של שרה").
  //
  // Three choices in it she can rule on separately:
  //   · "השעות האלה" and not "החלון" — this screen never says "window" to
  //     her (quietAdd's own note above is where that was settled), and the
  //     add button already calls the same thing "השעות האלה".
  //   · it names the END and not only the refusal. She is held until these
  //     hours are over, never longer, and that bound is the entire reason
  //     this rule was acceptable at all (#130, option 3).
  //   · it hands her the door instead of leaving her at a wall. The valve's
  //     label is interpolated from DASH_COPY.hardNow rather than retyped, so
  //     this sentence can never end up naming a button that no longer says
  //     that.
  // No em-dash, no emoji, second person singular feminine, the same גרשיים
  // every other quoted label in this object uses.
  quietRemoveHeld: (valve) =>
    `השעות האלה פעילות עכשיו, ואי אפשר להסיר אותן עד שייגמרו. אם קשה לך ברגע הזה, ״${valve}״ כאן בשבילך.`,
  reminderTitle: "תזכורת יומית ב־",

  // ---- UNAPPROVED · Sara's ruling of 2026-08-23, her own two words
  // ---- ("מוצאי שבת", "יום שישי") but not her own sentences. Every string
  // ---- in this block is new, is listed in the report, and is waiting on
  // ---- her. Audited through avshalom-hebrew-expert and
  // ---- hebrew-writing-skill: second person singular feminine throughout
  // ---- (the whole audience is women, so the masculine default does not
  // ---- apply), no em-dash, no emoji, no corporate loanword. ----
  shabbatTitle: "יום שישי ומוצאי שבת",
  shabbatIntro:
    "מהשעה שאת קובעת ביום שישי ועד מוצאי שבת, לא נמדד כלום ולא נשפט כלום.",
  shabbatFrom: "יום שישי, מהשעה",
  shabbatTo: "מוצאי שבת, מהשעה",
  shabbatSave: "שמירת השעות",
  shabbatNote:
    "השעות של שישי בבוקר ושל מוצאי שבת נמדדות כמו כל שעה אחרת בשבוע.",
  emptyTitle: "עוד אין לך קבלה",
  emptyBody: "הלוח הזה מתמלא ברגע שתתחילי קבלה ראשונה.",
  emptyBtn: "מתחילות ←",
};

const DAY_NAMES = ["א", "ב", "ג", "ד", "ה", "ו", "ש"];
// The check-in reminder's own bounds. Sara, 2026-08-23: "אני רוצה שיהיה
// אפשר גם לבחור חלקי שעות כמו רבע שעה חצי שעה וכזה, לא רק שעות עגולות" —
// so the step is a quarter of an hour, not a whole one, and the same three
// numbers are mirrored in onboarding.js's own copy of this stepper (no
// module system; a test holds the two together).
//
// THE CEILING, AND WHY IT IS 23:45 AND NOT MIDNIGHT. Her other request in
// the same breath was to reach twelve at night, and for the quiet-hours
// range that is exactly what happens: a window can now end at 24:00, which
// is the end of the day. A reminder is not a range, it is a moment, and
// there is no moment "24:00" on a clock that runs 00:00 to 23:59 — a
// reminder set there would simply never fire, which is a worse answer than
// not offering it. So the reminder reaches the last quarter before
// midnight, and the quiet hours reach midnight itself. FLAGGED FOR SARA.
// issue 142: no floor. Sara's call. See background.js's herHourHasPassed,
// which had to learn about hours inside the day's tail before this number
// could safely go below DAY_RESET_HOUR.
const REMINDER_FLOOR = 0;
const REMINDER_CEIL = 23.75;
const REMINDER_STEP = 0.25;

// A quiet window may close at midnight, written "24:00" — the end of the
// day, which is a different thing from a window that *crosses* midnight
// (that one has a `to` smaller than its `from`, and activeWindow's own
// overnight branch has always handled it). <input type="time"> cannot
// produce "24:00" at all: its own ceiling is 23:59, and midnight comes back
// as "00:00". So a closing time of "00:00" is normalised on the way in.
// Nothing about the engine changes either way — parseClock("00:00") is 0,
// which makes the window overnight and therefore active from `from` to the
// end of the calendar day, and parseClock("24:00") is 1440, which makes it
// a plain same-day window active to minute 1439. Identical minutes, one
// honest label.
const QUIET_END_OF_DAY = "24:00";
// Used for a quiet window's closing time AND for the motzash edge, which is
// the same question asked by the same kind of control: "she picked midnight
// — the end of which day?" Always the one the range was running through.
function normaliseWindowEnd(to) {
  return to === "00:00" ? QUIET_END_OF_DAY : to;
}

function reminderInRange(h) {
  return Number.isFinite(h) && h >= REMINDER_FLOOR && h <= REMINDER_CEIL;
}

// Sara's two hours, or the engine's own defaults. The shape and the
// fallback are background.js's normaliseEdges(), written out a second time
// here for the same reason DAY_RESET_HOUR is written out in shared.js: this
// project has no module system, and a screen that guessed a different
// default from the engine would show her a Shabbat the engine does not
// keep. a-week-that-is-lived-not-a-calendar.mjs holds the two together.
const SHABBAT_EDGES_DEFAULT = { fridayFrom: "15:00", motzashFrom: "21:00" };
const CLOCK_RE = /^(?:(?:[01]\d|2[0-3]):[0-5]\d|24:00)$/;
// "00:00" at the motzash edge is midnight at the END of Shabbat, exactly the
// reading normaliseWindowEnd above already gives a quiet window's closing
// time — the same control, on the same screen, and it was only applied to
// one of them. background.js's normaliseEdges() carries the full account of
// what that cost; keep the two in step.
function normaliseShabbatEdges(stored) {
  const pick = (v, fallback) =>
    typeof v === "string" && CLOCK_RE.test(v) ? v : fallback;
  const motzash = pick(stored?.motzashFrom, SHABBAT_EDGES_DEFAULT.motzashFrom);
  return {
    fridayFrom: pick(stored?.fridayFrom, SHABBAT_EDGES_DEFAULT.fridayFrom),
    motzashFrom: normaliseWindowEnd(motzash),
  };
}

// The way back out, and it belongs to the MOTZASH FIELD ALONE.
//
// <input type="time"> refuses "24:00" and renders empty, so an edge stored as
// the end of the day has to be shown to her as the midnight it is. Saving it
// again normalises it straight back (normaliseShabbatEdges), so the round
// trip is closed and what she sees is what is kept.
//
// The Friday field must NOT go through here, and the reason is the whole
// point of the asymmetry one function up: there is no inverse normalisation
// on that edge, deliberately, because "00:00" at an opening edge means the
// earliest start and is a real choice. Sending it through anyway would break
// the round trip in the one direction that costs her something — a stored
// fridayFrom of "24:00" (only reachable by hand-editing a profile) would be
// drawn as "00:00", and one save would re-read it as Friday 00:00, silently
// stretching her arc from 1260 minutes to 2700 and silencing a whole extra
// day she never asked to silence.
function motzashFieldValue(clock) {
  return clock === QUIET_END_OF_DAY ? "00:00" : clock;
}

const CHAT_FALLBACK_REPLY =
  "אני כאן איתך, גם אם הרגע לא הצלחתי למצוא את המילים. נשימה עמוקה. הקבלה שלך עדיין שלך.";

function openTab(url) {
  if (hasChrome && chrome.tabs) {
    chrome.tabs.create({ url: chrome.runtime.getURL(url) });
  } else {
    window.location.href = url;
  }
}

// ---------- state ----------

// Mutates one kabbalah by id and writes the whole list back — mirrors
// popup.js's own saveKabbalahById exactly, id for id. Re-reads kabbalot
// fresh right before writing rather than trusting the render-time
// state.kabbalot a click handler closes over: a tab left open sits on a
// snapshot, while background.js keeps settling weeks and acking falls
// straight to storage the whole time it is open (docs/data-model.md's own
// "לא דרך הודעה למנוע"). Writing the stale snapshot back would silently
// erase whatever the engine (or another tab) wrote in the meantime.
// Known residual race, accepted for the pilot (the same one popup.js's
// comment names): the read here and the write a line later are not atomic,
// so a settlement landing in that exact gap can still be overwritten. #13's
// message-passing rewrite is what closes it for good.
async function saveKabbalahById(id, mutate) {
  const { kabbalot = [] } = await storeGet("kabbalot");
  const k = kabbalot.find((x) => x.id === id);
  if (!k) return null;
  mutate(k);
  await storeSet({ kabbalot });
  return k;
}

async function loadState() {
  const today = dateStr();
  const usageKeys = [];
  for (let i = 0; i < 7; i++) usageKeys.push(`usage:${daysAgoStr(today, i)}`);
  const data = await storeGet([
    "kabbalot",
    "events",
    "quietWindows",
    "reminderHour",
    // `holidayDates` used to be read here too. It is not any more: the
    // manual holiday off-switch is retired (Sara, 2026-08-23 — see
    // dashboard-model.js's own note at "the manual holiday off-switch, and
    // why it is not here"). Nothing on this screen reads the key, and the
    // calendar's "skipped" days come from the event journal, not from it.
    "shabbatEdges",
    ...usageKeys,
  ]);
  const usageByDay = {};
  for (const key of usageKeys) if (key in data) usageByDay[key] = data[key];
  return {
    today,
    kabbalot: data.kabbalot || [],
    events: data.events || [],
    quietWindows: data.quietWindows || [],
    // Number.isFinite, not Number.isInteger: a quarter past eight is 20.25,
    // and the old guard would have thrown her own choice away and handed
    // back 20:00 without saying so.
    reminderHour: reminderInRange(data.reminderHour) ? data.reminderHour : 20,
    shabbatEdges: normaliseShabbatEdges(data.shabbatEdges),
    usageByDay,
    usageToday: data[`usage:${today}`] || {},
  };
}

// UI-only state, never persisted — reset on every full page load, exactly
// like issue #20's own pauseShownFor/draftDays were.
let pauseShownFor = null; // kabbalahId the pause card is currently about, or null
let draftDays = [0, 1, 2, 3, 4];
// The two time fields of the same draft, held here for the same reason
// draftDays is: render() replaces main.innerHTML wholesale, and a deferred
// background redraw flushes on blur — which is what moving from "מהשעה" to
// "עד" is. Rendered from a fixed default instead, the form came back
// looking filled-in while holding a start time she never chose, and the
// save took it. The chips survived that redraw and the hours did not, only
// because the chips already had a home out here.
const QUIET_DRAFT_DEFAULT = { from: "16:00", to: "18:00" };
let draftFrom = QUIET_DRAFT_DEFAULT.from;
let draftTo = QUIET_DRAFT_DEFAULT.to;
let settingsOpen = false; // the "הגדרות הקבלה" reveal

// True while a background storage write (chrome.storage.onChanged, below)
// arrived while she had an editable field inside #main focused, and the
// redraw that would have shown it was skipped rather than blowing away
// whatever she was mid-typing. Cleared the moment any render() actually
// runs — a fresh render already shows current everything, pending or not.
let redrawPending = false;

// The chat panel's own state. The transcript (chatLog) and the conversation
// state live only as long as this page — the popup's showConversation keeps
// them in a closure for exactly the same reason — while chatPoolHistory is
// written to storage after EVERY turn (chat-engine.js's documented spec:
// the no-repeats window must survive a browser restart). Nothing she types
// is ever stored or sent anywhere.
let chatOpen = false;
let chatLog = []; // [{who: "ora"|"me", text}]
let convState = null;
let convPoolHistory = null;

// ---------- rendering: the 2a layout ----------

function renderHeader() {
  return `
    <header class="dash-header">
      <div class="head-text">
        <h1>${DASH_COPY.title}</h1>
        <div class="sub">${DASH_COPY.subtitle}</div>
      </div>
      <img class="char" src="character/v3/cheer.png" alt="" />
    </header>`;
}

// Fix (issue #116, 2026-09-09): "בחרתי 2 אתרים והוא הראה לי רק אחד" — she
// chose two places for one kabbalah and the row named only one. kabRowHtml
// used to carry nothing but the kabbalah's NAME, and since #113 that name
// is auto-derived from the FIRST place she chose — so a second (or third)
// place never appeared anywhere on the row, not because the data was gone
// (background.js/export.js already sum every place in k.places, untouched
// here) but because nothing ever drew it. This lists every place actually
// stored in k.places, formatted the same recognisable way the name itself
// already trusts (placeDisplayName, onboarding-model.js) — not a count,
// not a re-derived name, not a "+N" affordance. Whether the row should one
// day collapse a long list, and whether the auto-derived name still reads
// right with several places, are the issue's own two open questions and
// are left exactly that open; this only makes what was already true also
// visible.
function kabPlacesHtml(k) {
  const places = (k.places || []).filter((p) => typeof p === "string" && p);
  if (!places.length) return "";
  // placeDisplayName can refuse to name a place (an empty or punycode
  // host — see its own comments) and return "". Falling back to the raw
  // stored string rather than dropping the place silently keeps this fix
  // from recreating, for an edge case, the exact bug it exists to close.
  const shown = places.map((p) => escapeHtml(placeDisplayName(p) || p)).join(" · ");
  return `<div class="kab-row-places" dir="ltr">${shown}</div>`;
}

function kabRowHtml(k, state) {
  const name = escapeHtml(kabbalahLabel(k));
  const chip =
    k.mode === "commitment"
      ? `<span class="mode-chip commitment">${DASH_COPY.modeCommitment}</span>`
      : `<span class="mode-chip">${DASH_COPY.modeCompanion}</span>`;
  const places = kabPlacesHtml(k);
  const left = remainingToday(k, state.usageToday);
  if (!left) {
    // A window kabbalah has no quota to count down — its hours stand where
    // the clock would (background.js's own note at remainingFor).
    const range =
      k.rule && k.rule.from
        ? `<span class="of" dir="ltr">${escapeHtml(k.rule.from)}–${escapeHtml(k.rule.to)}</span>`
        : "";
    return `
      <div class="kab-row">
        <div class="kab-row-top">
          <div class="kab-row-name"><span class="kab-name" title="${name}">${name}</span>${chip}</div>
          <div class="kab-row-clock">${range}</div>
        </div>
        ${places}
      </div>`;
  }
  return `
    <div class="kab-row">
      <div class="kab-row-top">
        <div class="kab-row-name"><span class="kab-name" title="${name}">${name}</span>${chip}</div>
        <div class="kab-row-clock">
          <span class="clock" dir="ltr">${formatClock(left.remainingMin)}</span>
          <span class="of">${DASH_COPY.remainingOf} <b dir="ltr">${formatClock(left.limit)}</b></span>
        </div>
      </div>
      ${places}
      <div class="bar"><div class="bar-fill" style="width:${left.usedPercent}%"></div></div>
    </div>`;
}

function renderTodayCard(state) {
  const rows = state.kabbalot
    .map((k) => kabRowHtml(k, state))
    .join(`<div class="row-sep"></div>`);
  const hours = formatReturnedHours(
    returnedThisWeekMinutes(state.kabbalot, state.usageByDay, state.today)
  );
  const returnedHtml =
    hours === null ? "" : `<div class="returned-line">${DASH_COPY.returnedLine(hours)}</div>`;
  return `
    <section class="card today-card">
      <div>
        <div class="card-eyebrow">${DASH_COPY.todayTitle}</div>
        <div class="fine">${DASH_COPY.todaySub}</div>
      </div>
      ${rows}
      ${returnedHtml}
    </section>`;
}

function renderGeneralCard(state) {
  const o = overviewStats(state.kabbalot, state.events, state.today);
  const pct =
    o.weeklyPercent === null
      ? `<span class="big-num muted-num">–</span>`
      : `<span class="big-num" dir="ltr">${o.weeklyPercent}%</span>`;
  return `
    <section class="card general-card">
      <div class="card-eyebrow">${DASH_COPY.generalTitle}</div>
      <div class="general-head">
        ${pct}
        <span class="fine">${DASH_COPY.standingWord} · ${DASH_COPY.overviewCount(o.count)}</span>
      </div>
      <div class="tile-row">
        <div class="tile kept"><span class="num" dir="ltr">${o.totalDaysKept}</span><span class="label">${DASH_COPY.keptTile}</span></div>
        <div class="tile streak"><span class="num" dir="ltr">${o.bestStreak}</span><span class="label">${DASH_COPY.streakTile}</span></div>
      </div>
    </section>`;
}

// ---------- the suggestion card ----------
//
// One card, two possible sources, strict priority:
//   1. the ENGINE's own pendingWeekChoice (issue #30: settleWeek already
//      applied the drop and is waiting for her word — "להתקדם" keeps it,
//      "להישאר" restores previousLimit, both through applyWeekChoice);
//   2. otherwise the dashboard's own targetSuggestion (issue #102: a kept
//      week ending yesterday earns an offer that has NOT been applied yet).
// Never both — she is offered one step at a time.
function suggestionFor(state) {
  for (const k of state.kabbalot) {
    if (k.pendingWeekChoice) {
      return {
        kind: "week",
        k,
        from: k.pendingWeekChoice.previousLimit,
        to: k.pendingWeekChoice.newLimit,
      };
    }
  }
  for (const k of state.kabbalot) {
    const s = targetSuggestion(k, state.events, state.today);
    if (s) return { kind: "fresh", k, from: s.from, to: s.to };
  }
  return null;
}

function renderSuggestionCard(state) {
  const s = suggestionFor(state);
  if (!s) return "";
  // Two different cards behind the same class (review B3): the engine's
  // own pendingWeekChoice ("week") states an already-applied fact with
  // buttons that name the number each leads to; the dashboard's own fresh
  // offer ("fresh") is still a question, unchanged.
  const isWeek = s.kind === "week";
  const title = isWeek ? DASH_COPY.suggestTitleWeek : DASH_COPY.suggestTitle;
  const body = isWeek
    ? DASH_COPY.suggestBodyWeek(kabbalahLabel(s.k), s.from, s.to)
    : DASH_COPY.suggestBody(kabbalahLabel(s.k), s.from, s.to);
  const advanceLabel = isWeek ? DASH_COPY.weekAdvanceLabel(s.to) : DASH_COPY.weekAdvance;
  const stayLabel = isWeek ? DASH_COPY.weekStayLabel(s.from) : DASH_COPY.weekStay;
  return `
    <section class="card suggest-card">
      <div class="card-eyebrow">${title}</div>
      <p>${body}</p>
      <div class="suggest-actions">
        <button class="btn-primary sm" data-suggest="advance|${s.kind}|${escapeHtml(s.k.id)}">${advanceLabel}</button>
        <button class="btn-quiet sm" data-suggest="stay|${s.kind}|${escapeHtml(s.k.id)}">${stayLabel}</button>
      </div>
    </section>`;
}

function wireSuggestion(state) {
  document.querySelectorAll("[data-suggest]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const [choice, kind, id] = btn.dataset.suggest.split("|");
      // A fresh, real "today" — not state.today, which is however old this
      // render is. A tab open past the day boundary must not backdate
      // targetChangedOn to the day it happened to load on.
      const today = dateStr();
      let changed = false;
      await saveKabbalahById(id, (k) => {
        if (kind === "week") {
          // Pass today so an accepted engine descent stamps targetChangedOn
          // too (dashboard-model.js's own fix, ed73465) — otherwise the same
          // seven kept days that earned THIS descent would immediately earn
          // a second, unrelated one from targetSuggestion's card.
          const patch = applyWeekChoice(k, choice, today);
          if (!patch) return;
          Object.assign(k, patch);
          changed = true;
        } else {
          // state.events (render-time) is still used here, per the same
          // minimum-fix reasoning as the rest of this handler: events are
          // append-only and this offer already re-checks itself below, so
          // only the mutated kabbalah itself needs a fresh read.
          const s = targetSuggestion(k, state.events, today);
          if (!s) return; // the offer expired between render and click
          if (choice === "advance") {
            // The existing target-change path: a direct rule write through
            // storeSet, exactly how applyWeekChoice's "stay" already moves
            // limitMinutes, applied immediately — the engine's own
            // settleWeek applies its drops immediately too; nothing in this
            // product defers a target to tomorrow (only MODES wait a day).
            k.rule = { ...k.rule, limitMinutes: s.to };
            k.targetChangedOn = today;
            k.dismissedSuggestion = null;
          } else {
            k.dismissedSuggestion = { from: s.from };
          }
          changed = true;
        }
      });
      if (changed) render();
    })
  );
}

function calendarGridHtml(cal, k) {
  const name = escapeHtml(kabbalahLabel(k));
  const head = DAY_NAMES.map((n) => `<div class="cal-dayname">${n}׳</div>`).join("");
  const cells = cal.weeks
    .map((week) =>
      week
        .map((c) => {
          if (!c) return `<span class="hist-day blank"></span>`;
          const today = c.isToday ? " today" : "";
          return `<span class="hist-day ${c.status}${today}" title="${c.day}">${c.num}</span>`;
        })
        .join("")
    )
    .join("");
  const pct =
    cal.percent === null ? "" : `<span class="cal-percent">${DASH_COPY.calPercent(cal.percent)}</span>`;
  return `
    <div class="cal-kab">
      <div class="cal-kab-head"><span class="cal-kab-name" title="${name}">${name}</span>${pct}</div>
      <div class="cal-grid">${head}${cells}</div>
    </div>`;
}

function renderCalendarCard(state) {
  const cals = state.kabbalot.map((k) => ({ k, cal: monthCalendar(k, state.events, state.today) }));
  const monthLabel = cals.length ? cals[0].cal.monthLabel : "";
  const anyReleased = cals.some(({ cal }) =>
    cal.weeks.some((w) => w.some((c) => c && c.status === "released"))
  );
  const legendReleased = anyReleased
    ? `<span class="legend-item"><span class="legend-dot released"></span>${DASH_COPY.legendReleased}</span>`
    : "";
  return `
    <section class="card cal-card">
      <div class="cal-head">
        <span class="card-eyebrow cal-title">${DASH_COPY.calTitle(monthLabel)}</span>
        <span class="fine">${DASH_COPY.calSub}</span>
      </div>
      <div class="cal-list">
        ${cals.map(({ k, cal }) => calendarGridHtml(cal, k)).join("")}
      </div>
      <div class="legend">
        <span class="legend-item"><span class="legend-dot kept"></span>${DASH_COPY.legendKept}</span>
        <span class="legend-item"><span class="legend-dot fell"></span>${DASH_COPY.legendFell}</span>
        <span class="legend-item"><span class="legend-dot today"></span>${DASH_COPY.legendToday}</span>
        ${legendReleased}
      </div>
    </section>`;
}

function renderFooter() {
  return `
    <div class="footer-links">
      <button class="btn-link" id="create-kabbalah">${DASH_COPY.createBtn}</button>
      <button class="btn-link" id="open-settings">${DASH_COPY.editKabbalah}</button>
      <button class="btn-link" id="open-places">${DASH_COPY.editPlaces}</button>
      <button class="btn-link" id="open-export">${DASH_COPY.exportLink}</button>
    </div>`;
}

function renderPauseCard(pause) {
  return `
    <div class="pause-card">
      <p>${DASH_COPY.pauseTitle(pause.kabbalahName, pause.days)}</p>
      <p class="fine">${DASH_COPY.pauseConfirm}</p>
      <div class="pause-actions">
        <button class="btn-quiet sm" id="pause-back">${DASH_COPY.pauseGoBack}</button>
        <button class="btn-primary sm" id="pause-continue">${DASH_COPY.pauseContinue}</button>
      </div>
    </div>`;
}

function renderPauseSlot(state) {
  const pause = gentlePause(state.kabbalot, state.today);
  // Re-check rather than trust the stale flag — the same "the check runs
  // again, it just never blocks" shape issue #20's report describes.
  if (!pause) {
    pauseShownFor = null;
    return "";
  }
  return `<section class="card">${renderPauseCard(pause)}</section>`;
}

// ---------- rendering: the settings reveal ----------

function modeToggleHtml(k) {
  const pending = k.pendingMode
    ? `<div class="mode-pending">${DASH_COPY.pendingCommitment}</div>`
    : "";
  return `
    <div>
      <div class="mode-toggle" role="radiogroup" aria-label="${DASH_COPY.modeCompanion} / ${DASH_COPY.modeCommitment}">
        <button type="button" class="mode-toggle-btn${k.mode === "companion" ? " on" : ""}"
                role="radio" aria-checked="${k.mode === "companion"}"
                data-mode="companion|${escapeHtml(k.id)}">${DASH_COPY.modeCompanion}</button>
        <button type="button" class="mode-toggle-btn commitment${k.mode === "commitment" ? " on" : ""}"
                role="radio" aria-checked="${k.mode === "commitment"}"
                data-mode="commitment|${escapeHtml(k.id)}">${DASH_COPY.modeCommitment}</button>
      </div>
      ${pending}
    </div>`;
}

function renderKabbalahSettings(k) {
  const editable = canEditPlacesViaOnboarding(k);
  const editHtml = editable
    ? `<button class="btn-link muted" data-edit="${escapeHtml(k.id)}">${DASH_COPY.editPlaces}</button>`
    : `<span class="fine">${DASH_COPY.editUnavailable}</span>`;
  return `
    <div class="kab-settings">
      <div class="kab-settings-name">${escapeHtml(kabbalahLabel(k))}</div>
      ${modeToggleHtml(k)}
      ${editHtml}
    </div>`;
}

// The one row that is not always the same row: issue #130's guard, which
// takes the removal button away from the window she is inside AT THIS
// MINUTE and leaves every other row exactly as it was.
//
// It is a `disabled` attribute and a visible reason, not a vanished button.
// The house rule elsewhere on this board is §1 principle 4 — an action that
// is not available disappears rather than greying out (popup.js says so at
// its own send button, and renderChatPanel drops its chips outright on a
// closed conversation). This row is the deliberate exception, and Sara's
// issue asks for it in those words: "כפתור מושבת בלי סיבה נקרא כתקלה. צריך משפט קצר."
// A button that simply left the list would read as data loss on a screen
// whose whole job is her own settings; the row has to stay, say it is held,
// and say until when. `aria-describedby` ties the reason to the button, so
// a screen reader reaching a disabled control is told why it is disabled
// rather than just that it is.
function renderWindowLine(w, i, now) {
  const days = (w.days || []).slice().sort().map((d) => `${DAY_NAMES[d]}׳`).join(" ");
  // w.from/w.to normally come from the <input type="time"> below, but
  // quietWindows is stored data like any other kabbalah field — the same
  // "escape it because it's rendered, not because it's untrusted today"
  // reasoning as kabRowHtml's name (review item 2/4).
  const removable = canRemoveQuietWindow(w, now);
  const reasonId = `window-held-${i}`;
  return `<div class="window-line${removable ? "" : " held"}">
      <div class="window-when" dir="ltr">${escapeHtml(w.from)}–${escapeHtml(w.to)}</div>
      <div class="window-meta">בימים ${days}</div>
      <button class="btn-link muted" data-remove-window="${i}"${
        removable ? "" : ` disabled aria-describedby="${reasonId}"`
      }>${DASH_COPY.quietRemove}</button>
      ${
        removable
          ? ""
          : `<p class="fine window-held" id="${reasonId}">${DASH_COPY.quietRemoveHeld(DASH_COPY.hardNow)}</p>`
      }
    </div>`;
}

// The three blocks below each carry .settings-block: dashboard.css lays the
// settings card out as an auto-fitting grid (issue #124 — as one column of
// narrow content in a full-width card, everything hugged the RTL edge and
// half the card stayed blank), and the class is what marks a block as one
// of that grid's columns. The card's own title, the per-kabbalah rows and
// the explanatory line stay full width and are matched by their own classes.
function renderQuietSettings(state) {
  return `
    <div class="settings-block quiet-block">
      <div class="card-title">${DASH_COPY.quietTitle}</div>
      <p class="fine">${DASH_COPY.quietIntro}</p>
      ${(() => {
        // One clock for the whole list, read once, so two rows drawn in the
        // same paint are never judged by two different minutes.
        const now = new Date();
        return state.quietWindows.map((w, i) => renderWindowLine(w, i, now)).join("");
      })()}
      <div class="window-form">
        <div class="day-row">
          ${DAY_NAMES.map(
            (n, i) =>
              `<button class="chip day-chip${draftDays.includes(i) ? " on" : ""}" data-day="${i}">${n}׳</button>`
          ).join("")}
        </div>
        <div class="time-row">
          <label>מהשעה <input type="time" id="from-time" step="900" value="${escapeHtml(draftFrom)}" /></label>
          <label>עד <input type="time" id="to-time" step="900" value="${escapeHtml(draftTo)}" /></label>
        </div>
        <button class="btn-quiet sm" id="add-window" style="align-self:flex-start">${DASH_COPY.quietAdd}</button>
      </div>
    </div>`;
}

function renderReminderSettings(state) {
  return `
    <div class="settings-block">
      <div class="card-title">${DASH_COPY.reminderTitle}</div>
      <div class="reminder-row">
        <div class="stepper">
          <button type="button" class="stepper-btn" data-hour="-" aria-label="${DASH_COPY.reminderTitle}">−</button>
          <div class="stepper-value" dir="ltr">${quietHourLabel(state.reminderHour)}</div>
          <button type="button" class="stepper-btn" data-hour="+" aria-label="${DASH_COPY.reminderTitle}">+</button>
        </div>
      </div>
    </div>`;
}

// Sara's ruling of 2026-08-23. There is no zmanim call here and there never
// will be (docs/packaging.md Gate 1), so the two hours are hers or they are
// the defaults. Same <input type="time"> the quiet-hours form beside it
// already uses, on the same quarter-hour grid, so this screen has one way of
// asking for a clock reading rather than two.
function renderShabbatSettings(state) {
  return `
    <div class="settings-block">
      <div class="card-title">${DASH_COPY.shabbatTitle}</div>
      <p class="fine">${DASH_COPY.shabbatIntro}</p>
      <div class="window-form">
        <div class="time-row">
          <label>${DASH_COPY.shabbatFrom}
            <input type="time" id="friday-from" step="900" value="${escapeHtml(state.shabbatEdges.fridayFrom)}" /></label>
          <label>${DASH_COPY.shabbatTo}
            <input type="time" id="motzash-from" step="900" value="${escapeHtml(motzashFieldValue(state.shabbatEdges.motzashFrom))}" /></label>
        </div>
        <button class="btn-quiet sm" id="save-shabbat" style="align-self:flex-start">${DASH_COPY.shabbatSave}</button>
        <div class="fine">${DASH_COPY.shabbatNote}</div>
      </div>
    </div>`;
}

function renderSettings(state) {
  return `
    <section class="card settings-grid" id="settings">
      <div class="section-title">${DASH_COPY.settingsTitle}</div>
      ${state.kabbalot.map(renderKabbalahSettings).join("")}
      <div class="fine">${DASH_COPY.modeNote}</div>
      ${renderQuietSettings(state)}
      ${renderReminderSettings(state)}
      ${renderShabbatSettings(state)}
    </section>`;
}

function renderEmpty() {
  return `
    <section class="card empty-note" style="text-align:center;gap:14px;">
      <div class="card-title">${DASH_COPY.emptyTitle}</div>
      <p>${DASH_COPY.emptyBody}</p>
      <button class="btn-primary sm" id="start-onboarding" style="align-self:center">${DASH_COPY.emptyBtn}</button>
    </section>`;
}

// ---------- the chat: the popup's engine, a panel's worth of surface ----------

// The hard-day valve's door (#87), so where it sits is not decoration.
//
// It used to be position:fixed against the viewport, and inset-inline-end is
// the LEFT edge in RTL, so on a wide window it pinned itself to the far
// bottom-left corner while the whole board sat centred ("בעמוד המלא הוא קצת
// נעלם", issue #124). The first fix here put it in the flow at the very end
// of .dash-body — inside the board, which is what Sara suggested, but BELOW
// the four housekeeping links and 170px under the fold at 1280x800. That
// traded one kind of disappearing for another, and it also undid #121, where
// she asked for the button to be MORE dominant, not less.
//
// It now renders directly under .dash-columns — the "מצב היום" row, the card
// about right now, which is what this button is about too. It is the first
// thing after the board's live state, it is above the fold at 1280x800 with
// one kabbalah, and it is nowhere near the housekeeping links. .fab-slot is
// what carries the placement (and gives the panel it opens something to
// anchor to, so the two never drift apart); dashboard.css carries the size.
function renderChatButton() {
  return `
    <button class="fab" id="hard-now">
      <img src="character/v3/heart.png" alt="" />
      ${DASH_COPY.hardNow}
    </button>`;
}

function chatBubbleHtml(who, text) {
  return `<div class="chat-bubble ${who}">${escapeHtml(text)}</div>`;
}

function renderChatPanel() {
  const closed = !convState || convState.closed;
  // §1 principle 4: an action that isn't available disappears — a closed
  // conversation renders neither chips nor an input row, exactly as the
  // popup removes its own input row outright.
  const chips = closed
    ? ""
    : `<div class="chat-chips" id="chat-chips">
        ${DASH_COPY.chatChips.map((c, i) => `<button class="chat-chip" data-chip="${i}">${c}</button>`).join("")}
      </div>`;
  const inputRow = closed
    ? ""
    : `<div class="chat-input-row">
        <input type="text" id="chat-input" class="chat-input" placeholder="${DASH_COPY.chatPlaceholder}" />
        <button class="chat-send" id="chat-send" aria-label="שליחה">←</button>
      </div>`;
  return `
    <div class="chat-panel" id="chat-panel">
      <div class="chat-head">
        <img src="character/v3/heart.png" alt="" />
        <div class="chat-head-text">
          <span class="chat-title">${DASH_COPY.chatTitle}</span>
          <span class="chat-sub">${DASH_COPY.chatSub}</span>
        </div>
        <button class="chat-close" id="chat-close" aria-label="סגירה">✕</button>
      </div>
      <div class="chat-privacy">${DASH_COPY.chatPrivacy}</div>
      <div class="chat-log" id="chat-log">
        ${chatLog.map((m) => chatBubbleHtml(m.who, m.text)).join("")}
      </div>
      ${chips}
      ${inputRow}
    </div>`;
}

// One assistant turn — the same three lines popup.js's askOra runs, against
// the same window.ChatEngine / window.MESSAGE_BANK chat-bridge.js provides.
async function askOra() {
  const step = window.ChatEngine.advanceConversation(window.MESSAGE_BANK, convState, convPoolHistory);
  convState = step.state;
  convPoolHistory = step.poolHistory;
  await storeSet({ chatPoolHistory: convPoolHistory });
  return step.text;
}

async function openChat() {
  chatOpen = true;
  chatLog = [];
  let opening = CHAT_FALLBACK_REPLY;
  try {
    convState = window.ChatEngine.createConversationState();
    const { chatPoolHistory } = await storeGet("chatPoolHistory");
    convPoolHistory = chatPoolHistory || window.ChatEngine.createPoolHistory();
    opening = await askOra();
  } catch {
    // A bank that failed to load still gets her a warm, honest line — and a
    // closed state, because there is no engine to answer a reply.
    convState = { turn: 0, usedIds: [], closed: true };
  }
  chatLog.push({ who: "ora", text: opening });
  render();
}

async function sendChat(text) {
  const t = String(text || "").trim();
  if (!t || !convState || convState.closed) return;
  chatLog.push({ who: "me", text: t });
  let answer = CHAT_FALLBACK_REPLY;
  try {
    answer = await askOra();
  } catch {
    convState = { ...convState, closed: true };
  }
  chatLog.push({ who: "ora", text: answer });
  render();
}

function wireChat() {
  el("hard-now")?.addEventListener("click", () => {
    if (chatOpen) {
      chatOpen = false;
      render();
      return;
    }
    openChat();
  });
  el("chat-close")?.addEventListener("click", () => {
    chatOpen = false;
    render();
  });
  document.querySelectorAll("[data-chip]").forEach((btn) =>
    btn.addEventListener("click", () => sendChat(btn.textContent))
  );
  const input = el("chat-input");
  const send = () => {
    if (!input) return;
    const t = input.value;
    input.value = "";
    sendChat(t);
  };
  el("chat-send")?.addEventListener("click", send);
  input?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      send();
    }
  });
}

// ---------- the one render ----------

async function render() {
  // Any render, whatever triggered it, shows everything current — a
  // redraw deferred by the guard below (because she was mid-typing when it
  // arrived) is no longer owed once a render actually happens.
  redrawPending = false;
  const state = await loadState();
  const main = el("main");

  if (!state.kabbalot.length) {
    main.innerHTML = `<div class="shell">${renderHeader()}<div class="dash-body">${renderEmpty()}</div></div>`;
    el("start-onboarding")?.addEventListener("click", () => openTab("onboarding.html"));
    return;
  }

  main.innerHTML = `
    <div class="shell">
      ${renderHeader()}
      <div class="dash-body">
        <div class="dash-columns">
          ${renderTodayCard(state)}
          <div class="side-col">
            ${renderGeneralCard(state)}
            ${renderSuggestionCard(state)}
          </div>
        </div>
        <div class="fab-slot">
          ${renderChatButton()}
          ${chatOpen ? renderChatPanel() : ""}
        </div>
        ${renderCalendarCard(state)}
        ${pauseShownFor ? renderPauseSlot(state) : ""}
        ${settingsOpen ? renderSettings(state) : ""}
        ${renderFooter()}
      </div>
    </div>`;

  wireFooter(state);
  wireKabbalahSettings(state);
  wireSuggestion(state);
  wireSettings(state);
  wireChat();
  wireRedrawFlush();
  const log = el("chat-log");
  if (log) log.scrollTop = log.scrollHeight;
}

// True while she has an editable field inside #main actively focused. The
// two reproduced clobbers this closes (issue #102 review follow-up) are
// both "she is mid-typing when a background storage write lands" — quiet-
// hours' #from-time/#to-time and the chat panel's #chat-input — so checking
// focus alone is enough to close both without over-guarding: a background
// redraw landing while nothing here is focused is exactly as safe as it
// always was.
//
// tagName is compared case-insensitively on purpose (review follow-up: this
// was the actual bug in the first version of this guard) — a real DOM's
// `Element.tagName` reads UPPERCASE ("INPUT"), not the lowercase this
// file's own template literals are written in, and dom-stub.mjs's tiny
// parser happens to preserve whatever case the source markup used, so a
// case-sensitive check against "input" passed every test here while doing
// nothing at all in a real tab. This is the one tagName comparison in the
// whole extension — nothing else to match its convention against.
const EDITABLE_TAG = /^(input|textarea|select)$/i;
function editableFocusedInMain() {
  const main = el("main");
  const active = document.activeElement;
  if (!main || !active) return false;
  if (!active.isContentEditable && !EDITABLE_TAG.test(active.tagName)) return false;
  let node = active;
  while (node) {
    if (node === main) return true;
    node = node.parentElement;
  }
  return false;
}

// Called when she leaves one of those fields (blur) or closes the panel it
// lives in (settings/chat already call render() directly on close, which
// clears redrawPending itself — see render()'s own first line) — applies
// whatever background redraw was deferred while she was mid-typing there.
function maybeFlushPendingRedraw() {
  if (!redrawPending) return;
  redrawPending = false;
  render();
}
// Known narrow gap (review follow-up, left as-is on purpose): if she parks
// focus in a field and switches browser tabs rather than blurring it (a
// "visibilitychange" the field itself never sees), a redraw stays deferred
// until she interacts with this tab again — the board can sit one write
// stale in the meantime, never a wrong one. A visibilitychange flush would
// close it; not added here because it would need dom-stub.mjs to model
// document.visibilityState/hidden, which no test in this suite does yet.

// Wires the flush above onto every field editableFocusedInMain() actually
// guards — by query, not by a hand-maintained list of ids (review
// follow-up: the guard is generic over any input/textarea/select inside
// #main, but an id allowlist here would silently fall out of step with it
// the day a fourth field is added — deferred by the guard, flushed by
// nothing, a redraw stranded forever). Called once per render(), after the
// markup for that render exists to query.
function wireRedrawFlush() {
  const main = el("main");
  if (!main) return;
  ["input", "textarea", "select"].forEach((tag) =>
    main.querySelectorAll(tag).forEach((field) =>
      field.addEventListener("blur", maybeFlushPendingRedraw)
    )
  );
}

// ---------- wiring ----------

function wireFooter(state) {
  el("create-kabbalah")?.addEventListener("click", () => {
    const pause = gentlePause(state.kabbalot, state.today);
    if (pause) {
      pauseShownFor = pause.kabbalahId;
      render();
      return;
    }
    openTab("onboarding.html?new=1");
  });
  el("pause-back")?.addEventListener("click", () => {
    pauseShownFor = null;
    render();
  });
  // S-05: never a wall — this click always gets her through.
  el("pause-continue")?.addEventListener("click", () => {
    pauseShownFor = null;
    openTab("onboarding.html?new=1");
  });
  el("open-settings")?.addEventListener("click", () => {
    settingsOpen = !settingsOpen;
    render();
  });
  // "עריכת אתרים" from the footer: the per-kabbalah edit doors (each behind
  // canEditPlacesViaOnboarding) live inside the settings reveal — open it.
  el("open-places")?.addEventListener("click", () => {
    settingsOpen = true;
    render();
  });
  el("open-export")?.addEventListener("click", () => openTab("export.html"));
}

function wireKabbalahSettings(state) {
  document.querySelectorAll("[data-edit]").forEach((btn) =>
    btn.addEventListener("click", () => openTab(`onboarding.html?edit=${btn.dataset.edit}`))
  );
  document.querySelectorAll("[data-mode]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const [target, id] = btn.dataset.mode.split("|");
      const today = dateStr(); // fresh, not the render-time state.today
      let changed = false;
      await saveKabbalahById(id, (k) => {
        const patch = requestModeChange(k, target, today);
        if (!patch) return;
        Object.assign(k, patch);
        changed = true;
      });
      if (changed) render();
    })
  );
}

function wireSettings(state) {
  document.querySelectorAll(".day-chip").forEach((btn) =>
    btn.addEventListener("click", () => {
      const d = Number(btn.dataset.day);
      draftDays = draftDays.includes(d) ? draftDays.filter((x) => x !== d) : [...draftDays, d];
      btn.classList.toggle("on");
    })
  );
  document.querySelectorAll("[data-remove-window]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const i = Number(btn.dataset.removeWindow);
      // Asked again here, and not only at render time (#130). A real
      // `<button disabled>` never runs this listener at all, so on the
      // happy path this costs nothing — but this tab may have been sitting
      // open since before the window opened, and then the button she is
      // pressing was drawn under a clock that has since moved past her own
      // start time. Redrawing instead of deleting turns that stale row into
      // the held row it should already have been, reason and all.
      if (!canRemoveQuietWindow(state.quietWindows[i], new Date())) {
        render();
        return;
      }
      await storeSet({ quietWindows: state.quietWindows.filter((_, idx) => idx !== i) });
      render();
    })
  );
  // Keep the draft in step with the field on every keystroke, so a redraw
  // between now and the save re-renders what she typed. Reading the node at
  // save time is not enough: the node she typed into may not be the node
  // that is there when she presses the button.
  // Tracks the field exactly, empty included: a value she cleared must come
  // back cleared, not resurrected by the next redraw, and the guard below
  // still refuses to save an empty edge.
  el("from-time")?.addEventListener("input", () => {
    draftFrom = el("from-time").value;
  });
  el("to-time")?.addEventListener("input", () => {
    draftTo = el("to-time").value;
  });
  el("add-window")?.addEventListener("click", async () => {
    const from = el("from-time").value;
    const to = normaliseWindowEnd(el("to-time").value);
    if (!from || !to || !draftDays.length) return;
    await storeSet({
      quietWindows: [...state.quietWindows, { days: draftDays, from, to, scope: "browser" }],
    });
    // The window is hers now; the next one starts from the defaults again
    // rather than from what she just used.
    draftFrom = QUIET_DRAFT_DEFAULT.from;
    draftTo = QUIET_DRAFT_DEFAULT.to;
    render();
  });
  document.querySelectorAll("[data-hour]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const next =
        btn.dataset.hour === "+"
          ? Math.min(REMINDER_CEIL, state.reminderHour + REMINDER_STEP)
          : Math.max(REMINDER_FLOOR, state.reminderHour - REMINDER_STEP);
      await storeSet({ reminderHour: next });
      render();
    })
  );

  // Both edges are written in one go, so a half-finished pair can never
  // reach storage: an empty or unparseable field simply keeps whatever that
  // edge already had.
  el("save-shabbat")?.addEventListener("click", async () => {
    await storeSet({
      shabbatEdges: normaliseShabbatEdges({
        fridayFrom: el("friday-from").value || state.shabbatEdges.fridayFrom,
        motzashFrom: el("motzash-from").value || state.shabbatEdges.motzashFrom,
      }),
    });
    render();
  });
}

// ---- design-review seeding, outside the extension only ----------------
// Same guard and same purpose as issue #20's version: opening dashboard.html
// over http (extension/index.html's preview list) seeds enough data that
// every 2a section is visible at once. Extended with usage days so the
// clocks, bars and the returned-hours line show real arithmetic instead of
// empty quotas. Inside the real extension this never runs.
function seedPreviewIfEmpty() {
  if (hasChrome) return;
  if (!("kabbalot" in memStore)) {
    // Routed through dateStr()/daysAgoStr() (review item 4) rather than a
    // bare new Date().setDate() — the latter counts back from the actual
    // calendar day, not her day (DAY_RESET_HOUR = 3). Between midnight and
    // 03:00 the two disagree by exactly one day, so back(0) used to hand
    // out tomorrow's date relative to what dateStr() elsewhere on this same
    // page calls "today" — a seed that argued with itself for three hours
    // every night, preview-only (hasChrome guard above) but still worth
    // getting right the same cheap way the rest of this file already does.
    const todayForSeed = dateStr();
    const back = (n) => daysAgoStr(todayForSeed, n);
    const events = [];
    for (let i = 1; i <= 10; i++) {
      events.push({
        type: i === 4 ? "fall" : "day_success",
        occurredAt: new Date().toISOString(),
        kabbalahId: "preview_k1",
        meta: { day: back(i) },
      });
    }
    for (let i = 1; i <= 5; i++) {
      events.push({
        type: "day_success",
        occurredAt: new Date().toISOString(),
        kabbalahId: "preview_k2",
        meta: { day: back(i) },
      });
    }
    memStore.kabbalot = [
      {
        id: "preview_k1", name: "הפינה ההיא",
        rule: { kind: "dailyLimit", limitMinutes: 60 },
        places: ["preview-place-one.example"], baselineMinutes: 120,
        mode: "companion", streak: 3, longestStreak: 9, daysKept: 21,
        stationsReached: 1, pendingStation: null, fellOn: null, fallAcked: true,
        createdAt: back(21),
        pendingWeekChoice: { previousLimit: 60, newLimit: 45 },
      },
      {
        id: "preview_k2", name: "האתר השני",
        rule: { kind: "dailyLimit", limitMinutes: 30 },
        places: ["preview-place-two.example"], baselineMinutes: 45,
        mode: "commitment", streak: 5, longestStreak: 5, daysKept: 5,
        stationsReached: 0, pendingStation: null, fellOn: null, fallAcked: true,
        createdAt: back(5),
      },
    ];
    memStore.events = events;
    memStore[`usage:${dateStr()}`] = {
      "preview-place-one.example": 35 * 60,
      "preview-place-two.example": 12 * 60,
    };
    for (let i = 1; i <= 6; i++) {
      memStore[`usage:${back(i)}`] = {
        "preview-place-one.example": 55 * 60,
        "preview-place-two.example": 20 * 60,
      };
    }
    memStore.reminderHour = 20;
    memStore.quietWindows = [{ days: [0, 1, 2, 3, 4], from: "16:00", to: "17:00", scope: "browser" }];
    persistMemStore();
  }
}

// The board follows her data wherever it is written from — background.js
// settles weeks and acks falls straight to storage while this tab stays
// open (docs/data-model.md's own "לא דרך הודעה למנוע"), the same reason
// saveKabbalahById above re-reads before writing. Without this, a tab left
// open overnight would keep showing the numbers it loaded with until she
// clicks something on it herself. Mirrors background.js's own
// syncFallBadge listener, one key wider (events matters here too — a fall
// or a day_success recorded elsewhere changes the calendar and the
// suggestion card, not just kabbalot). Guarded by hasChrome because, unlike
// background.js, this file also runs as a plain http preview
// (seedPreviewIfEmpty above) where `chrome` itself does not exist.
if (hasChrome) {
  chrome.storage.onChanged?.addListener?.((changes, area) => {
    if (area !== "local" || !(changes.kabbalot || changes.events)) return;
    if (!el("main")) return;
    // She is mid-typing somewhere inside #main right now (quiet-hours'
    // #from-time/#to-time, or the chat panel's #chat-input) — a redraw
    // this instant would wipe it silently (the field still LOOKS right
    // afterward, because settingsOpen/chatOpen are module-level state that
    // survives the redraw — she just typed something into it that is no
    // longer there). Defer instead: maybeFlushPendingRedraw() applies it
    // the moment she leaves that field.
    if (editableFocusedInMain()) {
      redrawPending = true;
      return;
    }
    render();
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  seedPreviewIfEmpty();
  await render();
});
