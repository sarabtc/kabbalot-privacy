// בחרתי בי — popup: the v3 rewrite (issue #16, DESIGN.md §6.2).
//
// This is the one screen in the product she opens most — the onboarding,
// the stop page and the export screen are each seen once, or only on a bad
// day. So this rewrite carries more weight than any of them, and it lands
// on top of the many-kabbalot engine (#13): the popup used to walk with
// `kabbalot[0]` alone ("the UI is still single-kabbalah — the v3 screens
// are stage 2", read the old comment here). This file is stage 2.
//
// Copy rules (DESIGN.md §7, docs/messages.md): her agency, no "failed"
// language, positive accounting, no emoji anywhere except STATION_SYMBOLS
// (issue #57's call, not this one's — see
// extension/tests/the-character-carries-the-warmth.mjs).
//
// CULTURAL RED LINE (Sara's ruling, #15, narrowed by Founder Ruling 1,
// 2026-08-26): the rule used to be "never a site or brand name, anywhere" —
// that stopped being accurate the moment nameFrom()'s own fallback started
// defaulting `kabbalah.name` to the site itself (2026-08-25). The real rule
// is narrower: a site name may appear as the kabbalah's own default name,
// but never on a surface someone else in the room could see without her
// having opened it herself. The popup is exactly such a surface — she opens
// it herself — so it is allowed to show `kabbalah.name` here, whatever it
// is. What still never appears on ANY screen is `kabbalah.places` itself
// (the raw domain list) — not even as a count — because that was never
// what she named the kabbalah, only what it resolves to. A chip naming a
// site is a shortcut at setup only.
//
// ---- judgment calls this file had to make, flagged rather than guessed ----
// DESIGN.md was written for the popup before the many-kabbalot engine (#13)
// landed underneath it, so a few of its literal screen contents describe
// data this build does not have. Each gap below is a deliberate choice, not
// an oversight — reported to Sara in full with the rest of this build.
//
// 1. §6.2's "רואים את הירידה? זו את" bar graph and the "איך עבר היום עם
//    הקבלה?" manual check-in card both assume a self-reported day (עמדתי /
//    היה לי קשה). The real engine judges every day automatically from
//    measured usage (`streak`/`fellOn`/`fallAcked`, docs/data-model.md) —
//    there is no "did she check in" field to ask about, and building a fake
//    one would mean asking her to confirm something the product already
//    knows. Neither is built. The per-kabbalah list (§8 decision 4, "רשימת
//    הקבלות הפעילות שלך") carries the same information honestly instead.
// 2. The illustrated v2 "journey road" (a hand-drawn landscape SVG with its
//    own gold/green palette, JOURNEY_STAGES, stageEnd/stagesAtDays,
//    currentStage — all removed below) is not part of the v3 language at
//    all: DESIGN.md never mentions it, its colours are not v3 tokens, and
//    §1 principle 1 ("הדמות מובילה, הממשק לא מטיף") already gives the
//    illustrated character that narrative role. The station ritual itself
//    (a real, tested feature — `pendingStation`/`stationsReached`) is kept;
//    only the flavour text and the SVG road around it are gone.
// 3. "יצירת קבלה חדשה" (§8 decision 3: always available) is not built here.
//    `onboarding.js`'s `saveKabbalah()` always edits `kabbalot[0]` — it has
//    no path to *add* a second kabbalah. Wiring a button to it here would
//    either silently overwrite her first kabbalah's data, or require
//    changing onboarding.js's save logic, which is out of this issue's
//    scope. Left undone rather than built unsafely.
// 4. RESOLVED (issue #94). "הגדרות הקבלה" (edit) used to appear only when
//    she had exactly one kabbalah, and the morning-after screen's "להקל על
//    הקבלה" only when the kabbalah that fell IS `kabbalot[0]` — both because
//    `openOnboarding()` opened `onboarding.html` blind, and onboarding.js's
//    default (no-query) intent always edits `kabbalot[0]`. onboarding.js has
//    parsed `?edit=<id>` since issue #20; `openOnboarding()` below now takes
//    the id to edit and both call sites pass the specific kabbalah on
//    screen, so both restrictions are gone. What is not gone: a kabbalah
//    onboarding-model.js's `canEditPlacesViaOnboarding()` refuses (any place
//    with a path, e.g. a "corner" narrowed on the dashboard, which cannot
//    round-trip through onboarding's link field without silently widening
//    back to the whole site) still gets no edit control here — the same
//    guard dashboard.js checks before it ever renders its own edit link.
//    Unlike dashboard.js, this cramped 360px popup does not add an
//    "unavailable" explanation for that case; the control is simply absent,
//    same as every other thing this screen leaves unsaid rather than
//    crowds in. See kabCardHtml() and canEaseFor() below.
// 5. `extension/chat-engine.js` (issue #17's local reply pool, matching
//    exactly what DESIGN.md §8 decision 1 asks for) is wired in now (see
//    "a real conversation with אורה" below and extension/chat-bridge.js).
//    It ships as a generated asset, not docs/messages.md itself — see
//    scripts/build-message-bank.mjs's header for why — and reaches this
//    plain script as window.ChatEngine / window.MESSAGE_BANK, set by
//    chat-bridge.js's own small ES module before her first click can ever
//    reach askOra(). The five hardcoded SUPPORT_MESSAGES this rewrite
//    inherited (none of them in docs/messages.md) are gone.
// 6. Two short lines have no home in DESIGN.md §7 or docs/messages.md and
//    are marked inline where they appear: the per-kabbalah quiet-hours-rule
//    summary line ("שקטה בימים… "), and the empty-install screen's
//    onward-facing choice of reusing the onboarding's own approved opening
//    copy rather than writing a new welcome line.
//
// Two things this rewrite was told, explicitly, not to touch:
// `showResetConfirm()` keeps its exact gating logic (issue #46) —
// restyled, not re-plumbed — and every date this file needs comes from
// `dateStr()` in shared.js, never computed locally.

// issue #94: this used to always open "onboarding.html" bare, which put
// onboarding.js on its default (no-query) intent — always `kabbalot[0]`,
// regardless of which kabbalah she was actually looking at. Every caller
// below now has a specific kabbalah id in hand and passes it; the id
// becomes onboarding.html's `?edit=<id>` (parsed since issue #20), so the
// tab that opens edits exactly the kabbalah she asked for. `kabbalahId` is
// required in practice — every remaining call site here has one — but is
// still accepted as optional so a caller with no id (none exists today)
// degrades to the old blind behaviour instead of building a broken URL.
function openOnboarding(kabbalahId) {
  const url = kabbalahId
    ? `onboarding.html?edit=${encodeURIComponent(kabbalahId)}`
    : "onboarding.html";
  if (hasChrome && chrome.tabs) {
    chrome.tabs.create({ url: chrome.runtime.getURL(url) });
    window.close();
  } else {
    window.location.href = url;
  }
}

function openExport() {
  if (hasChrome && chrome.tabs) {
    chrome.tabs.create({ url: chrome.runtime.getURL("export.html") });
    window.close();
  } else {
    window.location.href = "export.html";
  }
}

// issue #20's door: "נפתח מהפופאפ", the closing criterion's own words. Same
// tab-not-navigate shape as openOnboarding/openExport above, because the
// dashboard is a full page (statistics, settings, and now the only path to
// a second kabbalah) and the 360px popup shell was never meant to hold it.
function openDashboard() {
  if (hasChrome && chrome.tabs) {
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
    window.close();
  } else {
    window.location.href = "dashboard.html";
  }
}

// ---------- storage ----------
// storeGet / storeSet / storeClear / dateStr / parseLink live in shared.js.
// dateStr() is the one and only place "what day is it" is decided in this
// file — a sibling branch (#6) is changing the boundary a day starts on,
// and every call site below goes through that single function so the fix
// only has to land once.

// Her own words for her own place — never a brand name. Escaped wherever it
// reaches innerHTML (see escapeHtml below), the same discipline content.js
// already holds for this exact field.
function kabbalahLabel(kabbalah) {
  return (kabbalah && kabbalah.name) || "המקום שלי";
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[c]);
}

// Mutates one kabbalah by id and writes the whole list back — the general
// form of what used to be savePrimary() (kabbalot[0] only). Known race,
// accepted for the pilot: the popup and the worker both rewrite the whole
// list, so a click landing inside the worker's multi-day settlement can be
// overwritten. #13 routes popup writes through the worker (the
// kabbalot-grace message pattern) and retires this helper.
async function saveKabbalahById(id, mutate) {
  const { kabbalot = [] } = await storeGet("kabbalot");
  const k = kabbalot.find((x) => x.id === id);
  if (!k) return null;
  mutate(k);
  await storeSet({ kabbalot });
  return k;
}

// The journal feeds the export screen ("הסיפור שלך במספרים") — local only.
async function journalEvent(type, meta = {}) {
  const { events = [] } = await storeGet("events");
  events.push({ type, occurredAt: new Date().toISOString(), meta });
  await storeSet({ events: events.slice(-500) });
}

async function loadState() {
  const today = dateStr();
  const data = await storeGet([
    "kabbalot",
    "sprint",
    "treasureMinutes",
    "achievements",
    "events",
    `usage:${today}`,
    releasedKey(today),
  ]);
  return {
    today,
    kabbalot: data.kabbalot || [],
    sprint: data.sprint || null,
    treasureMinutes: data.treasureMinutes || 0,
    achievements: data.achievements || [],
    // The journal is read here for one reason: M-03/M-04 count consecutive
    // fall days and M-05 names the streak that ended, and neither number is
    // a stored field — both are derived from `fall`/`day_success` entries
    // (morning-after-model.js). Without this key the screen could only ever
    // reach M-01 and M-02, which is exactly what this popup could do before.
    events: data.events || [],
    usageToday: data[`usage:${today}`] || {},
    // issue #87 — a released day releases every kabbalah (⚑13), so the home
    // screen has to stop counting for the rest of it: summarizeKabbalah()
    // and renderHeader() below both read this one answer instead of each
    // computing it (or not) on their own. releasedKey() is defined further
    // down in this file's valve section but hoisted, like every function
    // declaration; loadState() runs after DOMContentLoaded, well after the
    // whole file has been parsed.
    released: Boolean(data[releasedKey(today)]),
  };
}

// ---------- helpers ----------

// Kept for docs/messages.md's own variable table ("{{ברכה לפי שעה}} … הפונקציה
// קיימת ב-extension/popup.js") — that table describes the notification
// engine (not yet wired, a different issue), which already points here as
// the implementation. Not called by this screen's own header text, which
// DESIGN.md §6.2 does not give a time-of-day greeting to.
function greetingByHour() {
  const h = new Date().getHours();
  if (h < 12) return "בוקר טוב";
  if (h < 17) return "צהריים טובים";
  return "ערב טוב";
}

// fmt(m) — DESIGN.md §7.2. The remainder is "ו־{r} דק׳" (abbreviated),
// not "דקות" — a small correction from the pre-v3 file, which spelled the
// word out in full.
function minutesToHebrew(m) {
  const h = Math.floor(m / 60);
  const mm = m % 60;
  const hoursWord = h === 1 ? "שעה" : h === 2 ? "שעתיים" : `${h} שעות`;
  if (h === 0) return `${mm} דקות`;
  if (mm === 0) return hoursWord;
  return `${hoursWord} ו־${mm} דק׳`;
}

const DAY_NAMES = ["א", "ב", "ג", "ד", "ה", "ו", "ש"];

function windowDaysLabel(days) {
  return (days || [])
    .slice()
    .sort()
    .map((d) => `${DAY_NAMES[d]}׳`)
    .join(" ");
}

function minutesNowPop(d = new Date()) {
  return d.getHours() * 60 + d.getMinutes();
}
function parseClockPop(str) {
  const [h, m] = String(str).split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}
// Mirrors background.js's ruleWindowActive/activeWindow. The engine
// (background.js) is the one place that actually enforces a window; this is
// a second, small copy of the same day/time math so the popup can answer
// the question without importing it. Same "no shared module, this project
// has no build step" shape every file here already lives with (see
// content.js's own window-rule copy for the precedent).
//
// It used to be read-only, for display only. Since issue 130 it also gates
// a control: showQuietHours() below asks it whether a quiet window is
// running right now, and hides the removal button's teeth if it is. So it
// is now held to the engine's answer by a test rather than trusted —
// she-cannot-delete-the-hour-she-is-inside.mjs runs this function and the
// engine's activeWindow over every minute of a week and fails if they part
// ways. dashboard-model.js's quietWindowActive() is the third copy of the
// same rule, pinned by the same file, for the board's own settings screen.
// Change one, change all three.
function ruleWindowActiveNow(rule, now = new Date()) {
  // The engine's own first line (activeWindow: `if (!w || !w.from || !w.to)
  // continue;`), which this copy was missing — caught by
  // she-cannot-delete-the-hour-she-is-inside.mjs the moment the two were
  // run side by side. Without it a record with no hours on it reads as
  // ACTIVE ALL DAY: parseClockPop(undefined) is 0, so `to <= from` holds,
  // the overnight branch is taken, and `mins >= 0` is true every minute of
  // any day the record names. Harmless while this only described her
  // standing in a sentence; not harmless now that it decides whether a
  // removal button works, because a malformed stored window would have
  // become permanently undeletable. A rule with no hours is not a window
  // she is inside.
  if (!rule || !rule.from || !rule.to) return false;
  const day = now.getDay();
  const mins = minutesNowPop(now);
  const from = parseClockPop(rule.from);
  const to = parseClockPop(rule.to);
  const overnight = to <= from;
  const startedToday = (rule.days || []).includes(day);
  const startedYesterday = (rule.days || []).includes((day + 6) % 7);
  if (!overnight) return startedToday && mins >= from && mins < to;
  return (startedToday && mins >= from) || (startedYesterday && mins < to);
}

// The Hebrew list join for {{קבלות_עומדות}} used to live here as a second,
// untested copy of morning-after-model.js's standingListPhrase(). The two
// disagreed past three names — this one said "״א״, ״ב״ ו״ג״ ועוד 1", the
// model says "״א״, ״ב״, ״ג״ ועוד 1" — and only the model's reading was ever
// covered by a test. docs/messages.md's rule ("מעל שלוש: שלוש ואז ״ועוד
// {{k}}״") can honestly be read either way; the tested one wins here rather
// than a coin toss, and the ambiguity is flagged for Sara rather than
// settled by this file. There is now one implementation, in the model.

// ---------- per-kabbalah summary (the heart of the multi-kabbalah list) ----------

// What her standing is *today*, in her own words — never the raw domains
// in `k.places` (the cultural red line above). A quota kabbalah is judged
// against today's measured usage; a window kabbalah has no quota to spend,
// only hours it applies on, so its line describes the hours instead. The
// window-rule sentence below has no approved copy anywhere (§7 / messages.md
// only cover the block-overlay wording for this, not a popup summary line)
// — flagged, kept deliberately plain and neutral rather than invented.
// issue #87 — the shortest existing line for "the day is released," pulled
// from MESSAGE_BANK.valve.moments.released (group 8, moment 4's chosen
// proposal) rather than typed here: that moment's full text is a two-line
// release-confirmation screen — currently "היום נסגר. נתחיל מחדש מחר,
// ואני כאן בבוקר" (moment 4ב׳) — written for the valve's own "released"
// screen, not a one-line card or header state. No suitable *card-level*
// moment exists in the bank, so this extracts the moment's own first
// sentence rather than inventing new Hebrew — flagged in the report for
// Sara to rule on. Whichever proposal is wired, this same first sentence
// now drives BOTH the home card and the header (see docs/messages.md,
// moment 4's own note) — a future swap changes both at once.
function releasedStateText() {
  const copy = window.MESSAGE_BANK?.valve?.moments?.released;
  // The fallback for when the bank itself failed to load (a build gap, not
  // her doing — see the !copy branches elsewhere in this file) must say
  // the same words the normal path currently extracts, not an
  // independently-typed alternative: a reader hitting this path by
  // accident must not see different copy than the one moment 4 actually
  // ships. Kept in sync by a-released-day-is-not-counted-on-her-list.mjs,
  // which asserts this literal string still equals a fresh extraction from
  // the live bank — so a future proposal swap that forgets to update this
  // line fails the suite instead of shipping silently, the way this one did.
  const fallback = "היום נסגר.";
  if (!copy?.text) return fallback;
  const firstSentence = copy.text.split(".")[0]?.trim();
  return firstSentence ? `${firstSentence}.` : fallback;
}

function summarizeKabbalah(k, state) {
  // issue #87 — a released day releases every kabbalah (⚑13), the window
  // rule's own "quiet hours" line included: neither a quota card's
  // remaining minutes nor "עכשיו זה השעות השקטות שלה" means anything today.
  // This has to come before the window/quota branches below, not after —
  // the bug this guards was exactly a window kabbalah still showing itself
  // as blocking on a day nothing is blocked.
  if (state.released) {
    return { stateText: releasedStateText(), stateClass: "done" };
  }
  if (k.rule?.kind === "window") {
    const range = `${k.rule.from}–${k.rule.to}`;
    const active = ruleWindowActiveNow(k.rule);
    return {
      stateText: active
        ? `עכשיו זה השעות השקטות שלה — ${range}`
        : `שקטה בימים ${windowDaysLabel(k.rule.days)} · ${range}`,
      stateClass: active ? "soon" : "",
    };
  }
  const limit = k.rule?.limitMinutes || 0;
  const usedSeconds = (k.places || []).reduce(
    (sum, p) => sum + (state.usageToday[p] || 0),
    0
  );
  const usedMin = Math.round(usedSeconds / 60);
  const remaining = Math.max(limit - usedMin, 0);
  if (remaining === 0) {
    // §6.2/§6.3's own approved headline, reused here verbatim.
    return { stateText: "סיימת את הזמן שקבעת לעצמך להיום.", stateClass: "done" };
  }
  return {
    // Adapted from the approved notification fragment "נשארו לך X מהקבלה
    // של היום" (§6.5) — "מהקבלה" is dropped because the card's own name
    // above it already says whose time this is.
    stateText: `נשארו לך ${minutesToHebrew(remaining)} היום`,
    stateClass: remaining <= 10 ? "soon" : "",
  };
}

function kabStreakHtml(k) {
  if (!k.streak) {
    return `<div class="kab-streak">היום הראשון מתחיל עכשיו</div>`;
  }
  const dots = "●".repeat(Math.min(k.streak, 6));
  const word = k.streak === 1 ? "יום אחד ברצף" : `${k.streak} ימים ברצף`;
  return `<div class="kab-streak"><span class="dots" dir="ltr">${dots}</span> ${word}</div>`;
}

// A long name is a real case this build has to survive (see the report):
// the name truncates with an ellipsis (popup.css's .kab-name) and the full
// text is still reachable through the native `title` tooltip.
// issue #94: with exactly one kabbalah, renderHomeScreen()'s own footer
// keeps the single "הגדרות הקבלה" link it always had (now pointed at that
// kabbalah's id explicitly instead of implicitly). With more than one, a
// shared footer link cannot say which kabbalah it means, so each card gets
// its own — gated the same way, by canEditPlacesViaOnboarding(k), see this
// file's header, judgment call 4.
function kabCardHtml(k, state) {
  const summary = summarizeKabbalah(k, state);
  const badge =
    k.mode === "commitment" ? `<span class="badge">מצב מחויבות</span>` : "";
  const name = escapeHtml(kabbalahLabel(k));
  const editHtml =
    state.kabbalot.length > 1 && canEditPlacesViaOnboarding(k)
      ? `<button class="btn-link muted" data-edit-kabbalah="${k.id}">הגדרות הקבלה</button>`
      : "";
  return `
    <div class="kab-card">
      <div class="kab-name-row">
        <span class="kab-name" title="${name}">${name}</span>
        ${badge}
      </div>
      <div class="kab-state ${summary.stateClass}">${summary.stateText}</div>
      ${kabStreakHtml(k)}
      ${editHtml}
    </div>`;
}

// ---------- header (DESIGN.md §6.2) ----------

function renderHeader(state) {
  // issue #87 — same guard as summarizeKabbalah() above: a released day
  // stops the "עמדת ב-X מתוך Y" / streak counting the header would
  // otherwise still show.
  if (state.released) {
    return `
      <header class="pop-header">
        <div class="greeting-line">${releasedStateText()}</div>
        <img class="char-cheer" src="character/v3/cheer.png" alt="" />
      </header>`;
  }
  const total = state.kabbalot.length;
  const kept = state.kabbalot.filter((k) => k.fellOn !== state.today).length;

  let line;
  if (total > 1) {
    // §6.2, §8 decision 4, verbatim example: "עמדת ב-2 מתוך 3".
    line = `עמדת ב-${kept} מתוך ${total}`;
  } else {
    const streak = state.kabbalot[0].streak || 0;
    line =
      streak > 0
        ? `את כבר <span class="streak-num" dir="ltr">${streak}</span> ${
            streak === 1 ? "יום אחד" : "ימים"
          } ברצף עומדת בקבלה שלך. כל הכבוד`
        : "היום הראשון של הקבלה שלך מתחיל עכשיו";
  }

  return `
    <header class="pop-header">
      <div class="greeting-line">${line}</div>
      <img class="char-cheer" src="character/v3/cheer.png" alt="" />
    </header>`;
}

// ---------- "קבלה של עכשיו" — active mini-commitments that grow the treasure ----------

let sprintTimer = null;

function renderSprintSection(sprint) {
  if (sprint && Date.now() < sprint.until) {
    return `
      <div class="sprint sprint-active">
        <div class="sprint-title">קבלה של עכשיו</div>
        <div class="sprint-count" id="sprint-count" dir="ltr"></div>
        <div class="sprint-track"><div class="sprint-fill" id="sprint-fill"></div></div>
        <div class="sprint-sub">את באמצע ${minutesToHebrew(sprint.minutes)} של קבלה. מחזיקה חזק.</div>
        <button class="btn-link muted" id="sprint-cancel">מוותרת הפעם, בלי דרמה</button>
      </div>`;
  }
  return `
    <div class="sprint">
      <div class="sprint-title">מקבלת על עצמי עכשיו</div>
      <div class="sprint-sub">זמן קצר בלי המקום הזה, והוא נכנס לאוצר שלך</div>
      <div class="chip-row sprint-chips">
        <button class="chip" data-m="15">רבע שעה</button>
        <button class="chip" data-m="30">חצי שעה</button>
        <button class="chip" data-m="60">שעה</button>
      </div>
    </div>`;
}

function startSprintTicker(sprint) {
  clearInterval(sprintTimer);
  const total = sprint.minutes * 60 * 1000;

  const tick = async () => {
    const left = sprint.until - Date.now();
    if (left <= 0) {
      clearInterval(sprintTimer);
      await grantSprintPopupSide(sprint);
      return;
    }
    const m = Math.floor(left / 60000);
    const s = Math.floor((left % 60000) / 1000);
    const countEl = document.getElementById("sprint-count");
    const fillEl = document.getElementById("sprint-fill");
    if (countEl) countEl.textContent = `${m}:${String(s).padStart(2, "0")}`;
    if (fillEl) fillEl.style.width = `${(left / total) * 100}%`;
  };
  tick();
  sprintTimer = setInterval(tick, 1000);
}

async function grantSprintPopupSide(sprint) {
  const { sprint: current, treasureMinutes = 0 } = await storeGet([
    "sprint",
    "treasureMinutes",
  ]);
  if (current && current.until === sprint.until) {
    await journalEvent("sprint_success", { minutes: sprint.minutes });
    await storeSet({
      sprint: null,
      treasureMinutes: treasureMinutes + sprint.minutes,
    });
  }
  showSprintSuccess(sprint.minutes);
}

function showSprintSuccess(minutes) {
  const main = document.getElementById("main");
  main.innerHTML = `
    <div class="aux-screen">
      <img class="aux-char" src="character/v3/cheer.png" alt="" />
      <div class="aux-title">עמדת בזה!</div>
      <div class="aux-lead">${minutesToHebrew(minutes)} נכנסו לאוצר שלך</div>
      <div class="aux-hint">קבלה קטנה שעמדת בה שווה יותר מאלף החלטות גדולות</div>
      <div class="aux-actions"><button class="btn-primary sm" id="go-home">לדף הבית שלי</button></div>
    </div>`;
  document.getElementById("go-home").addEventListener("click", showHome);
}

function wireSprintSection() {
  document.querySelectorAll(".sprint-chips .chip").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const minutes = Number(btn.dataset.m);
      await storeSet({
        sprint: { minutes, until: Date.now() + minutes * 60 * 1000 },
      });
      await showHome();
    });
  });
  const cancel = document.getElementById("sprint-cancel");
  if (cancel) {
    cancel.addEventListener("click", async () => {
      await journalEvent("sprint_broken", { cancelled: true });
      await storeSet({ sprint: null });
      await showHome();
    });
  }
}

// ---------- empty state (fresh install, before onboarding) ----------
// No approved copy exists for an empty popup specifically (§7 / messages.md
// are both written assuming a kabbalah already exists). Rather than invent
// a new welcome line, this reuses the onboarding's own approved opening —
// h1, lead and button, §6.1 step 0 / §7 — verbatim, since that is exactly
// where the button leads. Flagged as a judgment call, not a fabrication.
function renderEmptyScreen() {
  return `
    <div class="aux-screen">
      <img class="aux-char" src="character/v3/present.png" alt="" />
      <div class="aux-title">בואי נגדיר יחד קבלה אחת — קטנה, שתחזיק.</div>
      <div class="aux-lead">שלוש שאלות, פחות משלוש דקות. הכל נשאר אצלך במחשב.</div>
      <div class="aux-actions">
        <button class="btn-primary sm" id="start-onboarding">מתחילות ←</button>
      </div>
    </div>`;
}

// ---------- the morning after a fall (DESIGN.md §6.7, docs/messages.md group 3) ----------
//
// THIS IS THE ONLY DOOR. It used to be one of two: issue #19 also shipped a
// full extension page (morning-after.html) that background.js opened by
// itself, in a new tab, on the first service-worker wake after a fall. That
// tab is gone — background.js's syncFallBadge carries the whole argument —
// and the page's richer half came here, into morning-after-model.js, which
// this screen renders. What she gets now: she opens the popup herself, and
// the moment is waiting inside it. Nothing appears on screen that she did
// not ask for.
//
// §6.7 already specified this screen at 360px, the popup's own width, and
// popup.css's `.aux-screen` block is written against that spec — so this is
// the width the design was drawn for, not a squeeze.
//
// M-01 through M-05 all live here now (the tab knew M-03/M-04/M-05; this
// screen only knew M-01/M-02), and so do the two after-states M-07 and M-08.

// Whether the "ease" button can be offered without doing harm.
//
// issue #94 (was FLAGGED FOR SARA above): this used to require the fallen
// kabbalah to BE `allKabbalot[0]`, because onboarding.js could only ever
// edit `kabbalot[0]` and had no way to be told otherwise. onboarding.js has
// known `?edit=<id>` since issue #20, and openOnboarding() above now passes
// it, so the position-in-the-array restriction is gone: "להקל" reaches the
// kabbalah that actually fell, whichever one that is.
//
// What replaces it is the same guard dashboard.js already applies before it
// offers its own edit link: onboarding-model.js's
// canEditPlacesViaOnboarding(). A kabbalah with a "corner" place (a path
// narrowed on the dashboard, e.g. site.example/corner) cannot round-trip
// through onboarding's link field — see that function's own comment — so
// onboarding.js refuses to load it for editing and falls back to a blank
// form on `kabbalot[0]` instead. Offering "להקל" for such a kabbalah would
// walk her straight into that silent fallback, which is exactly the bug
// this issue is about, reached a different way. Gating on the same check
// dashboard.js uses keeps that path closed.
function canEaseFor(choice, allKabbalot) {
  const k = allKabbalot.find((x) => x.id === choice.kabbalahId);
  return !!(k && canEditPlacesViaOnboarding(k));
}

function renderRecoveryScreen(choice, allKabbalot) {
  // window.MESSAGE_BANK is chat-bridge.js's (see the file header, judgment
  // call 5); only a released day (issue #87) reads it here.
  const msg = buildMorningAfterMessage(choice, escapeHtml, window.MESSAGE_BANK?.valve);

  // M-01's lines carry its own bold second sentence and its own question
  // sentence; every other id renders as plain lines, same size, same colour
  // (morning-after-model.js's judgment calls 1 and 2).
  const linesHtml = msg.lines.map((l) => `<div class="aux-lead">${l}</div>`).join("");
  const emphHtml = msg.emph ? `<div class="aux-lead"><b>${msg.emph}</b></div>` : "";
  const questionHtml = msg.question
    ? `<div class="aux-hint">${msg.question}</div>`
    : "";

  return `
    <div class="aux-screen">
      <img class="aux-char" src="character/v3/heart.png" alt="" />
      ${linesHtml}${emphHtml}${questionHtml}
      <div class="aux-actions">
        <button class="btn-primary sm" id="restart">מתחילה מחדש</button>
        ${
          canEaseFor(choice, allKabbalot)
            ? `<button class="btn-quiet block" id="adjust">להקל על הקבלה — לתכנון מחדש ←</button>`
            : ""
        }
      </div>
    </div>`;
}

// §6.7, after "מתחילה מחדש": M-07, verbatim, and a quiet link back to her
// list. "← חזרה" is DESIGN.md §3.1's own documented quiet-link example for
// exactly this step-back role — reused rather than writing a new word for
// "done". The choice is already final by the time this shows (ackMorningAfter
// has already run). FLAGGED FOR SARA: §6.7 asks for "a quiet .btn-link" here
// without naming its label, so the label is borrowed, not approved for this
// spot.
function renderRestarted() {
  return `
    <div class="aux-screen">
      <img class="aux-char" src="character/v3/heart.png" alt="" />
      <div class="aux-lead">${MORNING_AFTER_RESTARTED}</div>
      <div class="aux-actions">
        <button class="btn-link" id="ma-done">← חזרה</button>
      </div>
    </div>`;
}

// §6.7, after "להקל על הקבלה": M-08, verbatim, the primary button §6.7 names
// ("למסך האונבורדינג ←"), and a quiet way back. Nothing is committed at this
// point — the acknowledgement happens on the button that actually leaves —
// so "← חזרה" genuinely undoes.
function renderEase() {
  return `
    <div class="aux-screen">
      <img class="aux-char" src="character/v3/heart.png" alt="" />
      <div class="aux-lead">${MORNING_AFTER_EASE}</div>
      <div class="aux-actions">
        <button class="btn-primary sm" id="ma-onboarding">למסך האונבורדינג ←</button>
        <button class="btn-link" id="ma-back">← חזרה</button>
      </div>
    </div>`;
}

// Her choice, written back exactly the way the deleted page wrote it: every
// kabbalah this one message spoke for gets `fallAcked: true`, and each gets
// one `morning_after_choice` entry in the shared journal — issue #19's own
// "מדד הקימה תוך 48 שעות". The popup used to flip fallAcked and record
// nothing at all, so a woman who answered here was invisible to that metric;
// that gap closes with the merge.
//
// Every id in `choice.acks`, not just the one the message named: one rising
// message a day speaks for the whole morning (morning-after-model.js's
// chooseMorningAfter explains the rule). This is also what makes
// acknowledging settle it everywhere — the badge in background.js watches
// the same field, so it clears on this write without being told.
async function ackMorningAfter(choice, choiceLabel) {
  const { kabbalot = [], events = [] } = await storeGet(["kabbalot", "events"]);
  const acked = new Set(choice.acks);
  for (const k of kabbalot) if (acked.has(k.id)) k.fallAcked = true;
  const entries = choice.acks.map((id) => ({
    type: "morning_after_choice",
    occurredAt: new Date().toISOString(),
    kabbalahId: id,
    meta: { choice: choiceLabel, message: choice.id },
  }));
  await storeSet({ kabbalot, events: [...events, ...entries].slice(-500) });
}

function wireRecoveryScreen(choice, allKabbalot) {
  const main = document.getElementById("main");

  document.getElementById("restart").addEventListener("click", async () => {
    await ackMorningAfter(choice, "restart");
    main.innerHTML = renderRestarted();
    document.getElementById("ma-done").addEventListener("click", showHome);
  });

  const adjustBtn = document.getElementById("adjust");
  if (!adjustBtn) return;
  adjustBtn.addEventListener("click", () => {
    main.innerHTML = renderEase();
    document.getElementById("ma-onboarding").addEventListener("click", async () => {
      await ackMorningAfter(choice, "ease");
      openOnboarding(choice.kabbalahId);
    });
    document.getElementById("ma-back").addEventListener("click", () => {
      main.innerHTML = renderRecoveryScreen(choice, allKabbalot);
      wireRecoveryScreen(choice, allKabbalot);
    });
  });
}

// ---------- home: the multi-kabbalah list (§8 decision 4) ----------

function renderHomeScreen(state) {
  const stationBanners = state.kabbalot
    .filter((k) => k.pendingStation)
    .map(
      (k) => `
        <button class="station-banner" data-station="${k.id}">
          הגעת לתחנה במסע ב״${escapeHtml(kabbalahLabel(k))}״ <span>לפתיחה</span>
        </button>`
    )
    .join("");

  const cards = state.kabbalot.map((k) => kabCardHtml(k, state)).join("");

  const listHeading =
    state.kabbalot.length > 1
      ? `<div class="section-title">הקבלות הפעילות שלך</div>`
      : "";

  // With exactly one kabbalah the footer keeps its own single link (each
  // card's own link, kabCardHtml() above, only appears once there is more
  // than one to tell apart). Still gated by canEditPlacesViaOnboarding — see
  // the file header, judgment call 4.
  const soleKabbalah = state.kabbalot.length === 1 ? state.kabbalot[0] : null;
  const editLink =
    soleKabbalah && canEditPlacesViaOnboarding(soleKabbalah)
      ? `<button class="btn-link muted" data-edit-kabbalah="${soleKabbalah.id}">הגדרות הקבלה</button><span>·</span>`
      : "";

  // The treasure and the collection are global, not per-kabbalah — one
  // shared time-bank, one shared board of station achievements
  // (docs/data-model.md). Both are real, accumulated things she can see
  // building up; dropping them from the list view would be exactly the
  // kind of silent loss this rewrite was warned against.
  const treasureHtml =
    state.treasureMinutes > 0
      ? `<div class="treasure-strip">באוצר שלך <span class="num">${minutesToHebrew(
          state.treasureMinutes
        )}</span> של עמידה בקבלה</div>`
      : "";
  const collectionHtml = state.achievements.length
    ? `<div class="collection">${state.achievements
        .map((a) => `<span>${a.symbol}</span>`)
        .join("")}<span class="collection-label">מהתחנות שעברת</span></div>`
    : "";

  return `
    ${renderHeader(state)}
    <div class="pop-body">
      ${stationBanners}
      ${listHeading}
      <div class="kab-list">${cards}</div>
      ${treasureHtml}
      ${collectionHtml}
      ${renderSprintSection(state.sprint)}
      <button class="btn-pink-soft" id="help-btn">קשה לי עכשיו</button>
      <div class="pop-footer" id="footer-links">
        ${editLink}
        <button class="btn-link muted" id="open-dashboard">הלוח שלך</button>
        <span>·</span>
        <button class="btn-link muted" id="quiet-hours">שעות קבועות</button>
        <span>·</span>
        <button class="btn-link muted" id="open-export">ייצוא נתונים</button>
        <span>·</span>
        <button class="btn-link muted" id="reset-all">התחלה מחדש</button>
      </div>
    </div>`;
}

function wireHomeScreen(state) {
  document.querySelectorAll("[data-station]").forEach((btn) =>
    btn.addEventListener("click", () => showStation(btn.dataset.station))
  );

  // issue #94: one wiring covers both the footer's single link (sole
  // kabbalah) and each card's own link (more than one) — both carry the
  // kabbalah id to edit on `data-edit-kabbalah`, never openOnboarding()
  // called blind.
  document.querySelectorAll("[data-edit-kabbalah]").forEach((btn) =>
    btn.addEventListener("click", () => openOnboarding(btn.dataset.editKabbalah))
  );
  document.getElementById("open-dashboard").addEventListener("click", openDashboard);
  document.getElementById("quiet-hours").addEventListener("click", showQuietHours);
  document.getElementById("open-export").addEventListener("click", openExport);
  document.getElementById("reset-all").addEventListener("click", showResetConfirm);

  wireSprintSection();
  if (state.sprint && Date.now() < state.sprint.until) {
    startSprintTicker(state.sprint);
  }

  const helpBtn = document.getElementById("help-btn");
  if (helpBtn) {
    helpBtn.addEventListener("click", async () => {
      // Journal the click locally. How often she reaches for this is worth
      // knowing; the number that would make it good or bad is not ours to
      // invent, and no product document has ever set one.
      await journalEvent("help_click");
      // issue #87 — a valve she already accepted today is where every press
      // lands (never re-asked); the third press of a day skips the chat.
      if (await pendingValve()) {
        showValve();
        return;
      }
      if (!(await dayReleasedToday()) && (await valveChatsClosedToday()) >= VALVE_IMMEDIATE_AT - 1) {
        showValveImmediate();
        return;
      }
      showConversation();
    });
  }
}

// ---------- the router every screen returns to ----------

async function showHome() {
  const state = await loadState();
  const main = document.getElementById("main");

  if (!state.kabbalot.length) {
    main.innerHTML = renderEmptyScreen();
    // No kabbalah exists yet to hand an id for — the one caller of
    // openOnboarding() with none. Wrapped in an arrow rather than passed
    // bare: addEventListener hands its listener the click Event as the
    // first argument, which would otherwise become `kabbalahId` above.
    document
      .getElementById("start-onboarding")
      .addEventListener("click", () => openOnboarding());
    return;
  }

  // The moment of truth (PRD §3.4): the system never goes silent after a
  // fall. This screen comes before the list, every time she opens the popup,
  // until she has answered it — which is the whole of how she finds it now
  // that nothing opens a tab at her.
  //
  // One message, however many kabbalot fell. This used to loop — pick the
  // first unacknowledged kabbalah, and after she answered, re-run and find
  // the next — which put two rising messages in front of her on a morning
  // two commitments broke. docs/messages.md group 3 forbids exactly that
  // ("אף פעם לא שתי הודעות קימה באותו יום"), and the approved copy is
  // already written for the whole morning at once: M-02 names the fallen one
  // and the standing ones, and M-01 is annotated "וגם המקרה שכל הקבלות
  // נשברו". So one message speaks for all of them, and answering it settles
  // all of them (see ackMorningAfter).
  const choice = chooseMorningAfter(state.kabbalot, state.events);
  if (choice) {
    main.innerHTML = renderRecoveryScreen(choice, state.kabbalot);
    wireRecoveryScreen(choice, state.kabbalot);
    return;
  }

  // issue #87 — a valve she accepted today is where she lands, before the
  // list: "כשהיא חוזרת — זה מחכה לה". One quiet link leads to the list.
  // After the morning-after screen on purpose: an unanswered morning is
  // the product's one standing promise, and it is older than any valve.
  // Skipped once she has already used that quiet link this popup session
  // (valveDismissedThisSession) — otherwise every ordinary "go home" click
  // elsewhere in the popup would loop straight back to the valve and she
  // could never actually reach her list while it waits.
  if (!valveDismissedThisSession && (await pendingValve())) {
    await showValve();
    return;
  }

  main.innerHTML = renderHomeScreen(state);
  wireHomeScreen(state);
}

// ---------- reset (issue #46, pilot blocker) ----------
//
// The reset button used to call storeClear() straight from the click — no
// confirmation, no way back. One stray tap during the pilot erased a
// tester's whole history. The fix (kept exactly, only restyled here): the
// delete control does not exist on screen until she has typed the word
// "איפוס" into this panel — real deliberation, not one more click to
// reflex through. The button itself is now labelled "התחלה מחדש" —
// "(לבדיקות)" had no business being read by a real pilot tester. The word
// she must type to confirm is unchanged; it is written out in full in the
// warning text below, not implied by the button's label, so the two never
// needed to match. scripts/package-extension.mjs greps this function by
// name, and
// extension/tests/a-stray-click-does-not-erase-the-pilot.mjs fails if the
// gating logic below changes — see that file for a mutation proof of
// exactly the regression this guards against.
function showResetConfirm() {
  const footer = document.getElementById("footer-links");
  if (!footer) return;

  footer.innerHTML = `
    <div class="reset-confirm">
      <p class="reset-confirm-warn">הפעולה הזו מוחקת את כל הנתונים שנשמרו כאן, ואי אפשר להחזיר אותם. כדי להמשיך, הקלידי כאן את המילה ״איפוס״.</p>
      <input type="text" id="reset-confirm-input" class="reset-confirm-input" autocomplete="off" aria-label="הקלידי את המילה איפוס לאישור המחיקה" />
      <div class="reset-confirm-actions" id="reset-confirm-actions">
        <button class="btn-link muted" id="reset-confirm-cancel">בעצם, לא</button>
      </div>
    </div>`;

  document.getElementById("reset-confirm-cancel").addEventListener("click", showHome);

  const input = document.getElementById("reset-confirm-input");
  const actions = document.getElementById("reset-confirm-actions");
  input.addEventListener("input", () => {
    const existing = document.getElementById("reset-confirm-go");
    const typedMatch = input.value.trim() === "איפוס";
    if (typedMatch && !existing) {
      const goBtn = document.createElement("button");
      goBtn.className = "btn-quiet sm reset-confirm-go";
      goBtn.id = "reset-confirm-go";
      goBtn.textContent = "כן, איפוס סופי";
      goBtn.addEventListener("click", async () => {
        await storeClear();
        showHome();
      });
      actions.appendChild(goBtn);
    } else if (!typedMatch && existing) {
      existing.remove();
    }
  });
  input.focus?.();
}

// ---------- שעות קבועות ----------
// A fixed hour is a commitment of a different kind from a daily quota: not
// "how much" but "when". The screen has to let her say it in one breath —
// which days, from when to when.
//
// There used to be a second question here too — a chip asking whether the
// hour applied "only where there is a kabbalah" or to the whole browser.
// #37 deleted it: the engine could only ever test "is this page inside
// *some* kabbalah", a plain boolean with no identity in it, so a woman with
// two kabbalot who meant to quiet one of them was silently quieting both,
// and the stop page could never say why. Any window here is browser-wide
// now, full stop — a woman who wants an hour on one specific place already
// has the right tool for that, a kabbalah with a window rule (#13).
let draftDays = [0, 1, 2, 3, 4];

// UNAPPROVED · issue 130, Sara's ruling of 2026-08-30 ("אני רוצה שלא תהיה
// אפשרות לעזוב את זה בזמן שזה חסום"). Hours that are stopping her right now
// cannot be removed until they end; every other window, and this one at
// every other hour, stays one click away, and adding is untouched.
//
// THE SAME SENTENCE, VERBATIM, as dashboard.js's DASH_COPY.quietRemoveHeld
// — deliberately, because the two screens edit ONE list and a woman who
// meets this rule in the popup and then again on the board must not be told
// two different things about it. dashboard.js carries the full note on why
// each half of it is worded the way it is, and it is Sara's to approve or
// replace in BOTH files at once. she-cannot-delete-the-hour-she-is-inside.mjs
// renders both screens and fails if the two sentences ever differ.
const QUIET_HELD_REASON =
  "השעות האלה פעילות עכשיו, ואי אפשר להסיר אותן עד שייגמרו. אם קשה לך ברגע הזה, ״קשה לי עכשיו״ כאן בשבילך.";

function renderWindowLine(w, i, now) {
  const days = (w.days || [])
    .slice()
    .sort()
    .map((d) => `${DAY_NAMES[d]}׳`)
    .join(" ");
  // A disabled button and a visible reason, not a button that silently
  // does nothing: the comment at the send button further down is right that
  // this product has no greyed-out states as a rule, and this row is the
  // one place the issue asks for the exception in as many words ("כפתור
  // מושבת בלי סיבה נקרא כתקלה. צריך משפט קצר"). aria-describedby ties the
  // two together so a screen reader is told why, not only that.
  const held = ruleWindowActiveNow(w, now);
  const reasonId = `window-held-${i}`;
  return `<div class="window-line${held ? " held" : ""}">
      <div class="window-when" dir="ltr">${w.from}–${w.to}</div>
      <div class="window-meta">בימים ${days} · בכל הדפדפן</div>
      <button class="btn-link muted" data-remove="${i}"${
        held ? ` disabled aria-describedby="${reasonId}"` : ""
      }>הסרה</button>
      ${held ? `<p class="window-held" id="${reasonId}">${QUIET_HELD_REASON}</p>` : ""}
    </div>`;
}

// UNAPPROVED · Sara's live Chrome test, 2026-08-26: the add button used to
// read "הוספת השעות האלה" and she could not tell what pressing it would do.
// It appends the current form (days + from/to) as one more window onto her
// list, never replacing what is already saved — "לרשימה" names that. Full
// audit trail in dashboard.js, which renders the identical string.
async function showQuietHours() {
  const main = document.getElementById("main");
  const { quietWindows = [] } = await storeGet(["quietWindows"]);

  main.innerHTML = `
    <div class="quiet-screen">
      <div class="aux-title">שעות קבועות</div>
      <div class="section-sub">לא כמה — אלא מתי</div>
      <p class="quiet-intro">
        יש שעות שבהן את פשוט לא שם. כאן את קובעת אותן מראש, ואין צורך במונה.
      </p>
      ${(() => {
        // One clock for the whole list, read once, so two rows drawn in the
        // same paint are never judged by two different minutes.
        const now = new Date();
        return quietWindows.map((w, i) => renderWindowLine(w, i, now)).join("");
      })()}
      <div class="window-form">
        <div class="day-row">
          ${DAY_NAMES.map(
            (n, i) =>
              `<button class="chip day-chip${
                draftDays.includes(i) ? " on" : ""
              }" data-day="${i}">${n}׳</button>`
          ).join("")}
        </div>
        <div class="time-row">
          <label>מהשעה <input type="time" id="from-time" step="900" value="16:00" /></label>
          <label>עד <input type="time" id="to-time" step="900" value="18:00" /></label>
        </div>
        <p class="scope-note">
          ״בכל הדפדפן״ הוא כל האתרים בדפדפן הזה. תוסף לא יכול לחסום תוכנות
          אחרות או דפדפן אחר.
        </p>
        <button class="btn-primary" id="add-window">הוספת השעות האלה לרשימה</button>
      </div>
      <div class="pop-footer">
        <button class="btn-link muted" id="quiet-back">חזרה לדף הבית</button>
      </div>
    </div>`;

  main.querySelectorAll(".day-chip").forEach((btn) =>
    btn.addEventListener("click", () => {
      const d = Number(btn.dataset.day);
      draftDays = draftDays.includes(d)
        ? draftDays.filter((x) => x !== d)
        : [...draftDays, d];
      btn.classList.toggle("on");
    })
  );

  main.querySelectorAll("[data-remove]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const i = Number(btn.dataset.remove);
      // Asked again here, and not only at render time (issue 130). A real
      // `<button disabled>` never runs this listener at all, so on the happy
      // path this costs nothing — but a popup left open since before the
      // window opened drew that button live, and the clock has moved since.
      // Redrawing turns the stale row into the held row it should already
      // have been, reason and all.
      if (ruleWindowActiveNow(quietWindows[i] || {}, new Date())) {
        showQuietHours();
        return;
      }
      await storeSet({
        quietWindows: quietWindows.filter((_, idx) => idx !== i),
      });
      showQuietHours();
    })
  );

  document.getElementById("add-window").addEventListener("click", async () => {
    const from = document.getElementById("from-time").value;
    // Same reading dashboard.js's own quiet form gives a closing "00:00":
    // the end of the day, written "24:00". Without it the identical window
    // read "22:00–00:00" here and "22:00–24:00" one screen over, which is
    // two different-looking promises for one stored set of minutes.
    // background.js sees no difference either way (quiet-hours.mjs proves
    // that minute by minute) — this is about the two screens agreeing.
    const to = document.getElementById("to-time").value === "00:00"
      ? "24:00"
      : document.getElementById("to-time").value;
    if (!from || !to || !draftDays.length) return;
    await storeSet({
      quietWindows: [...quietWindows, { days: draftDays, from, to }],
    });
    showQuietHours();
  });

  document.getElementById("quiet-back").addEventListener("click", showHome);
}

// ---------- the station ritual ----------
// Content pool — founder-approved, mature in tone. Rotates by station index.

const STATION_CONTENT = [
  {
    title: "התחנה הראשונה",
    body: "כל דרך ארוכה נמדדת בצעד אחד שחוזר על עצמו. לא בהחלטה הגדולה, אלא בבוקר השני, ובשלישי. הגעת לכאן כי חזרת. זה הכול.",
  },
  {
    title: "מה שנבנה בשקט",
    body: "אף אחד לא ראה את הימים האלה חוץ ממך. בלי מחיאות כפיים, בלי שאף אחד ידע. דווקא הדברים שנבנים בשקט הם אלה שמחזיקים הכי הרבה זמן.",
  },
  {
    title: "על מה שמותר",
    body: "הקושי שלך אף פעם לא היה במה שאסור. הוא במה שמותר וגוזל. ודווקא שם, במקום שאף אחד לא שומר עלייך, בחרת לשמור על עצמך.",
  },
  {
    title: "הזמן שחזר אלייך",
    body: "כל דקה שלא נשאבה חזרה אלייך לחיים האמיתיים. לשיחה, ללימוד, למנוחה אמיתית. לא ויתרת על משהו. קיבלת בחזרה משהו.",
  },
  {
    title: "כשקשה באמצע",
    body: "האמצע הוא החלק שאף אחד לא מספר עליו. ההתחלה מרגשת, הסוף מספק, והאמצע פשוט דורש. את באמצע, ואת עדיין כאן.",
  },
  {
    title: "לא מושלמת. עקבית.",
    body: "לא נדרשת ממך שלמות. נדרשת ממך חזרה. מי שחוזרת אחרי יום פחות טוב, חזקה יותר ממי שמעולם לא נפלה.",
  },
  {
    title: "הרגל שנעשה שלך",
    body: "בהתחלה זו הייתה החלטה שצריך לזכור. עכשיו זה כבר קצת מי שאת. זה הרגע שבו הקבלה מפסיקה להיות מאמץ ומתחילה להיות בית.",
  },
  {
    title: "מכאן ממשיכים",
    body: "הדרך שעברת שייכת לך לתמיד, וגם אם יהיו ימים קשים היא לא נמחקת. תמיד אפשר להמשיך מכאן, אף פעם לא מתחילים מאפס.",
  },
];

// The one deliberate exception to "no emoji" — see the matching exemption in
// extension/tests/the-character-carries-the-warmth.mjs. Issue #57 asked what
// should replace these; Sara decided (2026-08-16) that they stay, and that
// each one must say what its own station says.
//
// They did not, before. The order here matches STATION_CONTENT above, and
// two of those texts name their symbol outright: station 4 is about minutes
// coming back to her and carried a book, station 7 ends on the word בית and
// carried a blossom. A symbol that argues with the paragraph under it makes
// the reader trust the paragraph less, which is expensive on a screen whose
// whole job is to be believed.
const STATION_SYMBOLS = ["🌱", "🧱", "🛡️", "⏳", "⛰️", "🔁", "🏠", "🧭"];

function stationContent(index) {
  return STATION_CONTENT[index % STATION_CONTENT.length];
}

// Takes a kabbalah id (not the whole state) — the multi-kabbalah
// generalisation of what used to reach into kabbalot[0] directly. More than
// one kabbalah can have a pendingStation at once (see the station banners
// on the home screen); this always operates on the one she actually clicked.
async function showStation(kabbalahId) {
  const { kabbalot = [] } = await storeGet("kabbalot");
  const k = kabbalot.find((x) => x.id === kabbalahId);
  if (!k || !k.pendingStation) {
    showHome();
    return;
  }

  const station = k.pendingStation;
  const index = station.index;
  const piece = stationContent(index);
  const symbol = STATION_SYMBOLS[index % STATION_SYMBOLS.length];
  const main = document.getElementById("main");

  main.innerHTML = `
    <div class="station-view">
      <img class="char-cheer" src="character/v3/cheer.png" alt="" />
      <div class="station-symbol">${symbol}</div>
      <div class="station-title">${piece.title}</div>
      <p class="station-body">${piece.body}</p>
      <div class="station-signature">— ${MENTOR_NAME}</div>
      <div class="station-earned">הסמל הזה נשמר באוסף שלך</div>
      <div class="station-ask">איך את מרגישה עם הקבלה עכשיו?</div>
      <div class="choice-row">
        <button class="btn-primary" id="st-keep">ממשיכה כך</button>
        <button class="btn-quiet" id="st-up">מוכנה לשלב קטן למעלה</button>
        <button class="btn-quiet" id="st-down">בא לי להקל קצת</button>
      </div>
    </div>`;

  async function finish(deltaPct) {
    // One write for the whole moment — a popup killed midway can never
    // record a done station without its achievement.
    const { kabbalot: current = [], achievements = [] } = await storeGet([
      "kabbalot",
      "achievements",
    ]);
    const kk = current.find((x) => x.id === kabbalahId);
    if (kk) {
      // A window kabbalah has no limitMinutes to ease or tighten — only a
      // quota kabbalah does. The pre-v3 file never had to guard this
      // because it only ever knew one rule kind.
      if (deltaPct && kk.rule?.kind !== "window") {
        const next = Math.round((kk.rule.limitMinutes * (1 + deltaPct)) / 5) * 5;
        kk.rule.limitMinutes = Math.max(15, next);
      }
      kk.pendingStation = null;
    }
    achievements.push({
      index,
      symbol,
      title: piece.title,
      date: dateStr(),
      kabbalahId: kk?.id ?? null,
    });
    await storeSet({ kabbalot: current, achievements });
    showHome();
  }

  document.getElementById("st-keep").addEventListener("click", () => finish(0));
  document.getElementById("st-up").addEventListener("click", () => finish(-0.1));
  document.getElementById("st-down").addEventListener("click", () => finish(0.1));
}

// ---------- a real conversation with אורה ----------
// Nothing she writes is ever stored, and nothing is ever sent anywhere —
// there is no server to send it to. Every reply now comes from
// docs/messages.md's own "קשה לי עכשיו" bank (issue #17,
// extension/chat-engine.js) instead of a canned line — see the file
// header, judgment call 5, and extension/chat-bridge.js for how
// chat-engine.js's exports and the pre-parsed bank
// (extension/message-bank.generated.js) reach this plain script as
// window.ChatEngine / window.MESSAGE_BANK.
//
// Conversation state (which turn she's on, what's already been said in
// *this* conversation) lives only as long as this one open panel — a
// closure is enough, the same way `history` below already is. The
// per-pool recent-history window that keeps her next conversation from
// repeating this one does need to survive a browser restart
// (chat-engine.js's own documented spec), so that alone is read from and
// written back to chrome.storage.local, under its own key —
// `chatPoolHistory` — after every single turn, not just at the end, so a
// restart mid-conversation still keeps what was said.
const CHAT_FALLBACK_REPLY =
  "אני כאן איתך, גם אם הרגע לא הצלחתי למצוא את המילים. נשימה עמוקה — הקבלה שלך עדיין שלך.";

async function askOra(state, poolHistory) {
  const { text, state: nextState, poolHistory: nextPoolHistory } =
    window.ChatEngine.advanceConversation(window.MESSAGE_BANK, state, poolHistory);
  return { reply: text, state: nextState, poolHistory: nextPoolHistory };
}

function renderChatBubble(role, text) {
  return `<div class="chat-row ${role}"><div class="chat-bubble">${escapeHtml(text)}</div></div>`;
}

async function showConversation() {
  const main = document.getElementById("main");
  const history = [];

  let convState = window.ChatEngine.createConversationState();
  const { chatPoolHistory } = await storeGet("chatPoolHistory");
  let convPoolHistory = chatPoolHistory || window.ChatEngine.createPoolHistory();

  // The opening line is turn 1 of the real bank, picked before she has
  // typed anything — chat-engine.js's own documented shape, not a special
  // case built here. A bank that fails to load or parse still gets her a
  // warm, honest line rather than a blank screen.
  let opening = CHAT_FALLBACK_REPLY;
  try {
    const first = await askOra(convState, convPoolHistory);
    opening = first.reply;
    convState = first.state;
    convPoolHistory = first.poolHistory;
    await storeSet({ chatPoolHistory: convPoolHistory });
  } catch {
    // fall through with CHAT_FALLBACK_REPLY
  }

  main.innerHTML = `
    <div class="chat-screen">
      <div class="chat-head">
        <img src="character/v3/heart.png" alt="" />
        <div class="title">אני כאן איתך</div>
        <button class="chat-close" id="chat-close">סגירה</button>
      </div>
      <div class="chat-privacy">מה שנכתב כאן נשאר בינינו ולא נשמר בשום מקום</div>
      <div class="chat-log" id="chat-log">
        ${renderChatBubble("ora", opening)}
      </div>
      <div class="chat-input-row">
        <input type="text" id="chat-input" class="chat-input"
               placeholder="ספרי לי מה קורה עכשיו…" />
        <button class="chat-send" id="chat-send" aria-label="שליחה">←</button>
      </div>
      <button class="btn-link muted chat-back" id="chat-back">חזרה לדף הבית</button>
    </div>`;

  const log = document.getElementById("chat-log");
  const input = document.getElementById("chat-input");
  const sendBtn = document.getElementById("chat-send");

  // DESIGN.md §1 principle 4: an action that isn't available disappears,
  // it doesn't grey out — this product has no `disabled` state. Once the
  // bank's own closing line has been shown there is nothing left for her
  // to send, so the input row is removed outright rather than merely
  // disabled.
  function closeInput() {
    document.querySelector(".chat-input-row")?.remove();
  }

  if (convState.closed) closeInput();

  async function send() {
    const text = input.value.trim();
    if (!text || convState.closed) return;
    input.value = "";
    sendBtn.disabled = true;

    log.insertAdjacentHTML("beforeend", renderChatBubble("me", text));
    log.insertAdjacentHTML(
      "beforeend",
      `<div class="chat-row ora" id="chat-typing"><div class="chat-bubble typing">כותבת…</div></div>`
    );
    log.scrollTop = log.scrollHeight;

    let answer = CHAT_FALLBACK_REPLY;
    try {
      const step = await askOra(convState, convPoolHistory);
      answer = step.reply;
      convState = step.state;
      convPoolHistory = step.poolHistory;
      await storeSet({ chatPoolHistory: convPoolHistory });
    } catch {
      // fall through with CHAT_FALLBACK_REPLY
    }
    document.getElementById("chat-typing")?.remove();

    history.push({ role: "user", text }, { role: "assistant", text: answer });

    log.insertAdjacentHTML("beforeend", renderChatBubble("ora", answer));
    log.scrollTop = log.scrollHeight;
    sendBtn.disabled = false;
    if (convState.closed) {
      closeInput();
      // issue #87 — only a chat that reached its closing line is a return,
      // and only the second one of the day hands the valve over.
      const count = await noteChatClosed();
      if (await shouldOfferValveAtClose(count)) appendValveOffer(log);
    } else {
      input.focus();
    }
  }

  sendBtn.addEventListener("click", send);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      send();
    }
  });
  document.getElementById("chat-close").addEventListener("click", showHome);
  document.getElementById("chat-back").addEventListener("click", showHome);
  input.focus();
}

// ---------- the hard-day valve (issue #87, docs/messages.md group 8) ----------
//
// Not a button on the screen: "כפתור גלוי הוא הזמנה, והוא מייתר את השיחה".
// The chat hands it over, and only at the close of a conversation she came
// BACK to — the second *completed* chat of the same product day (dateStr(),
// so 01:00 still belongs to the evening before). On the third press that
// day it is handed over at once, with no chat. Most women never see it.
//
// Once she accepts, nothing argues. One absolute instant is written here
// (hardDayValve.readyAt, ten minutes out) and nothing else runs in this
// popup: the service worker arms a chrome.alarms alarm for it and flips
// `ready` when it lands (background.js, syncValveAlarm/markValveReady), so
// closing the popup, the browser or the machine changes nothing. She comes
// back before it: the waiting text. After it: one button. A valve she never
// comes back to is dropped the next day, and nothing is recorded — "ואם היא
// לא חוזרת, זה עצמו התשובה."
//
// Every word on these screens is docs/messages.md group 8, reached as
// window.MESSAGE_BANK.valve (chat-bridge.js) — a draft bank, marked as one
// there; nothing is typed here. The kabbalah is never named (⚑13: the day
// releases all of them), so nothing here is escaped except what she types.
const VALVE_WAIT_MS = 10 * 60 * 1000;
const VALVE_OFFER_AT_CLOSE = 2; // the second completed chat of the day
const VALVE_IMMEDIATE_AT = 3;   // the third press skips the chat

// A valve she is still inside — waiting out the ten minutes, or standing at
// the ready screen for her to press release — is not lost the instant the
// product day turns under her. She may accept at 02:58 and reopen the popup
// at 03:04: hardDayValve.day (the evening before) and dateStr() (the new
// day) now disagree, but the ten minutes she is living through do not care
// what the calendar just did. So "stale" is day !== dateStr() *and* more
// than this long past her own readyAt — a grace, not a second window, wide
// enough to cover the ten minutes plus however long she takes to notice the
// screen once it is ready — one hour. Mirrored in background.js's copy of
// this same name, the same way DAY_RESET_HOUR is mirrored across files; a
// test checks the two still agree.
const VALVE_CARRYOVER_MS = 60 * 60 * 1000;

// showHome() routes to a pending valve on its own (below), so every
// ordinary "go home" click across the popup would otherwise loop straight
// back to it while it waits — she could never actually see her list. This
// flips true only when she presses the waiting/ready screen's own "חזרה
// לדף הבית" (below), so that one press is honoured for the rest of this
// popup's life; the valve itself is untouched and still sits there for the
// next fresh popup open, or for a deliberate return via "קשה לי עכשיו".
let valveDismissedThisSession = false;

function valveCopy(moment) {
  return window.MESSAGE_BANK?.valve?.moments?.[moment] || null;
}

function releasedKey(day) {
  return `released:${day}`;
}

async function dayReleasedToday() {
  const key = releasedKey(dateStr());
  const data = await storeGet(key);
  return Boolean(data[key]);
}

// How many chats reached their closing line today. The engine spec is
// exact: a chat opened and abandoned mid-way is not a return, so this is
// written only from the branch of send() that shows the closing line.
async function valveChatsClosedToday() {
  const { valveChatsClosed } = await storeGet("valveChatsClosed");
  return valveChatsClosed && valveChatsClosed.day === dateStr() ? valveChatsClosed.count : 0;
}

async function noteChatClosed() {
  const count = (await valveChatsClosedToday()) + 1;
  await storeSet({ valveChatsClosed: { day: dateStr(), count } });
  return count;
}

// The valve she accepted today, or null. One from another product day is
// dropped here too (background.js's syncValveAlarm does the same on its
// side; whichever runs first), unrecorded.
async function pendingValve() {
  const { hardDayValve } = await storeGet("hardDayValve");
  if (!hardDayValve) return null;
  // issue #87 — whole-branch review, FINDING 5. A non-numeric readyAt
  // (unreachable through any product write, but silent and dangerous if it
  // ever happened) would make every "how long until ready" computation
  // downstream NaN: Math.max(0, NaN - Date.now()) is NaN, and
  // setTimeout(fn, NaN) fires on effectively every tick — showValve()
  // re-rendering itself in a tight loop with no way out, since pendingValve()
  // kept handing back the same corrupted valve. Treated exactly like a
  // stale one: dropped here, at the single choke point every caller in
  // this file already goes through, unrecorded.
  if (!Number.isFinite(hardDayValve.readyAt)) {
    await storeRemove(["hardDayValve", "hardDayValveNote"]);
    return null;
  }
  // A day mismatch alone is not stale — see VALVE_CARRYOVER_MS above; only
  // past the grace, on top of the day having turned, is it dropped.
  if (hardDayValve.day !== dateStr() && Date.now() > hardDayValve.readyAt + VALVE_CARRYOVER_MS) {
    await storeRemove(["hardDayValve", "hardDayValveNote"]);
    return null;
  }
  return hardDayValve;
}

async function shouldOfferValveAtClose(count) {
  if (count < VALVE_OFFER_AT_CLOSE) return false;
  if (await dayReleasedToday()) return false;
  return !(await pendingValve());
}

// A stray double press (a slow touchscreen firing twice, or this popup's
// own dom stub, dispatch both clicks synchronously — before either
// invocation's first `await` has resolved) must still write hardDayValve
// once and journal valve_accepted once. A check that itself awaits storage
// cannot catch that: both invocations would read "no valve yet" before
// either has written. This flag is the synchronous half of the guard; the
// pendingValve() check below is the slower half — a valve already sitting
// in storage from an earlier tick, or because she is pressing the very
// button showValve() itself renders once ready, is routed to, never
// re-asked and never overwritten.
let acceptingValve = false;

async function acceptValve() {
  if (acceptingValve) return;
  acceptingValve = true;
  try {
    if (await pendingValve()) {
      showValve();
      return;
    }
    const now = Date.now();
    await storeSet({
      hardDayValve: { day: dateStr(), requestedAt: now, readyAt: now + VALVE_WAIT_MS, ready: false },
      // A brand new valve starts with a clean note field — an orphaned note
      // from an earlier race (accept, never return, accept again days
      // later) must not resurface under a valve she never wrote it for.
      hardDayValveNote: "",
    });
    // Visible in her data either way: a valve accepted and never returned to
    // is the spec's own "that itself is the answer", and worth seeing.
    await journalEvent("valve_accepted");
    showValve();
  } finally {
    acceptingValve = false;
  }
}

function valveLinesHtml(copy) {
  return copy.text.split("\n").map((l) => `<div class="aux-lead">${l}</div>`).join("");
}

// The offer, after the closing line, inside the chat log: one more line
// from the character and the one button. `.chat-row.valve`, not `.ora`, so
// the button row is not read as a line she said.
function appendValveOffer(log) {
  const copy = valveCopy("offer");
  if (!copy) return;
  log.insertAdjacentHTML("beforeend", renderChatBubble("ora", copy.text));
  log.insertAdjacentHTML(
    "beforeend",
    `<div class="chat-row valve"><button class="btn-primary sm" id="valve-accept">${copy.button}</button></div>`
  );
  document.getElementById("valve-accept").addEventListener("click", acceptValve);
  log.scrollTop = log.scrollHeight;
}

// The third return: no chat, no argument, "גם בלי להזכיר שזאת הפעם
// השלישית". The same button leads to the same ten minutes (⚑15).
//
// issue #87 — whole-branch review, FINDING 12. "← חזרה" everywhere in the
// valve screens (here, the waiting/ready screen below, and releaseDay()'s
// own confirmation screen) rather than "חזרה לדף הבית": this file's
// second, separate quiet-link screen — morning-after — already uses
// "← חזרה" for the identical step-back-to-the-list gesture, and it is
// DESIGN.md §3.1's own documented quiet-link example ("וריאנט שקט: ← חזרה").
// The valve used to say "חזרה לדף הבית" in three of its four places and
// "← חזרה" in the fourth (releaseDay()'s own screen) — one feature,
// the same button, two different words for it.
function showValveImmediate() {
  const copy = valveCopy("immediate");
  if (!copy) {
    showConversation();
    return;
  }
  const main = document.getElementById("main");
  main.innerHTML = `
    <div class="aux-screen" data-valve-screen="immediate">
      <img class="aux-char" src="character/v3/heart.png" alt="" />
      ${valveLinesHtml(copy)}
      <div class="aux-actions">
        <button class="btn-primary sm" id="valve-accept">${copy.button}</button>
        <button class="btn-link" id="valve-back">← חזרה</button>
      </div>
    </div>`;
  document.getElementById("valve-accept").addEventListener("click", acceptValve);
  document.getElementById("valve-back").addEventListener("click", showHome);
}

// The optional line she can write, inside the ten minutes (⚑16). Saved on
// every keystroke under its own key so closing the popup loses nothing;
// moved into released:<day> when she releases; dropped with the valve if
// she never does. Never required, never sent anywhere.
function valveNoteHtml(saved) {
  const copy = valveCopy("note");
  if (!copy) return "";
  return `
    ${valveLinesHtml(copy)}
    <textarea id="valve-note" class="valve-note" placeholder="${copy.placeholder || ""}">${escapeHtml(saved)}</textarea>`;
}

function wireValveNote() {
  const field = document.getElementById("valve-note");
  if (!field) return;
  field.addEventListener("input", async () => {
    // A keystroke that lands after the screen has moved on — release
    // cleared the valve, or the grace ran out underneath her — must not
    // resurrect hardDayValveNote once nothing is asking for it any more.
    if (!(await pendingValve())) return;
    storeSet({ hardDayValveNote: field.value });
  });
}

// The ten minutes, and what waits for her after them. No countdown and no
// timer of this popup's own: "לא טיימר שרץ, ולא ספירה לאחור שמוצגת לה".
// Before the instant — the waiting text and the note field. After it, or
// once the worker has flipped `ready` — one line and one button. `ready`
// is honoured even if this popup's clock disagrees: the worker's alarm is
// the product's clock, and minutes she already waited through are not
// un-earned by a clock set back.
async function showValve() {
  const valve = await pendingValve();
  if (!valve) {
    showHome();
    return;
  }
  const ready = valve.ready || Date.now() >= valve.readyAt;
  const copy = valveCopy(ready ? "ready" : "waiting");
  if (!copy) {
    // A valve is genuinely pending, but the bank has nothing to say about
    // it — a build gap, not her doing. showHome()'s own pendingValve()
    // check would otherwise route straight back here and back again,
    // forever: this one press is what that check honours instead, exactly
    // as if she had pressed "← חזרה" herself.
    valveDismissedThisSession = true;
    showHome();
    return;
  }
  const { hardDayValveNote = "" } = await storeGet("hardDayValveNote");
  const main = document.getElementById("main");
  main.innerHTML = `
    <div class="aux-screen" data-valve-screen="${ready ? "ready" : "waiting"}">
      <img class="aux-char" src="character/v3/heart.png" alt="" />
      ${valveLinesHtml(copy)}
      ${valveNoteHtml(hardDayValveNote)}
      <div class="aux-actions">
        ${ready ? `<button class="btn-primary sm" id="valve-release">${copy.button}</button>` : ""}
        <button class="btn-link" id="valve-back">← חזרה</button>
      </div>
    </div>`;
  wireValveNote();
  document.getElementById("valve-back").addEventListener("click", () => {
    // "את לא צריכה להישאר כאן" cuts both ways: she is also not trapped in
    // front of it. This one press is what showHome()'s own pendingValve()
    // check (below) honours for the rest of this popup's life.
    valveDismissedThisSession = true;
    showHome();
  });
  if (ready) {
    const releaseBtn = document.getElementById("valve-release");
    releaseBtn.addEventListener("click", () => {
      // Disabled the instant she presses, synchronously — before releaseDay
      // has done anything async. A slow device can fire Enter-key
      // auto-repeat as two click events back to back, and a check that
      // itself awaits storage would let both land before either has
      // written; a disabled button never runs its listener a second time
      // (see dom-stub.mjs's own click(), which mirrors real DOM behaviour).
      releaseBtn.disabled = true;
      releaseDay();
    });
    return;
  }

  // Waiting with the popup open. The worker flips `ready` through storage
  // when its alarm lands; listen for that, and only re-render if this
  // screen is still the one on show — she may have gone home meanwhile.
  // Outside the extension (the design preview has no chrome.storage) a
  // plain timeout stands in for the alarm.
  if (hasChrome && chrome.storage.onChanged) {
    let settled = false;
    const settle = () => {
      if (settled) return;
      settled = true;
      chrome.storage.onChanged.removeListener(onChange);
      clearTimeout(fallback);
      if (document.querySelector("[data-valve-screen]")) showValve();
    };
    const onChange = (changes, area) => {
      if (area !== "local" || !changes.hardDayValve) return;
      settle();
    };
    chrome.storage.onChanged.addListener(onChange);
    // storage.onChanged stays the primary path — it is how the worker's
    // alarm actually reaches an open popup. This is only a backstop: a
    // torn-down worker or a lost alarm must not leave the popup staring at
    // a waiting screen whose ten minutes have already passed, with nothing
    // left to tell it so.
    const fallback = setTimeout(settle, Math.max(0, valve.readyAt - Date.now()));
  } else {
    setTimeout(() => {
      if (document.querySelector("[data-valve-screen]")) showValve();
    }, Math.max(0, valve.readyAt - Date.now()));
  }
}

// The one click. Releases the day for every kabbalah (⚑13) — the key
// background.js reads to stop stopping her today and to judge the day
// tomorrow — journals one `released` entry per kabbalah (the third state
// the morning-after screen, the dashboard and the export read), moves her
// note into the day's record, and clears the valve. The kabbalot
// themselves are not touched here: the day is judged once, by
// evaluatePastDays, exactly like every other day.
//
// Re-validates through pendingValve() rather than trusting the `valve`
// object showValve() closed over: between render and her click, another
// popup instance may have already released it, or the grace may have run
// out underneath her. day comes from the valve itself (⚑15/grace) — the
// product day she pressed in, never dateStr() at click time.
async function releaseDay() {
  const valve = await pendingValve();
  if (!valve) {
    showHome();
    return;
  }
  // FINDING 10 (whole-branch review) — day is the valve's own, not
  // dateStr() at click time, on purpose (⚑15/grace: a release inside the
  // 03:00 carryover grace still credits the evening she pressed in, for
  // evaluatePastDays' own judging). But background.js's broadcast listener
  // and blockStateFor() key their same-day read on dateStr(), not on this
  // value — see their own notes (background.js, releasedKey(dateStr())
  // sites) for the resulting gap and why it is left as-is.
  const day = valve.day;
  const { kabbalot = [], events = [], hardDayValveNote = "" } = await storeGet([
    "kabbalot", "events", "hardDayValveNote",
  ]);
  const at = new Date().toISOString();
  const entries = kabbalot.map((k) => ({
    type: "released",
    occurredAt: at,
    kabbalahId: k.id,
    meta: { day },
  }));
  await storeSet({
    [releasedKey(day)]: { at, note: hardDayValveNote },
    hardDayValve: null,
    hardDayValveNote: "",
    events: [...events, ...entries].slice(-500),
  });

  // "לומר מה קרה, מיד. בלי לברך אותה ובלי למחול לה." One line and the way
  // back; "← חזרה" is DESIGN.md §3.1's own quiet link for a step back.
  const copy = valveCopy("released");
  const main = document.getElementById("main");
  main.innerHTML = `
    <div class="aux-screen" data-valve-screen="released">
      <img class="aux-char" src="character/v3/heart.png" alt="" />
      ${copy ? valveLinesHtml(copy) : ""}
      <div class="aux-actions">
        <button class="btn-link" id="valve-done">← חזרה</button>
      </div>
    </div>`;
  document.getElementById("valve-done").addEventListener("click", showHome);
}

document.addEventListener("DOMContentLoaded", async () => {
  await seedPreviewScenario();
  showHome();
});

// ---- design-review seeding, outside the extension only ----------------
// index.html's "הבוקר שאחרי נפילה" tile lands here with ?preview=fall. It
// used to open morning-after.html, a page that seeded itself on first load
// so Sara never met an empty screen; that page is gone, so its seeding job
// comes here. Without it the tile would render the ordinary home list and
// look as though the screen had been deleted rather than moved.
//
// Guarded by hasChrome, exactly like __preview below: inside the real
// extension this function does not exist as anything but an immediate
// return, and no query string can make it write to her storage.
async function seedPreviewScenario() {
  if (hasChrome) return;
  if (typeof location === "undefined") return;
  let scenario = null;
  try {
    scenario = new URLSearchParams(location.search).get("preview");
  } catch {
    return;
  }
  if (scenario !== "fall") return;

  // The example the tile has always promised: one kabbalah fell yesterday,
  // one is still standing — which is the M-02 branch, the multi-kabbalah
  // message. The journal entry matters as much as the kabbalot do: without
  // a `fall` event the model cannot count consecutive days, and M-03/M-04
  // would be unreachable in preview.
  const today = dateStr();
  // Built through Date so the 1st of a month rolls back into the previous
  // one, rather than producing a "2026-09-00" that parses into nonsense.
  const n = new Date();
  const yd = new Date(n.getFullYear(), n.getMonth(), n.getDate() - 1);
  const yesterday = `${yd.getFullYear()}-${String(yd.getMonth() + 1).padStart(2, "0")}-${String(
    yd.getDate()
  ).padStart(2, "0")}`;
  await storeSet({
    kabbalot: [
      {
        id: "preview_k1", name: "הפינה ההיא",
        rule: { kind: "dailyLimit", limitMinutes: 90 },
        places: ["preview-place-one.example"],
        baselineMinutes: 120, mode: "companion",
        streak: 0, longestStreak: 9, daysKept: 11, stationsReached: 1,
        pendingStation: null, fellOn: yesterday, fallAcked: false,
        createdAt: today,
      },
      {
        id: "preview_k2", name: "האתר השני",
        rule: { kind: "window", from: "20:00", to: "21:00" },
        places: ["preview-place-two.example"],
        baselineMinutes: 45, mode: "companion",
        streak: 6, longestStreak: 6, daysKept: 9, stationsReached: 1,
        pendingStation: null, fellOn: null, fallAcked: true,
        createdAt: today,
      },
    ],
    events: [
      { type: "fall", occurredAt: new Date().toISOString(), kabbalahId: "preview_k1", meta: { day: yesterday } },
    ],
  });
}

// Preview-only helper for trying out states outside the extension runtime
// (extension/index.html → popup.html, served over http — see the report).
if (!hasChrome) {
  window.__preview = {
    async seed(opts = {}) {
      const {
        limit = 100,
        usedMin = 40,
        streak = 4,
        fell = false,
        treasureMinutes = 0,
        mode = "companion",
        pendingStation = null,
        achievements = [],
      } = opts;
      const today = dateStr();
      await storeSet({
        kabbalot: [
          {
            id: "k_preview",
            name: "הפינה ההיא",
            rule: { kind: "dailyLimit", limitMinutes: limit },
            places: ["example.co.il"],
            baselineMinutes: 120,
            mode,
            streak: fell ? 0 : streak,
            longestStreak: streak,
            daysKept: streak,
            stationsReached: 0,
            pendingStation,
            fellOn: fell ? today : null,
            fallAcked: !fell,
            createdAt: today,
          },
        ],
        treasureMinutes,
        achievements,
        [`usage:${today}`]: { "example.co.il": usedMin * 60 },
      });
      showHome();
    },
    // Multi-kabbalah preview: seedMany([{ name, streak, fellOn, mode, ... }]).
    async seedMany(list) {
      const today = dateStr();
      await storeSet({
        kabbalot: list.map((k, i) => ({
          id: k.id || `k_preview_${i}`,
          name: k.name || `קבלה ${i + 1}`,
          rule: k.rule || { kind: "dailyLimit", limitMinutes: 60 },
          places: k.places || [`example${i}.co.il`],
          baselineMinutes: k.baselineMinutes ?? 120,
          mode: k.mode || "companion",
          streak: k.streak ?? 0,
          longestStreak: k.longestStreak ?? k.streak ?? 0,
          daysKept: k.daysKept ?? k.streak ?? 0,
          stationsReached: k.stationsReached ?? 0,
          pendingStation: k.pendingStation ?? null,
          fellOn: k.fellOn ?? null,
          fallAcked: k.fallAcked ?? true,
          createdAt: k.createdAt || today,
        })),
        treasureMinutes: 0,
        achievements: [],
        [`usage:${today}`]: Object.fromEntries(
          list.map((k, i) => [k.places?.[0] || `example${i}.co.il`, (k.usedMin ?? 0) * 60])
        ),
      });
      showHome();
    },
    async clear() {
      await storeClear();
      showHome();
    },
  };
}
