// בחרתי בי — the handful of things both the popup and the onboarding need.
// Loaded as a plain script before each page's own script, so these are
// globals on purpose: there is no build step in this project.

// The character has one name, written down exactly once. Issue #44's name
// question is still open; when it is answered, the answer is a line here,
// not a sweep through the screens. Its emoji question is answered: Sara's
// ruling is that the illustrated character carries the warmth, not a glyph
// beside her words — "I only want my character, not a leaf emoji." So
// MENTOR_EMOJI is kept as an empty constant, not deleted, in case that is
// ever revisited; nothing in this product should build a string that puts a
// character on screen from it today.
const MENTOR_NAME = "אורה";
const MENTOR_EMOJI = "";

const hasChrome = typeof chrome !== "undefined" && chrome.storage;

// Outside the extension the preview stands in for chrome.storage. It is
// backed by localStorage so that reloading the preview behaves the way
// closing and reopening the popup does.
const memStore = (() => {
  try {
    return JSON.parse(localStorage.getItem("kabbalot:preview") || "{}");
  } catch {
    return {};
  }
})();

function persistMemStore() {
  try {
    localStorage.setItem("kabbalot:preview", JSON.stringify(memStore));
  } catch {
    // Private mode or no localStorage — the preview still works in-session.
  }
}

async function storeGet(keys) {
  if (hasChrome) return chrome.storage.local.get(keys);
  const list = Array.isArray(keys) ? keys : [keys];
  const out = {};
  for (const k of list) if (k in memStore) out[k] = memStore[k];
  return out;
}

async function storeSet(obj) {
  if (hasChrome) return chrome.storage.local.set(obj);
  Object.assign(memStore, obj);
  persistMemStore();
}

// issue #87 — whole-branch review, FINDING 12. background.js's own
// storage-clearing sites (pruneOldDays, pruneOnboardingDraft,
// releaseExpiredGrace, sign-out) all use chrome.storage.local.remove():
// the key is gone, not left sitting at a null value. popup.js's valve
// code used to write hardDayValve: null through storeSet() at the same
// moments background.js calls remove() for the identical reason (a stale
// or corrupted valve, dropped) — same intent, two different shapes in
// storage. Unified here in the same dual-mode style as storeGet/storeSet
// above, for the design preview (no chrome.storage) to keep working too.
async function storeRemove(keys) {
  if (hasChrome) return chrome.storage.local.remove(keys);
  for (const k of Array.isArray(keys) ? keys : [keys]) delete memStore[k];
  persistMemStore();
}

async function storeClear() {
  if (hasChrome) return chrome.storage.local.clear();
  for (const k of Object.keys(memStore)) delete memStore[k];
  persistMemStore();
}

// The hour her day turns over — issue #6's proposal, still awaiting Sara's
// answer. Mirrored from background.js on purpose: this project has no module
// system, the same reason GRACE_POOL_PER_WEEK is written out twice. If the
// hour changes it has to change in all three files (background.js, here,
// export.js), and a test says so out loud rather than letting them drift.
const DAY_RESET_HOUR = 3;

// The day on her clock, not Greenwich's — and it turns at DAY_RESET_HOUR,
// not at midnight, so a woman still reading at half past midnight is looking
// at the evening she is actually in. The screens and the service worker have
// to agree on this to the hour, or the popup shows a day the streak has
// already closed and nobody can tell which of the two is lying.
function dateStr(d = new Date()) {
  const back = d.getHours() < DAY_RESET_HOUR ? 1 : 0;
  const day = new Date(d.getFullYear(), d.getMonth(), d.getDate() - back);
  const y = day.getFullYear();
  const m = String(day.getMonth() + 1).padStart(2, "0");
  const dd = String(day.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

function parseLink(raw) {
  try {
    const url = new URL(
      String(raw).includes("://") ? String(raw) : `https://${String(raw).trim()}`
    );
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (!host.includes(".")) return null;
    const path = (url.pathname || "/").replace(/\/$/, "");
    return { host, path: path && path !== "/" ? path : "" };
  } catch {
    return null;
  }
}

function domainFromInput(raw) {
  return parseLink(raw)?.host || null;
}
