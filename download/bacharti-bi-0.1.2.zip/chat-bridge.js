// Bridges chat-engine.js's ES module exports, and the pre-parsed message
// bank (message-bank.generated.js — see scripts/build-message-bank.mjs for
// why that file exists), onto `window`, so popup.js can reach them.
//
// Why a separate file and not `<script type="module">` directly on
// popup.js: popup.js is a plain classic script on purpose — its own file
// header says so, and extension/tests/*.mjs that exercise it (e.g.
// the-popup-holds-a-whole-list.mjs) load it by concatenating it with
// shared.js/morning-after-model.js and handing the result to
// `new Function(...)`, exactly the way a browser's own global scope stacks
// plain <script> tags. `import` declarations are a syntax error inside a
// function body, so making popup.js itself a module would break every one
// of those tests for an unrelated reason. This file carries the only two
// `import`s issue #17's engine needs, and hands their result across the
// module/classic-script boundary the same way a real browser would let any
// deferred script see it: as properties on the one global object both
// module and classic scripts share. See popup.html for the load order this
// depends on (this script tag can sit anywhere among the others — module
// scripts are always deferred until after the document is parsed, and
// nothing here is read before popup.js's own DOMContentLoaded handler
// runs, which is later still).
import * as ChatEngine from "./chat-engine.js";
import { MESSAGE_BANK } from "./message-bank.generated.js";

window.ChatEngine = ChatEngine;
window.MESSAGE_BANK = MESSAGE_BANK;
